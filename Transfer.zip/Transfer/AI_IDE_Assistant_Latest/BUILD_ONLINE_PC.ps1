$ErrorActionPreference = 'Stop'
$ProjectDir = Join-Path $PSScriptRoot 'AiIdeAssistant.Extension_FIXED'
$Solution = Join-Path $ProjectDir 'AiIdeAssistant.Extension.sln'
$VsWhere = Join-Path ${env:ProgramFiles(x86)} 'Microsoft Visual Studio\Installer\vswhere.exe'
if (-not (Test-Path $VsWhere)) { throw "vswhere.exe not found. Install Visual Studio 2022 with the required workloads first." }
$MsBuild = & $VsWhere -latest -products '*' -requires Microsoft.Component.MSBuild -find 'MSBuild\**\Bin\MSBuild.exe' | Select-Object -First 1
if (-not $MsBuild -or -not (Test-Path $MsBuild)) { throw "MSBuild not found in the installed Visual Studio instance." }
Write-Host "MSBuild: $MsBuild"
Write-Host "Restoring NuGet packages and building Release..."
& $MsBuild $Solution /restore /m /t:Rebuild /p:Configuration=Release /p:Platform="Any CPU" /verbosity:minimal
if ($LASTEXITCODE -ne 0) { throw "Build failed with exit code $LASTEXITCODE. Read the build output and fix errors before packaging." }
$Vsix = Get-ChildItem -Path $ProjectDir -Filter '*.vsix' -Recurse | Where-Object { $_.FullName -match '\\bin\\Release\\' } | Select-Object -First 1
if (-not $Vsix) {
  Write-Warning "Build succeeded, but no .vsix was found under bin\Release. Search the Build Output and project packaging settings."
  exit 2
}
$Drop = Join-Path $PSScriptRoot 'Output'
New-Item -ItemType Directory -Force -Path $Drop | Out-Null
$Dest = Join-Path $Drop 'AiIdeAssistant.Extension.vsix'
Copy-Item $Vsix.FullName $Dest -Force
Write-Host "Created VSIX: $Dest"
Write-Host "IMPORTANT: this is a build result, not a proof of runtime correctness. Install and run the acceptance checklist in OFFLINE_DEPLOYMENT_GUIDE.md."
