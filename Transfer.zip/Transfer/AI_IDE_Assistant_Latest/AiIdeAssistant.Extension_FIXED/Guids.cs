using System;

namespace AiIdeAssistant.Extension
{
    /// <summary>
    /// Single source of truth for the GUIDs used across the package, the command
    /// table (AiIdeAssistantPackage.vsct), and the tool window. Keep the string
    /// values here in sync with the &lt;GuidSymbol&gt; values in the .vsct file —
    /// they are duplicated there because VSCT cannot reference C# constants.
    /// </summary>
    internal static class PackageGuids
    {
        public const string PackageGuidString = "42e7d61d-48a3-489b-ad1c-dc6ba934693e";
        public const string CommandSetGuidString = "6d6da3e5-7728-4369-96c5-3da18cca1165";
        public const string ToolWindowGuidString = "cc71fcc1-91f7-4c26-972a-342feb4d4011";
        public const string CodeActionToolWindowGuidString = "5dcb7b4f-5fe1-4e39-bc17-8a7a5fae5ef2";

        public static readonly Guid CommandSet = new Guid(CommandSetGuidString);
    }
}
