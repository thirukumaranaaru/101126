using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Net.Http;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using AiIdeAssistant.Extension.Models;
using AiIdeAssistant.Extension.Services;

namespace AiIdeAssistant.Extension.ViewModels
{
    /// <summary>
    /// Phase 6: SendCurrentInputAsync calls the real Python backend via
    /// ApiClient (SRS FR-GA-3/4/5). This revision adds a local chat-history
    /// sidebar (ChatHistoryStore) so a developer can revisit a previous
    /// conversation — not an SRS requirement from the original 57-section
    /// spec, added on request.
    ///
    /// Threading note, because it's easy to get wrong here: every async
    /// method below deliberately does NOT use ConfigureAwait(false). This
    /// class is constructed on the WPF UI thread (from
    /// AiAssistantToolWindowControl's constructor), which has an active
    /// DispatcherSynchronizationContext, so a plain `await` resumes back on
    /// that UI thread — required, because these methods mutate
    /// ObservableCollection instances (Messages, Sessions) that WPF's
    /// data-binding only supports touching from the UI thread. Adding
    /// ConfigureAwait(false) anywhere in this chain (a common reflex from
    /// library code) would resume on a background thread and either throw
    /// or silently fail to update the UI.
    /// </summary>
    public class ChatViewModel : INotifyPropertyChanged, IDisposable
    {
        private readonly ApiClient apiClient = new ApiClient();
        private readonly ChatHistoryStore historyStore = new ChatHistoryStore();

        private string currentSessionId;
        private DateTime currentSessionCreatedAt;

        public ObservableCollection<ChatMessage> Messages { get; } = new ObservableCollection<ChatMessage>();

        public ObservableCollection<ChatSessionSummary> Sessions { get; } = new ObservableCollection<ChatSessionSummary>();

        private string currentInput = string.Empty;
        public string CurrentInput
        {
            get => this.currentInput;
            set
            {
                this.currentInput = value;
                this.OnPropertyChanged();
                this.OnPropertyChanged(nameof(CanSend));
            }
        }

        private bool isBusy;
        public bool IsBusy
        {
            get => this.isBusy;
            set
            {
                this.isBusy = value;
                this.OnPropertyChanged();
                this.OnPropertyChanged(nameof(IsBusyOrError));
                this.OnPropertyChanged(nameof(CanSend));
            }
        }

        private string statusMessage = string.Empty;
        public string StatusMessage
        {
            get => this.statusMessage;
            set
            {
                this.statusMessage = value;
                this.OnPropertyChanged();
                this.OnPropertyChanged(nameof(IsBusyOrError));
            }
        }

        private bool isHistoryVisible;
        public bool IsHistoryVisible
        {
            get => this.isHistoryVisible;
            set
            {
                this.isHistoryVisible = value;
                this.OnPropertyChanged();
                this.OnPropertyChanged(nameof(IsChatVisible));
            }
        }

        /// <summary>Bound to the chat view's Visibility — the inverse of
        /// IsHistoryVisible. A computed property instead of a value
        /// converter, consistent with IsBusyOrError below, to avoid adding
        /// a new IValueConverter class for one boolean flip.</summary>
        public bool IsChatVisible => !this.IsHistoryVisible;

        public bool IsBusyOrError => this.IsBusy || !string.IsNullOrEmpty(this.StatusMessage);

        public bool CanSend => !this.IsBusy && !string.IsNullOrWhiteSpace(this.CurrentInput);

        public ChatViewModel()
        {
            this.ResetToGreeting();

            // Fire-and-forget: WPF constructors can't be async. Errors are
            // caught inside ChatHistoryStore itself (returns an empty list
            // rather than throwing), so this can't crash the panel.
            _ = this.LoadSessionsAsync();
        }

        private void ResetToGreeting()
        {
            this.Messages.Clear();
            this.Messages.Add(new ChatMessage
            {
                Author = "Assistant",
                Content = "Ask me a programming, algorithm, or debugging question.",
                IsFromUser = false
            });
        }

        /// <summary>Refreshes the sidebar list from disk. Public so the
        /// code-behind can re-call it each time the sidebar is opened, in
        /// case another session was saved since the panel loaded.</summary>
        public async Task LoadSessionsAsync()
        {
            var summaries = await this.historyStore.LoadSessionSummariesAsync();

            this.Sessions.Clear();
            foreach (var summary in summaries)
            {
                this.Sessions.Add(summary);
            }
        }

        /// <summary>Starts a fresh, unsaved conversation. Nothing already
        /// persisted is deleted — this only resets the in-memory view.</summary>
        public void StartNewChat()
        {
            this.ResetToGreeting();
            this.currentSessionId = null;
            this.StatusMessage = string.Empty;
            this.IsHistoryVisible = false;
        }

        public async Task SelectSessionAsync(ChatSessionSummary summary)
        {
            if (summary == null)
            {
                return;
            }

            var messages = await this.historyStore.LoadSessionMessagesAsync(summary.Id);

            this.Messages.Clear();
            foreach (var message in messages)
            {
                this.Messages.Add(message);
            }

            this.currentSessionId = summary.Id;
            this.currentSessionCreatedAt = summary.CreatedAt;
            this.StatusMessage = string.Empty;
            this.IsHistoryVisible = false;
        }

        public async Task<bool> RenameSessionAsync(ChatSessionSummary summary, string title)
        {
            if (summary == null || string.IsNullOrWhiteSpace(title)) return false;
            var renamed = await this.historyStore.RenameSessionAsync(summary.Id, title);
            if (renamed)
            {
                if (summary.Id == this.currentSessionId) summary.Title = title.Trim();
                await this.LoadSessionsAsync();
            }
            return renamed;
        }

        public async Task<bool> DeleteSessionAsync(ChatSessionSummary summary)
        {
            if (summary == null) return false;
            var deleted = await this.historyStore.DeleteSessionAsync(summary.Id);
            if (deleted)
            {
                if (summary.Id == this.currentSessionId) this.StartNewChat();
                await this.LoadSessionsAsync();
            }
            return deleted;
        }

        public async Task SendCurrentInputAsync()
        {
            if (!this.CanSend)
            {
                return;
            }

            var userText = this.CurrentInput;
            var historyForBackend = this.BuildHistoryDto();

            this.Messages.Add(new ChatMessage { Author = "You", Content = userText, IsFromUser = true });
            this.CurrentInput = string.Empty;
            this.IsBusy = true;
            this.StatusMessage = "Thinking...";

            try
            {
                var response = await this.apiClient.SendChatAsync(userText, historyForBackend);

                this.Messages.Add(new ChatMessage
                {
                    Author = "Assistant",
                    Content = response.Reply,
                    IsFromUser = false
                });
                this.StatusMessage = string.Empty;

                await this.SaveCurrentSessionAsync();
            }
            catch (ApiClientException ex)
            {
                // FR-PANEL-5: clear, actionable error state, not a raw exception.
                this.StatusMessage = $"Error: {ex.Message}";
            }
            catch (HttpRequestException ex)
            {
                this.StatusMessage = $"Could not reach the AI backend: {ex.Message}";
            }
            catch (TaskCanceledException)
            {
                this.StatusMessage = "The request timed out. Please try again.";
            }
            finally
            {
                this.IsBusy = false;
            }
        }

        private async Task SaveCurrentSessionAsync()
        {
            if (string.IsNullOrEmpty(this.currentSessionId))
            {
                this.currentSessionId = Guid.NewGuid().ToString();
                this.currentSessionCreatedAt = DateTime.UtcNow;
            }

            var title = DeriveTitle(this.Messages);

            // Snapshot with ToList() on the UI thread before ChatHistoryStore
            // hops to a background thread (Task.Run) — ObservableCollection
            // is not safe to enumerate concurrently with UI-thread mutation.
            var saved = await this.historyStore.SaveSessionAsync(
                this.currentSessionId, title, this.currentSessionCreatedAt, this.Messages.ToList());

            if (saved)
            {
                await this.LoadSessionsAsync();
            }
            // If saving failed, the conversation itself is unaffected — this
            // exchange just silently isn't available in history. Not
            // surfaced as a StatusMessage error, to avoid interrupting an
            // otherwise-successful chat reply over a non-critical failure.
        }

        private static string DeriveTitle(IEnumerable<ChatMessage> messages)
        {
            var firstUserMessage = messages.FirstOrDefault(m => m.IsFromUser)?.Content;
            if (string.IsNullOrWhiteSpace(firstUserMessage))
            {
                return "New conversation";
            }

            var singleLine = firstUserMessage.Replace('\n', ' ').Replace('\r', ' ').Trim();
            return singleLine.Length > 40 ? singleLine.Substring(0, 40) + "..." : singleLine;
        }

        /// <summary>
        /// Converts the conversation so far (before the message just added in
        /// SendCurrentInputAsync) into the wire format the backend's
        /// ChatRequest.history expects.
        /// </summary>
        private List<ChatMessageDto> BuildHistoryDto()
        {
            var history = new List<ChatMessageDto>();
            foreach (var m in this.Messages)
            {
                history.Add(new ChatMessageDto
                {
                    Role = m.IsFromUser ? "user" : "assistant",
                    Content = m.Content
                });
            }
            return history;
        }

        public void Dispose() => this.apiClient.Dispose();

        public event PropertyChangedEventHandler PropertyChanged;

        private void OnPropertyChanged([CallerMemberName] string name = null) =>
            this.PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
    }
}
