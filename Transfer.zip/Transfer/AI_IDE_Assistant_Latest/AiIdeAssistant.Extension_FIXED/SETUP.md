# Setup

Use the repository-level `OFFLINE_DEPLOYMENT_GUIDE.md` for build and offline installation instructions. This source package is not precompiled or runtime-verified; build and test it with Visual Studio 2022 before transferring the generated VSIX.

The extension calls the backend directly and does not require Keycloak/OIDC configuration. Default backend URL: `http://192.168.1.150:8000`. Override with the user environment variable `AI_IDE_ASSISTANT_BACKEND_URL`.
