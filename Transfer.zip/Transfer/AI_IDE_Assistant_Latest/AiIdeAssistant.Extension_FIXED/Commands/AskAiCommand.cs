using System;
using System.ComponentModel.Design;
using AiIdeAssistant.Extension.ToolWindows;
using Microsoft.VisualStudio.Shell;
using Task = System.Threading.Tasks.Task;

namespace AiIdeAssistant.Extension.Commands
{
    /// <summary>
    /// Handles Tools &gt; Ask AI (SRS FR-GA-1). Placed under the standard Tools-menu
    /// "add-ins" group rather than as a bespoke new top-level menu bar entry — see
    /// the note in AiIdeAssistantPackage.vsct on why that placement was chosen.
    /// </summary>
    internal sealed class AskAiCommand
    {
        public static readonly int CommandId = PkgCmdIDList.cmdidAskAi;

        public static readonly Guid CommandSet = PackageGuids.CommandSet;

        private readonly AsyncPackage package;

        private AskAiCommand(AsyncPackage package, OleMenuCommandService commandService)
        {
            this.package = package ?? throw new ArgumentNullException(nameof(package));
            if (commandService == null)
            {
                throw new ArgumentNullException(nameof(commandService));
            }

            var menuCommandId = new CommandID(CommandSet, CommandId);
            var menuItem = new MenuCommand(this.Execute, menuCommandId);
            commandService.AddCommand(menuItem);

            // Dedicated toolbar command: separate command ID, same behavior.
            var toolbarCommandId = new CommandID(CommandSet, PkgCmdIDList.cmdidAskAiToolbar);
            var toolbarItem = new MenuCommand(this.Execute, toolbarCommandId);
            commandService.AddCommand(toolbarItem);
        }

        public static AskAiCommand Instance { get; private set; }

        public static async Task InitializeAsync(AsyncPackage package)
        {
            await ThreadHelper.JoinableTaskFactory.SwitchToMainThreadAsync(package.DisposalToken);

            var commandService = await package.GetServiceAsync(typeof(IMenuCommandService)) as OleMenuCommandService;
            Instance = new AskAiCommand(package, commandService);
        }

        private void Execute(object sender, EventArgs e)
        {
            ThreadHelper.ThrowIfNotOnUIThread();

            // Phase 3: open the dockable AI Assistant panel (SRS FR-GA-2).
            // Deliberately fire-and-forget: Execute() is a synchronous event handler
            // (MenuCommand requires an EventHandler signature), so it cannot itself
            // be async/await.
            _ = this.package.JoinableTaskFactory.RunAsync(async () =>
            {
                await AiAssistantToolWindow.ShowAsync(this.package);
            });
        }
    }
}
