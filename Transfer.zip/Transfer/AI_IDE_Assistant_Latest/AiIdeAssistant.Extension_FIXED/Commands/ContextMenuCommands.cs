using System;
using System.ComponentModel.Design;
using System.Net.Http;
using System.Threading.Tasks;
using AiIdeAssistant.Extension.Dialogs;
using AiIdeAssistant.Extension.Models;
using AiIdeAssistant.Extension.Services;
using AiIdeAssistant.Extension.ToolWindows;
using EnvDTE;
using Microsoft.VisualStudio.Shell;
using Microsoft.VisualStudio.Shell.Interop;

namespace AiIdeAssistant.Extension.Commands
{
    /// <summary>
    /// The three requested editor context-menu actions. Wire-format action
    /// strings must match the backend's code-action enum exactly.
    /// </summary>
    internal sealed class ContextMenuCommands
    {
        private const string ActionExplain = "explain";
        private const string ActionEvaluate = "evaluate";
        private const string ActionFixErrors = "fix_errors";
        private const string ActionDirectFixErrors = "direct_fix_errors";
        private const string ActionAlgorithmToCode = "algorith_to_code";
        private const string ActionCodeToAlgorithm = "code_to_algorithm";

        private readonly AsyncPackage package;
        private readonly ApiClient apiClient = new ApiClient();

        private ContextMenuCommands(AsyncPackage package, OleMenuCommandService commandService)
        {
            this.package = package ?? throw new ArgumentNullException(nameof(package));
            if (commandService == null)
            {
                throw new ArgumentNullException(nameof(commandService));
            }

            this.AddCommand(commandService, PkgCmdIDList.cmdidExplainCode, ActionExplain, "Explain Code");
            this.AddCommand(commandService, PkgCmdIDList.cmdidEvaluateCode, ActionEvaluate, "Evaluate Code");
            this.AddCommand(commandService, PkgCmdIDList.cmdidFixErrors, ActionFixErrors, "Fix Errors");
            this.AddCommand(commandService, PkgCmdIDList.cmdidDirectFixErrors, ActionDirectFixErrors, "Direct Fix Errors");
            this.AddCommand(commandService, PkgCmdIDList.cmdidAlgorithmToCode, ActionAlgorithmToCode, "Algorithm to Code");
            this.AddCommand(commandService, PkgCmdIDList.cmdidCodeToAlgorithm, ActionCodeToAlgorithm, "Code to Algorithm");
        }

        public static ContextMenuCommands Instance { get; private set; }

        public static async Task InitializeAsync(AsyncPackage package)
        {
            await ThreadHelper.JoinableTaskFactory.SwitchToMainThreadAsync(package.DisposalToken);

            var commandService = await package.GetServiceAsync(typeof(IMenuCommandService)) as OleMenuCommandService;
            Instance = new ContextMenuCommands(package, commandService);
        }

        private void AddCommand(OleMenuCommandService commandService, int commandId, string action, string displayName)
        {
            var menuCommandId = new CommandID(PackageGuids.CommandSet, commandId);
            var command = new OleMenuCommand((sender, e) => this.OnInvoked(action, displayName), menuCommandId);

            // FR-CTX-1: only relevant when code is actually selected.
            command.BeforeQueryStatus += (sender, e) =>
            {
                var oleCommand = (OleMenuCommand)sender;
                oleCommand.Visible = HasNonEmptySelection();
                oleCommand.Enabled = oleCommand.Visible;
            };

            commandService.AddCommand(command);
        }

        /// <summary>
        /// Gets the DTE automation object. Uses the global service provider
        /// rather than AsyncPackage.GetServiceAsync because this is called
        /// from the synchronous BeforeQueryStatus event, which cannot await
        /// — confirmed against Microsoft's own documented pattern for
        /// exactly this case (see the chat history note on
        /// ServiceProvider.GlobalProvider).
        /// </summary>
        private static DTE GetDte()
        {
            ThreadHelper.ThrowIfNotOnUIThread();
            return ServiceProvider.GlobalProvider.GetService(typeof(DTE)) as DTE;
        }

        private static bool HasNonEmptySelection()
        {
            ThreadHelper.ThrowIfNotOnUIThread();

            try
            {
                var selection = GetDte()?.ActiveDocument?.Selection as TextSelection;
                return !string.IsNullOrWhiteSpace(selection?.Text);
            }
            catch
            {
                // BeforeQueryStatus must never throw — if the active document
                // is in an unexpected state, just hide the command.
                return false;
            }
        }

        private void OnInvoked(string action, string displayName)
        {
            ThreadHelper.ThrowIfNotOnUIThread();

            _ = this.package.JoinableTaskFactory.RunAsync(async () =>
            {
                await this.ExecuteCodeActionAsync(action, displayName);
            });
        }

        private async Task ExecuteCodeActionAsync(string action, string displayName)
        {
            await ThreadHelper.JoinableTaskFactory.SwitchToMainThreadAsync(this.package.DisposalToken);

            var dte = GetDte();
            var activeDocument = dte?.ActiveDocument;
            var selection = activeDocument?.Selection as TextSelection;
            var selectedCode = selection?.Text;

            if (string.IsNullOrWhiteSpace(selectedCode))
            {
                return; // BeforeQueryStatus should already have hidden the command.
            }

            string instruction = null;
            string compilerError = null;
            // Default to the active document's language; Algorithm to Code
            // replaces it with the target language chosen by the user.
            string language = activeDocument.Language;

            if (action == ActionFixErrors)
            {
                compilerError = SimpleInputDialog.Show(
                    "Fix Errors",
                    "Paste the compiler/build error for the selected code:");
                if (compilerError == null)
                {
                    return; // user cancelled or left the error box empty
                }
            }
            else if (action == ActionAlgorithmToCode)
            {
                var targetLanguage = LanguageInputDialog.GetLanguage();
                if (targetLanguage == null)
                {
                    return; // user cancelled or did not choose a language
                }

                language = targetLanguage;
            }

            var fileName = activeDocument.FullName;
            var projectName = activeDocument.ProjectItem?.ContainingProject?.Name;
            int? cursorPosition = selection.ActivePoint?.AbsoluteCharOffset;

            CodeActionResponseDto response;
            try
            {
                response = await this.apiClient.SendCodeActionAsync(
                    action, selectedCode, language, fileName, projectName, cursorPosition, instruction, compilerError);
            }
            catch (ApiClientException ex)
            {
                ShowWarning(ex.Message);
                return;
            }
            catch (HttpRequestException ex)
            {
                ShowWarning($"Could not reach the AI backend: {ex.Message}");
                return;
            }

            // Mirrors REPLACE_SELECTION_ACTIONS in backend/app/services/code_actions.py.
            var canReplaceSelection = action == ActionFixErrors || action == ActionDirectFixErrors;

            await CodeActionToolWindow.ShowResultAsync(
                this.package,
                actionDisplayName: displayName,
                resultText: response.Result,
                canReplaceSelection: canReplaceSelection,
                originatingSelection: selection,
                originalSelectedCode: selectedCode,
                insertBelowSelection: action == ActionAlgorithmToCode,
                insertAboveSelection: action == ActionCodeToAlgorithm);
        }

        private static void ShowWarning(string message)
        {
            ThreadHelper.ThrowIfNotOnUIThread();
            VsShellUtilities.ShowMessageBox(
                ServiceProvider.GlobalProvider,
                message,
                "AI Assistant",
                OLEMSGICON.OLEMSGICON_WARNING,
                OLEMSGBUTTON.OLEMSGBUTTON_OK,
                OLEMSGDEFBUTTON.OLEMSGDEFBUTTON_FIRST);
        }
    }
}
