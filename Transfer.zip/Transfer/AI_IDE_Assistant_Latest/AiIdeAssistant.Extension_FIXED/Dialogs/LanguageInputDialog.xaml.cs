using System.Windows;
using System.Windows.Controls;

namespace AiIdeAssistant.Extension.Dialogs
{
    /// <summary>Prompts for the target language before sending an algorithm to the backend.</summary>
    public partial class LanguageInputDialog : Window
    {
        private LanguageInputDialog()
        {
            this.InitializeComponent();
        }

        public static string GetLanguage()
        {
            var dialog = new LanguageInputDialog();
            var result = dialog.ShowDialog();
            if (result != true)
            {
                return null;
            }

            var language = dialog.LanguageComboBox.Text;
            return string.IsNullOrWhiteSpace(language) ? null : language.Trim();
        }

        private void OnOkClicked(object sender, RoutedEventArgs e)
        {
            var selected = this.LanguageComboBox.SelectedItem as ComboBoxItem;
            var language = selected?.Content?.ToString();
            if (string.IsNullOrWhiteSpace(language))
            {
                language = this.LanguageComboBox.Text;
            }

            if (string.IsNullOrWhiteSpace(language))
            {
                MessageBox.Show(this, "Please select or type a programming language.",
                    "Algorithm to Code", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            this.DialogResult = true;
        }

        private void OnCancelClicked(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
        }
    }
}
