using System.Windows;
using EnvDTE;

namespace AiIdeAssistant.Extension.Dialogs
{
    /// <summary>
    /// SRS FR-SAFE-1/2/3: the assistant never overwrites code automatically.
    /// This window is the only place a code action's result can reach a file,
    /// and only via an explicit click.
    ///
    /// Known limitation, disclosed rather than silently risked: "Replace
    /// Selection" re-reads the *current* selection in the *current* active
    /// document at the moment the button is clicked and only proceeds if it
    /// still matches the text that was originally sent to the backend. There
    /// is no tracked span (that needs the ITrackingSpan editor APIs, not DTE,
    /// and is a reasonable Phase 15 hardening item) — if the developer has
    /// changed the selection or switched documents in the meantime, this
    /// aborts with a warning instead of silently editing the wrong text.
    /// </summary>
    public partial class CodeActionResultWindow : System.Windows.Window
    {
        private readonly TextSelection originatingSelection;
        private readonly string originalSelectedCode;
        private readonly string resultText;

        private CodeActionResultWindow(
            string actionDisplayName,
            string resultText,
            bool canReplaceSelection,
            TextSelection originatingSelection,
            string originalSelectedCode)
        {
            this.InitializeComponent();

            this.resultText = resultText;
            this.originatingSelection = originatingSelection;
            this.originalSelectedCode = originalSelectedCode;

            this.HeaderText.Text = actionDisplayName;
            this.ResultTextBox.Text = resultText;
            this.ReplaceSelectionButton.Visibility = canReplaceSelection ? Visibility.Visible : Visibility.Collapsed;
        }

        /// <param name="canReplaceSelection">
        /// False for actions whose result isn't a drop-in replacement for the
        /// original selection (Explain Code, Evaluate Code, Generate Tests —
        /// tests belong in a different location, not in place of the
        /// selection). True for Modify, Optimize, Fix Errors, Refactor, and
        /// Generate Documentation.
        /// </param>
        public static void ShowResult(
            System.Windows.Window owner,
            string actionDisplayName,
            string resultText,
            bool canReplaceSelection,
            TextSelection originatingSelection,
            string originalSelectedCode)
        {
            var window = new CodeActionResultWindow(
                actionDisplayName, resultText, canReplaceSelection, originatingSelection, originalSelectedCode)
            {
                Owner = owner,
            };
            window.ShowDialog();
        }

        private void OnCopyClicked(object sender, RoutedEventArgs e)
        {
            Clipboard.SetText(this.resultText);
        }

        private void OnReplaceSelectionClicked(object sender, RoutedEventArgs e)
        {
            if (this.originatingSelection == null)
            {
                MessageBox.Show(
                    this,
                    "The original document is no longer available.",
                    "AI Assistant",
                    MessageBoxButton.OK,
                    MessageBoxImage.Warning);
                return;
            }

            // Safety guard: only replace if the selection still matches what
            // was actually sent to the backend.
            if (this.originatingSelection.Text != this.originalSelectedCode)
            {
                MessageBox.Show(
                    this,
                    "The selection in the editor has changed since this request was sent, " +
                    "so nothing was replaced. Use Copy and paste manually if you still want this result.",
                    "AI Assistant",
                    MessageBoxButton.OK,
                    MessageBoxImage.Warning);
                return;
            }

            this.originatingSelection.Text = this.resultText;
            this.Close();
        }
    }
}
