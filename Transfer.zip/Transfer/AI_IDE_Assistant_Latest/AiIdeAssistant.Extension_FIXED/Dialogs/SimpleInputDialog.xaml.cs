using System.Windows;

namespace AiIdeAssistant.Extension.Dialogs
{
    public partial class SimpleInputDialog : Window
    {
        private SimpleInputDialog()
        {
            this.InitializeComponent();
        }

        /// <summary>
        /// Shows a modal prompt and returns the entered text, or null if the
        /// user cancelled or entered nothing.
        /// </summary>
        public static string Show(string title, string prompt)
        {
            var dialog = new SimpleInputDialog
            {
                Title = title,
            };
            dialog.PromptText.Text = prompt;

            var result = dialog.ShowDialog();
            if (result != true)
            {
                return null;
            }

            var text = dialog.InputTextBox.Text;
            return string.IsNullOrWhiteSpace(text) ? null : text;
        }

        private void OnOkClicked(object sender, RoutedEventArgs e)
        {
            this.DialogResult = true;
        }

        private void OnCancelClicked(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
        }
    }
}
