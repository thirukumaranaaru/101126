using System;

namespace AiIdeAssistant.Extension.Models
{
    /// <summary>
    /// One entry in the history sidebar. Deliberately does not carry the
    /// full message list — ChatHistoryStore keeps summaries (this type) and
    /// full session content in separate files so listing history doesn't
    /// require reading every session's full transcript off disk.
    /// </summary>
    public class ChatSessionSummary
    {
        public string Id { get; set; }
        public string Title { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime UpdatedAt { get; set; }
    }
}
