using System.Collections.Generic;
using Newtonsoft.Json;

namespace AiIdeAssistant.Extension.Models
{
    /// <summary>
    /// These three classes mirror app/models/schemas.py field-for-field
    /// (role/content, message/history, reply/history). If the backend schema
    /// changes, these must change with it — they are intentionally kept
    /// separate from ChatMessage (the UI-facing model with Author/IsFromUser)
    /// so a wire-format change doesn't ripple into the WPF bindings.
    /// </summary>
    internal class ChatMessageDto
    {
        [JsonProperty("role")]
        public string Role { get; set; }

        [JsonProperty("content")]
        public string Content { get; set; }
    }

    internal class ChatRequestDto
    {
        [JsonProperty("message")]
        public string Message { get; set; }

        [JsonProperty("history")]
        public List<ChatMessageDto> History { get; set; } = new List<ChatMessageDto>();
    }

    internal class ChatResponseDto
    {
        [JsonProperty("reply")]
        public string Reply { get; set; }

        [JsonProperty("history")]
        public List<ChatMessageDto> History { get; set; } = new List<ChatMessageDto>();
    }
}
