using Newtonsoft.Json;

namespace AiIdeAssistant.Extension.Models
{
    /// <summary>
    /// Mirrors backend/app/models/schemas.py's CodeActionRequest/CodeActionResponse
    /// field-for-field (action/code/language/file_name/instruction/compiler_error,
    /// result). Kept separate from ChatRequestDto/ChatResponseDto since this is a
    /// different endpoint with a different shape.
    /// </summary>
    internal class CodeActionRequestDto
    {
        [JsonProperty("action")]
        public string Action { get; set; }

        [JsonProperty("code")]
        public string Code { get; set; }

        [JsonProperty("language")]
        public string Language { get; set; }

        [JsonProperty("file_name")]
        public string FileName { get; set; }

        [JsonProperty("project_name")]
        public string ProjectName { get; set; }

        [JsonProperty("cursor_position")]
        public int? CursorPosition { get; set; }

        [JsonProperty("instruction")]
        public string Instruction { get; set; }

        [JsonProperty("compiler_error")]
        public string CompilerError { get; set; }
    }

    internal class CodeActionResponseDto
    {
        [JsonProperty("result")]
        public string Result { get; set; }
    }
}
