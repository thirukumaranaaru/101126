using System;
using System.Runtime.InteropServices;
using System.Threading.Tasks;
using EnvDTE;
using Microsoft.VisualStudio.Shell;

namespace AiIdeAssistant.Extension.ToolWindows
{
    [Guid(PackageGuids.CodeActionToolWindowGuidString)]
    public sealed class CodeActionToolWindow : ToolWindowPane
    {
        private readonly CodeActionToolWindowControl control;

        public CodeActionToolWindow() : base(null)
        {
            this.Caption = "AI Code Action";
            this.control = new CodeActionToolWindowControl();
            this.Content = this.control;
        }

        public static async Task ShowResultAsync(
            AsyncPackage package,
            string actionDisplayName,
            string resultText,
            bool canReplaceSelection,
            TextSelection originatingSelection,
            string originalSelectedCode,
            bool insertBelowSelection,
            bool insertAboveSelection)
        {
            await ThreadHelper.JoinableTaskFactory.SwitchToMainThreadAsync(package.DisposalToken);
            var window = await package.ShowToolWindowAsync(
                typeof(CodeActionToolWindow), 0, true, package.DisposalToken) as CodeActionToolWindow;
            if (window?.Frame == null) throw new NotSupportedException("Cannot create the AI Code Action tool window.");

            window.control.SetResult(actionDisplayName, resultText, canReplaceSelection,
                originatingSelection, originalSelectedCode, insertBelowSelection, insertAboveSelection);
        }
    }
}
