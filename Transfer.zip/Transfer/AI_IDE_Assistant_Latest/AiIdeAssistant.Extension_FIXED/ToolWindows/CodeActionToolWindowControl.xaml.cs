using System.Windows;
using System.Windows.Controls;
using EnvDTE;

namespace AiIdeAssistant.Extension.ToolWindows
{
    public partial class CodeActionToolWindowControl : UserControl
    {
        private TextSelection originatingSelection;
        private string originalSelectedCode;
        private string resultText;
        private bool insertBelowSelection;
        private bool insertAboveSelection;

        public CodeActionToolWindowControl()
        {
            this.InitializeComponent();
        }

        public void SetResult(string actionDisplayName, string result, bool canReplaceSelection,
            TextSelection selection, string originalCode, bool insertBelow, bool insertAbove)
        {
            this.HeaderText.Text = actionDisplayName;
            this.resultText = result ?? string.Empty;
            this.ResultTextBox.Text = this.resultText;
            this.originatingSelection = selection;
            this.originalSelectedCode = originalCode;
            this.insertBelowSelection = insertBelow;
            this.insertAboveSelection = insertAbove;
            this.ActionButton.Visibility = (canReplaceSelection || insertBelow || insertAbove)
                ? Visibility.Visible : Visibility.Collapsed;
            this.ActionButton.Content = insertBelow ? "Insert Code Below Selection"
                : insertAbove ? "Insert Algorithm Above Selection"
                : "Apply Changes (Replace Selection)";
            this.ResultTextBox.Focus();
            this.ResultTextBox.SelectAll();
        }

        private void OnReplaceSelectionClicked(object sender, RoutedEventArgs e)
        {
            if (this.originatingSelection == null)
            {
                MessageBox.Show("The original document is no longer available.", "AI Assistant",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            if (this.originatingSelection.Text != this.originalSelectedCode)
            {
                MessageBox.Show("The editor selection changed since this request was sent, so nothing was replaced.",
                    "AI Assistant", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            if (this.insertBelowSelection)
            {
                this.originatingSelection.MoveToPoint(this.originatingSelection.BottomPoint);
                this.originatingSelection.Insert(System.Environment.NewLine + this.resultText);
            }
            else if (this.insertAboveSelection)
            {
                this.originatingSelection.MoveToPoint(this.originatingSelection.TopPoint);
                this.originatingSelection.Insert(this.resultText + System.Environment.NewLine);
            }
            else
            {
                this.originatingSelection.Text = this.resultText;
            }
        }

        private void OnClearClicked(object sender, RoutedEventArgs e)
        {
            this.HeaderText.Text = string.Empty;
            this.ResultTextBox.Clear();
            this.ActionButton.Visibility = Visibility.Collapsed;
            this.originatingSelection = null;
            this.originalSelectedCode = null;
            this.resultText = null;
        }
    }
}
