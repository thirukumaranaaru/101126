using System;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Media;

namespace AiIdeAssistant.Extension.ToolWindows
{
    /// <summary>
    /// Lightweight offline syntax presentation for fenced and code-shaped
    /// assistant output. It deliberately has no web control, CDN, or runtime
    /// dependency. Language-aware parsing can be substituted later without
    /// changing the chat view contract.
    /// </summary>
    public sealed class SyntaxHighlightedTextBlock : TextBlock
    {
        private static readonly Regex TokenPattern = new Regex(
            "\\b(public|private|protected|internal|class|interface|static|async|await|return|if|else|for|while|foreach|try|catch|throw|using|namespace|def|import|from|function|const|let|var|new|true|false|null|None)\\b|\\b\\d+(?:\\.\\d+)?\\b|\"(?:\\\\.|[^\"\\\\])*\"|'(?:\\\\.|[^'\\\\])*'",
            RegexOptions.Compiled);

        public static readonly DependencyProperty ContentProperty = DependencyProperty.Register(
            "Content", typeof(string), typeof(SyntaxHighlightedTextBlock),
            new PropertyMetadata(string.Empty, OnContentChanged));

        public string Content
        {
            get { return (string)this.GetValue(ContentProperty); }
            set { this.SetValue(ContentProperty, value); }
        }

        private static void OnContentChanged(DependencyObject dependencyObject, DependencyPropertyChangedEventArgs e)
        {
            ((SyntaxHighlightedTextBlock)dependencyObject).RenderContent((string)e.NewValue ?? string.Empty);
        }

        private void RenderContent(string value)
        {
            this.Inlines.Clear();
            var codeShaped = value.Contains("```") || value.Contains("{") || value.Contains(";") || value.Contains("def ");
            this.Background = codeShaped ? new SolidColorBrush(Color.FromRgb(248, 248, 248)) : Brushes.Transparent;
            this.FontFamily = new FontFamily(codeShaped ? "Consolas" : "Segoe UI");

            var position = 0;
            foreach (Match match in TokenPattern.Matches(value))
            {
                if (match.Index > position) this.Inlines.Add(new Run(value.Substring(position, match.Index - position)));
                var run = new Run(match.Value);
                if (match.Value.StartsWith("\"") || match.Value.StartsWith("'")) run.Foreground = Brushes.DarkRed;
                else if (char.IsDigit(match.Value[0])) run.Foreground = Brushes.DarkCyan;
                else run.Foreground = Brushes.DarkBlue;
                run.FontWeight = FontWeights.SemiBold;
                this.Inlines.Add(run);
                position = match.Index + match.Length;
            }
            if (position < value.Length) this.Inlines.Add(new Run(value.Substring(position)));
        }
    }
}
