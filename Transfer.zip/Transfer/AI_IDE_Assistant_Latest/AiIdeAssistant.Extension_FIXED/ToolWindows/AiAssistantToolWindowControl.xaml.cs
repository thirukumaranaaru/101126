using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using AiIdeAssistant.Extension.Models;
using AiIdeAssistant.Extension.ViewModels;

namespace AiIdeAssistant.Extension.ToolWindows
{
    public partial class AiAssistantToolWindowControl : UserControl
    {
        private readonly ChatViewModel viewModel;

        public AiAssistantToolWindowControl()
        {
            this.InitializeComponent();
            this.viewModel = new ChatViewModel();
            this.DataContext = this.viewModel;
        }

        private void OnNewChatClicked(object sender, RoutedEventArgs e)
        {
            this.viewModel.StartNewChat();
        }

        private async void OnToggleHistoryClicked(object sender, RoutedEventArgs e)
        {
            this.viewModel.IsHistoryVisible = !this.viewModel.IsHistoryVisible;
            if (this.viewModel.IsHistoryVisible)
            {
                // Refresh in case another session was saved since this panel
                // was opened (e.g. a previous conversation from earlier today).
                await this.viewModel.LoadSessionsAsync();
            }
        }

        private async void OnSessionSelected(object sender, SelectionChangedEventArgs e)
        {
            if (e.AddedItems.Count > 0 && e.AddedItems[0] is ChatSessionSummary summary)
            {
                await this.viewModel.SelectSessionAsync(summary);
            }
        }

        private async void OnSendClicked(object sender, RoutedEventArgs e)
        {
            await this.viewModel.SendCurrentInputAsync();
        }

        // Enter sends the message; Shift+Enter keeps the TextBox's normal
        // newline behavior. PreviewKeyDown is used because AcceptsReturn is true.
        private async void OnInputBoxPreviewKeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter && (Keyboard.Modifiers & ModifierKeys.Shift) == ModifierKeys.Shift)
            {
                // Let WPF insert a newline for Shift+Enter.
                return;
            }

            if (e.Key == Key.Enter && (Keyboard.Modifiers & ModifierKeys.Control) != ModifierKeys.Control)
            {
                e.Handled = true;
                await this.viewModel.SendCurrentInputAsync();
            }
        }

        private async void OnRenameSessionClicked(object sender, RoutedEventArgs e)
        {
            if (!(sender is Button button) || !(button.Tag is ChatSessionSummary summary)) return;
            var title = Dialogs.SimpleInputDialog.Show("Rename Chat", "Enter a new chat name:");
            if (!string.IsNullOrWhiteSpace(title)) await this.viewModel.RenameSessionAsync(summary, title);
        }

        private async void OnDeleteSessionClicked(object sender, RoutedEventArgs e)
        {
            if (!(sender is Button button) || !(button.Tag is ChatSessionSummary summary)) return;
            var result = MessageBox.Show("Delete this chat history?", "AI Assistant",
                MessageBoxButton.YesNo, MessageBoxImage.Warning);
            if (result == MessageBoxResult.Yes) await this.viewModel.DeleteSessionAsync(summary);
        }
    }
}
