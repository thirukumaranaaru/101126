using System;
using System.Runtime.InteropServices;
using Microsoft.VisualStudio.Shell;
using Task = System.Threading.Tasks.Task;

namespace AiIdeAssistant.Extension.ToolWindows
{
    /// <summary>
    /// The dockable "AI Assistant" panel (SRS FR-GA-2, FR-PANEL-1..5).
    /// Phase 3 wires this up with a self-contained mock ChatViewModel;
    /// Phase 4/5 point SendCurrentInputAsync at the real backend instead.
    /// </summary>
    [Guid(PackageGuids.ToolWindowGuidString)]
    public class AiAssistantToolWindow : ToolWindowPane
    {
        public AiAssistantToolWindow() : base(null)
        {
            this.Caption = "AI Assistant";
            this.Content = new AiAssistantToolWindowControl();
        }

        public static async Task ShowAsync(AsyncPackage package)
        {
            await ThreadHelper.JoinableTaskFactory.SwitchToMainThreadAsync(package.DisposalToken);

            ToolWindowPane window = await package.ShowToolWindowAsync(
                typeof(AiAssistantToolWindow),
                id: 0,
                create: true,
                cancellationToken: package.DisposalToken);

            if (window?.Frame == null)
            {
                throw new NotSupportedException("Cannot create the AI Assistant tool window.");
            }
        }
    }
}
