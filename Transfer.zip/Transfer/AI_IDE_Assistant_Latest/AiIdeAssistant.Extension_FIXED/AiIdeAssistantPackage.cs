using System;
using System.Runtime.InteropServices;
using System.Threading;
using AiIdeAssistant.Extension.Commands;
using AiIdeAssistant.Extension.ToolWindows;
using Microsoft.VisualStudio.Shell;
using Task = System.Threading.Tasks.Task;

namespace AiIdeAssistant.Extension
{
    // Phase 1: bare AsyncPackage, no menu/tool window yet.
    // Phase 2 adds: [ProvideMenuResource] + AskAiCommand.InitializeAsync call.
    // Phase 3 adds: [ProvideToolWindow].
    // Phase 7/8 adds: ContextMenuCommands.InitializeAsync call.
    [PackageRegistration(UseManagedResourcesOnly = true, AllowsBackgroundLoading = true)]
    [Guid(PackageGuids.PackageGuidString)]
    [InstalledProductRegistration(
        "AI IDE Assistant",
        "Offline AI coding assistant for Microsoft Visual Studio, backed by an internal RAG-augmented Llama 3 8B service.",
        "0.1")]
    [ProvideMenuResource("Menus.ctmenu", 1)]
    [ProvideToolWindow(typeof(AiAssistantToolWindow))]
    [ProvideToolWindow(typeof(CodeActionToolWindow))]
    public sealed class AiIdeAssistantPackage : AsyncPackage
    {
        protected override async Task InitializeAsync(CancellationToken cancellationToken, IProgress<ServiceProgressData> progress)
        {
            // Switch to the UI thread before touching any VS UI services, per the
            // standard AsyncPackage pattern.
            await this.JoinableTaskFactory.SwitchToMainThreadAsync(cancellationToken);

            // Phase 2: registers the "Ask AI" command with the shell.
            await AskAiCommand.InitializeAsync(this);

            // Phase 7/8: registers the 8 editor context-menu code actions.
            await ContextMenuCommands.InitializeAsync(this);
        }
    }
}
