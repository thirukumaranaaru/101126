using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("AiIdeAssistant.Extension")]
[assembly: AssemblyDescription("Offline AI coding assistant for Microsoft Visual Studio")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("AiIdeAssistant.Extension")]
[assembly: AssemblyCopyright("")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: AssemblyVersion("0.1.0.0")]
[assembly: AssemblyFileVersion("0.1.0.0")]
