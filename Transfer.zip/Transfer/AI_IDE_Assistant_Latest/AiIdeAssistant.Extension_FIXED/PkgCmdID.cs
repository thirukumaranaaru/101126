namespace AiIdeAssistant.Extension
{
    /// <summary>
    /// Numeric command IDs. Must match the &lt;IDSymbol&gt; values in
    /// AiIdeAssistantPackage.vsct exactly.
    /// </summary>
    internal static class PkgCmdIDList
    {
        public const int cmdidAskAi = 0x0100;
        public const int cmdidAskAiToolbar = 0x0101;

        // Phase 7/8: editor context-menu code actions (SRS FR-CTX-2).
        public const int cmdidExplainCode = 0x0110;
        public const int cmdidEvaluateCode = 0x0111;
        public const int cmdidModifyCode = 0x0112;
        public const int cmdidOptimizeCode = 0x0113;
        public const int cmdidFixErrors = 0x0114;
        public const int cmdidGenerateDocumentation = 0x0115;
        public const int cmdidGenerateTests = 0x0116;
        public const int cmdidRefactorCode = 0x0117;
        public const int cmdidAlgorithmToCode = 0x0118;
        public const int cmdidCodeToAlgorithm = 0x0119;
        public const int cmdidDirectFixErrors = 0x011A;
    }
}
