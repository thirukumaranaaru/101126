# AI IDE Assistant - Visual Studio 2022 extension source (direct backend)

## What this edition contains

- Ask AI command and dedicated toolbar.
- Dockable chat tool window and local chat history.
- Editor right-click > Ask AI submenu with Explain Code, Evaluate Code, Fix Errors, Direct Fix Errors, Algorithm to Code, and Code to Algorithm.
- Direct HTTP calls to the existing backend: `POST /api/chat` and `POST /api/code-action`.
- Dockable code-action result panel with selectable output and guarded replacement/insertion actions.
- Rename and delete controls for locally stored chat sessions.
- **No Keycloak/OIDC login flow in the IDE extension.** Keycloak and the backend infrastructure are not changed by this source package.

## Build status

This archive contains source, not a prebuilt VSIX. Build it on a Windows PC with Visual Studio 2022, the Visual Studio extension workload, .NET Framework 4.7.2 targeting pack, and NuGet package restore. Run `BUILD_ONLINE_PC.ps1` from PowerShell. The generated VSIX must be tested before deployment.

## Backend URL

Default: `http://192.168.1.150:8000`

Optional user environment variable: `AI_IDE_ASSISTANT_BACKEND_URL`. Use `http://localhost:8000` only when the backend is reachable on the same PC as Visual Studio; use the server's LAN address for a separate client PC.

The backend must accept unauthenticated requests from this extension for direct chat to work. This extension does not attach a Bearer token. If the backend returns 401/403, do not assume the IDE source alone can override backend authentication; review backend policy and network restrictions.

## Build and install

1. Open `AiIdeAssistant.Extension.sln` in Visual Studio 2022.
2. Restore NuGet packages.
3. Choose Release / Any CPU and rebuild.
4. Locate `bin\Release\AiIdeAssistant.Extension.vsix` or use the output path printed by `BUILD_ONLINE_PC.ps1`.
5. Test the VSIX on the build PC before transferring it.
6. Close Visual Studio, install the new VSIX, and reopen Visual Studio.

## Security note

No IDE sign-in means requests are unauthenticated at the extension layer. Use only on a trusted LAN and restrict backend access with firewall/network controls or another suitable access-control mechanism. HTTP is not encrypted; configure TLS before broader deployment.
