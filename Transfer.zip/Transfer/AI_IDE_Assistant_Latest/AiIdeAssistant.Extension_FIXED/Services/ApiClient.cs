using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using AiIdeAssistant.Extension.Models;
using Newtonsoft.Json;

namespace AiIdeAssistant.Extension.Services
{
    /// <summary>
    /// The extension's HTTP client to the Python backend (SRS FR-GA-5, FR-CTX-4/5).
    /// Talks only to the LAN address from BackendConfiguration — never a
    /// hardcoded internet endpoint, per EC-1 through EC-8.
    /// </summary>
    internal sealed class ApiClient : IDisposable
    {
        private readonly HttpClient httpClient;

        public ApiClient()
        {
            this.httpClient = new HttpClient
            {
                BaseAddress = new Uri(BackendConfiguration.GetBaseUrl()),
                Timeout = TimeSpan.FromSeconds(60),
            };
        }

        public Task<ChatResponseDto> SendChatAsync(string message, List<ChatMessageDto> history)
        {
            var requestBody = new ChatRequestDto { Message = message, History = history };
            return this.PostJsonAsync<ChatResponseDto>("/api/chat", requestBody);
        }

        /// <summary>
        /// Sends a code action to the existing backend. `instruction` and
        /// `compilerError` are optional context fields used by supported actions.
        /// </summary>
        public Task<CodeActionResponseDto> SendCodeActionAsync(
            string action,
            string code,
            string language,
            string fileName,
            string projectName,
            int? cursorPosition,
            string instruction = null,
            string compilerError = null)
        {
            var requestBody = new CodeActionRequestDto
            {
                Action = action,
                Code = code,
                Language = language,
                FileName = fileName,
                ProjectName = projectName,
                CursorPosition = cursorPosition,
                Instruction = instruction,
                CompilerError = compilerError,
            };
            return this.PostJsonAsync<CodeActionResponseDto>("/api/code-action", requestBody);
        }

        private async Task<TResponse> PostJsonAsync<TResponse>(string path, object requestBody)
        {
            var json = JsonConvert.SerializeObject(requestBody);

            using (var request = new HttpRequestMessage(HttpMethod.Post, path))
            using (var content = new StringContent(json, Encoding.UTF8, "application/json"))
            {
                request.Content = content;
                using (var response = await this.httpClient.SendAsync(request).ConfigureAwait(false))
                {
                    var responseText = await response.Content.ReadAsStringAsync().ConfigureAwait(false);

                    if (!response.IsSuccessStatusCode)
                    {
                        throw new ApiClientException(
                            $"Backend returned {(int)response.StatusCode} {response.ReasonPhrase}: {responseText}");
                    }

                    return JsonConvert.DeserializeObject<TResponse>(responseText);
                }
            }
        }

        public void Dispose() => this.httpClient.Dispose();
    }

    internal sealed class ApiClientException : Exception
    {
        public ApiClientException(string message) : base(message)
        {
        }
    }
}
