using System;

namespace AiIdeAssistant.Extension.Services
{
    /// <summary>
    /// SRS FR-INFRA-1: the backend address must be externally configurable,
    /// never hardcoded. This minimal version reads an environment variable
    /// with a localhost default. A Tools &gt; Options settings page is a
    /// reasonable follow-up (Phase 15 hardening) but isn't required for
    /// Phase 6's acceptance criteria, and adding one now — with a
    /// DialogPage, a settings store, and its own UI — would be new surface
    /// area this phase doesn't need.
    /// </summary>
    internal static class BackendConfiguration
    {
        private const string EnvironmentVariableName = "AI_IDE_ASSISTANT_BACKEND_URL";
        private const string DefaultBaseUrl = "http://192.168.1.150:8000";

        public static string GetBaseUrl()
        {
            var configured = Environment.GetEnvironmentVariable(EnvironmentVariableName);
            return string.IsNullOrWhiteSpace(configured) ? DefaultBaseUrl : configured.TrimEnd('/');
        }
    }
}
