using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using AiIdeAssistant.Extension.Models;
using Newtonsoft.Json;

namespace AiIdeAssistant.Extension.Services
{
    /// <summary>
    /// Persists chat sessions as local JSON files under
    /// %APPDATA%\AiIdeAssistant\history\ — one file per session plus an
    /// index.json of summaries. Deliberately client-local: there is no
    /// authenticated user identity yet (Phase 12) and no backend database
    /// (Phase 13), so anything server-side would have to invent both just
    /// for this feature. This can move server-side later without changing
    /// ChatViewModel's public surface.
    ///
    /// Known limitation, disclosed rather than engineered around: no file
    /// locking. Two Visual Studio instances saving history at the same
    /// moment can lose one of the two index updates (last write wins).
    /// Acceptable for a single-developer local tool.
    ///
    /// Uses Task.Run around synchronous File I/O rather than
    /// File.ReadAllTextAsync/WriteAllTextAsync — those methods don't exist
    /// in .NET Framework 4.7.2 (added later, in .NET Standard 2.1).
    /// </summary>
    internal sealed class ChatHistoryStore
    {
        private const string IndexFileName = "index.json";

        private readonly string historyDirectory;

        public ChatHistoryStore()
        {
            var appData = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
            this.historyDirectory = Path.Combine(appData, "AiIdeAssistant", "history");
        }

        private string SessionFilePath(string sessionId) => Path.Combine(this.historyDirectory, sessionId + ".json");

        private string IndexFilePath => Path.Combine(this.historyDirectory, IndexFileName);

        public Task<List<ChatSessionSummary>> LoadSessionSummariesAsync()
        {
            return Task.Run(() =>
            {
                var summaries = this.LoadIndexSync();
                return summaries.OrderByDescending(s => s.UpdatedAt).ToList();
            });
        }

        public Task<List<ChatMessage>> LoadSessionMessagesAsync(string sessionId)
        {
            return Task.Run(() =>
            {
                try
                {
                    var path = this.SessionFilePath(sessionId);
                    if (!File.Exists(path))
                    {
                        return new List<ChatMessage>();
                    }

                    var json = File.ReadAllText(path);
                    var session = JsonConvert.DeserializeObject<PersistedSession>(json);
                    return session?.Messages ?? new List<ChatMessage>();
                }
                catch
                {
                    // A corrupt or unreadable session file must not crash the
                    // panel — that one session becomes unavailable, not fatal.
                    return new List<ChatMessage>();
                }
            });
        }

        /// <summary>
        /// Upserts both the full session file and its index entry. Returns
        /// false (rather than throwing) if the write failed — the caller
        /// shows a status message and carries on; a history write failure
        /// must never break the chat itself.
        /// </summary>
        public Task<bool> SaveSessionAsync(string sessionId, string title, DateTime createdAt, List<ChatMessage> messages)
        {
            return Task.Run(() =>
            {
                try
                {
                    Directory.CreateDirectory(this.historyDirectory);

                    var updatedAt = DateTime.UtcNow;
                    var session = new PersistedSession
                    {
                        Id = sessionId,
                        Title = title,
                        CreatedAt = createdAt,
                        UpdatedAt = updatedAt,
                        Messages = messages,
                    };
                    File.WriteAllText(
                        this.SessionFilePath(sessionId),
                        JsonConvert.SerializeObject(session, Formatting.Indented));

                    var summaries = this.LoadIndexSync();
                    summaries.RemoveAll(s => s.Id == sessionId);
                    summaries.Add(new ChatSessionSummary
                    {
                        Id = sessionId,
                        Title = title,
                        CreatedAt = createdAt,
                        UpdatedAt = updatedAt,
                    });
                    File.WriteAllText(
                        this.IndexFilePath,
                        JsonConvert.SerializeObject(summaries, Formatting.Indented));

                    return true;
                }
                catch
                {
                    return false;
                }
            });
        }

        public Task<bool> RenameSessionAsync(string sessionId, string title)
        {
            return Task.Run(() =>
            {
                try
                {
                    var summaries = this.LoadIndexSync();
                    var summary = summaries.FirstOrDefault(s => s.Id == sessionId);
                    if (summary == null || string.IsNullOrWhiteSpace(title)) return false;
                    summary.Title = title.Trim();
                    File.WriteAllText(this.IndexFilePath, JsonConvert.SerializeObject(summaries, Formatting.Indented));

                    var path = this.SessionFilePath(sessionId);
                    if (File.Exists(path))
                    {
                        var session = JsonConvert.DeserializeObject<PersistedSession>(File.ReadAllText(path));
                        if (session != null)
                        {
                            session.Title = summary.Title;
                            File.WriteAllText(path, JsonConvert.SerializeObject(session, Formatting.Indented));
                        }
                    }
                    return true;
                }
                catch { return false; }
            });
        }

        public Task<bool> DeleteSessionAsync(string sessionId)
        {
            return Task.Run(() =>
            {
                try
                {
                    var summaries = this.LoadIndexSync();
                    var removed = summaries.RemoveAll(s => s.Id == sessionId) > 0;
                    var path = this.SessionFilePath(sessionId);
                    if (File.Exists(path)) File.Delete(path);
                    if (removed && File.Exists(this.IndexFilePath))
                    {
                        File.WriteAllText(this.IndexFilePath, JsonConvert.SerializeObject(summaries, Formatting.Indented));
                    }
                    return removed;
                }
                catch { return false; }
            });
        }

        private List<ChatSessionSummary> LoadIndexSync()
        {
            try
            {
                if (!File.Exists(this.IndexFilePath))
                {
                    return new List<ChatSessionSummary>();
                }

                var json = File.ReadAllText(this.IndexFilePath);
                return JsonConvert.DeserializeObject<List<ChatSessionSummary>>(json) ?? new List<ChatSessionSummary>();
            }
            catch
            {
                return new List<ChatSessionSummary>();
            }
        }

        private sealed class PersistedSession
        {
            public string Id { get; set; }
            public string Title { get; set; }
            public DateTime CreatedAt { get; set; }
            public DateTime UpdatedAt { get; set; }
            public List<ChatMessage> Messages { get; set; }
        }
    }
}
