# Online PC -> offline office PC deployment checklist (direct backend edition)

## A. Internet-connected PC: create Visual Studio layout

Use the Visual Studio 2022 Community bootstrapper `vs_Community.exe` for VS 2022. Open an elevated Command Prompt in the directory containing it.

```bat
mkdir C:\VS2022_Offline
vs_Community.exe --layout C:\VS2022_Offline --lang en-US
```

For a selected workload layout:

```bat
vs_Community.exe --layout C:\VS2022_Offline --lang en-US ^
 --add Microsoft.VisualStudio.Workload.ManagedDesktop ^
 --add Microsoft.VisualStudio.Workload.VisualStudioExtension ^
 --add Microsoft.VisualStudio.Workload.NativeDesktop ^
 --add Microsoft.VisualStudio.Workload.NetWeb ^
 --includeRecommended --includeOptional
```

## B. Build and test extension on the online PC

1. Install Visual Studio 2022 with the Visual Studio extension workload and .NET Framework 4.7.2 targeting pack.
2. Extract this ZIP.
3. Set the backend URL if needed: `powershell -ExecutionPolicy Bypass -File .\SET_USER_ENVIRONMENT.ps1 -BackendUrl 'http://192.168.1.150:8000'`.
4. Run `powershell -ExecutionPolicy Bypass -File .\BUILD_ONLINE_PC.ps1`.
5. Install the generated VSIX on the build PC and test all features if the backend is reachable.
6. Copy the generated VSIX from the `Output` folder to the approved transfer drive.

## C. Office PC: install Visual Studio offline

If you created a layout, install from it with `--noWeb` and select only components present in the layout. Follow Microsoft's certificate instructions if signature errors occur; do not disable signature validation.

## D. Office PC: install the new extension

1. Close all Visual Studio windows.
2. Open **Extensions > Manage Extensions > Installed** and uninstall the existing AI IDE Assistant extension. If it is not listed there, run the VSIX Installer/uninstaller for the old VSIX.
3. Restart Visual Studio if prompted, then close it again.
4. Double-click the newly built `AiIdeAssistant.Extension.vsix` and install it for Visual Studio 2022.
5. Reopen Visual Studio. If the toolbar is hidden, use **View > Toolbars > AI IDE Assistant**.

## E. Configure backend URL

On the PC where Visual Studio runs, set the URL to the backend's reachable address:

```powershell
[Environment]::SetEnvironmentVariable('AI_IDE_ASSISTANT_BACKEND_URL','http://192.168.1.150:8000','User')
```

Use `http://localhost:8000` only if the backend runs on the same PC. Close and reopen Visual Studio after changing the variable. No Keycloak/OIDC environment variables are required by this extension edition. Keycloak remains in Docker and its configuration is not changed.

## F. Connectivity and acceptance tests

```powershell
Test-NetConnection 192.168.1.150 -Port 8000
Invoke-WebRequest http://192.168.1.150:8000/health
```

Check that the Ask AI toolbar opens the chat panel, a normal chat question gets a response, chat history can be reopened, and Explain Code / Evaluate Code / Fix Errors work from the editor context menu. Verify Copy/Replace/Cancel behavior on code actions.

If the backend returns 401/403, the backend still enforces authentication; removing IDE OIDC alone cannot bypass it. Review the backend's intended authentication policy and restrict network access appropriately. If it returns 404, verify the API route; if connection fails, verify Docker port publishing, firewall, and LAN routing.

## Security

This edition sends requests without a Bearer token. Use only on a trusted LAN and restrict backend access to approved machines. HTTP is unencrypted; use TLS before wider deployment. This archive is source, not a prebuilt VSIX. Build and test before deployment.
