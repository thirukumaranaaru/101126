# AI IDE Assistant offline transfer package — direct backend edition

Contents:
- `AiIdeAssistant.Extension_FIXED/`: Visual Studio extension source.
- `BUILD_ONLINE_PC.ps1`: restores NuGet packages and builds a Release VSIX on the internet-connected Windows PC.
- `SET_USER_ENVIRONMENT.ps1`: sets only the backend URL for the Windows user.
- `OFFLINE_DEPLOYMENT_GUIDE.md`: build, transfer, install, and test instructions.
- `vs2022-workloads.vsconfig`: Visual Studio workload list.

This edition removes Keycloak/OIDC from the IDE extension's request path. Keycloak and all backend Docker services are left unchanged. The extension sends direct HTTP requests to the backend without a Bearer token.

Default backend URL: `http://192.168.1.150:8000`. Set another URL with `SET_USER_ENVIRONMENT.ps1 -BackendUrl 'http://localhost:8000'` if Visual Studio and the backend run on the same PC.

**Not precompiled/verified:** Build the source on a Windows PC with Visual Studio 2022 and test it before moving the generated VSIX to the offline office PC. The ZIP is source plus instructions, not a ready-built VSIX.

**Security:** Direct requests are unauthenticated at the extension layer. Keep backend access restricted to trusted machines and ensure backend/network controls match your deployment requirements.

Code-action UI additions:
- Right-click > Ask AI > Fix Errors opens a multiline dialog for the compiler/build error. The error and selected code are sent to POST /api/code-action.
- Right-click > Ask AI > Algorithm to Code opens a language selector (with common languages and custom typing). The selected algorithm and chosen language are sent to POST /api/code-action using action `algorith_to_code`.
- Fix Errors shows the generated result in the existing result window with an explicit Apply Changes (Replace Selection) button. The source selection is replaced only after the user clicks it and only if it still matches the originally selected code.
- This source package has not been compiled in this environment; run BUILD_ONLINE_PC.ps1 on the Windows development PC and test before deployment.
