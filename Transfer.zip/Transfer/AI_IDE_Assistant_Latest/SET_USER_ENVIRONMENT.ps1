param(
  [string]$BackendUrl = 'http://192.168.1.150:8000'
)
$ErrorActionPreference = 'Stop'
if ([string]::IsNullOrWhiteSpace($BackendUrl)) { throw 'BackendUrl cannot be empty.' }
[Environment]::SetEnvironmentVariable('AI_IDE_ASSISTANT_BACKEND_URL',$BackendUrl.TrimEnd('/'),'User')
Write-Host "Saved AI_IDE_ASSISTANT_BACKEND_URL=$BackendUrl for the current Windows user."
Write-Host 'No Keycloak/OIDC variables are required by this IDE extension build.'
Write-Host 'Close ALL Visual Studio windows and reopen Visual Studio so it inherits the new value.'
