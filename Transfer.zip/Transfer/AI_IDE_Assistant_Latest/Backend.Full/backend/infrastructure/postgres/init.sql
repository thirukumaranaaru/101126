-- SRS Section 18 / SDD Section 7. Real DDL for the backend's own
-- PostgreSQL database (Keycloak, per infrastructure/docker-compose.yml,
-- uses its own separate storage — see that file's comments for why).
-- Mounted into the postgres container at
-- /docker-entrypoint-initdb.d/init.sql, so it runs once, automatically,
-- the first time the postgres data volume is created.

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

CREATE TABLE users (
    id                UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    external_subject  TEXT UNIQUE NOT NULL,  -- Keycloak's 'sub' claim
    display_name      TEXT,
    created_at        TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE roles (
    id    UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name  TEXT UNIQUE NOT NULL  -- e.g. developer, rag_admin, security_officer
);

CREATE TABLE user_roles (
    user_id  UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    role_id  UUID NOT NULL REFERENCES roles(id) ON DELETE CASCADE,
    PRIMARY KEY (user_id, role_id)
);

CREATE TABLE documents (
    id             UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    document_name  TEXT NOT NULL,
    category       TEXT,             -- e.g. coding-standard, secure-coding-practice
    priority_tier  INTEGER NOT NULL DEFAULT 0,  -- SRS §7.3 conflict precedence
    UNIQUE (document_name)
);

CREATE TABLE document_versions (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    document_id     UUID NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
    version         TEXT NOT NULL,
    effective_date  DATE,
    status          TEXT NOT NULL DEFAULT 'active'
                    CHECK (status IN ('draft', 'active', 'superseded')),
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (document_id, version)
);

CREATE INDEX idx_document_versions_status ON document_versions(status);

CREATE TABLE audit_events (
    id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id      UUID REFERENCES users(id) ON DELETE SET NULL,
    event_type   TEXT NOT NULL,  -- auth_success, auth_failure, code_action_invoked, admin_change, ...
    occurred_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    detail       JSONB NOT NULL DEFAULT '{}'::jsonb
    -- FR-SEC-6: application code populating `detail` must never include
    -- source code, secrets, or tokens. That is an application-layer
    -- responsibility (app/logging/redaction.py, Phase 15) — this schema
    -- has no way to enforce it at the database level.
);

CREATE INDEX idx_audit_events_occurred_at ON audit_events(occurred_at);
CREATE INDEX idx_audit_events_user_id ON audit_events(user_id);

-- Seed the three roles named in the SDD (SRS §44.4's "Intended Users").
-- Assigning them to actual users happens through Keycloak group/role
-- mapping (Phase 12), not here.
INSERT INTO roles (name) VALUES ('developer'), ('rag_admin'), ('security_officer');
