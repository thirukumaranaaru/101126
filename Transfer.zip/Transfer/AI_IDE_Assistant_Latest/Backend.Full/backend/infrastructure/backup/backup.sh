#!/usr/bin/env bash
# SRS Section 24 / Phase 14: nightly incremental backup of PostgreSQL data,
# Qdrant data, and configuration, targeting approved internal storage
# (EC-3/EC-4: never off the LAN, never off-site to an unapproved location).
#
# Run this from cron on the backend host, e.g.:
#   0 2 * * * /path/to/backup.sh >> /var/log/ai-ide-assistant-backup.log 2>&1
#
# Required environment (put these in a root-only .env file, sourced below —
# never hardcode a password in this script, per FR-SEC-5):
#   RESTIC_REPOSITORY   - e.g. /mnt/backup-storage/ai-ide-assistant
#   RESTIC_PASSWORD     - repository encryption password
#   POSTGRES_HOST, POSTGRES_PORT, POSTGRES_DB, POSTGRES_USER, PGPASSWORD
#   QDRANT_DATA_DIR     - host path backing the qdrant container's storage volume
#   CONFIG_DIR          - host path holding infrastructure/ and any .env files
#
# Verified against restic's actual documented CLI/env vars (RESTIC_REPOSITORY,
# RESTIC_PASSWORD, `restic init`, `restic backup --stdin`, `restic forget
# --prune`) via web search — not executed anywhere in this project, since
# there is no restic binary, Postgres, or Qdrant instance in the sandbox
# this was written in.

set -euo pipefail

ENV_FILE="${AI_IDE_ASSISTANT_BACKUP_ENV:-/etc/ai-ide-assistant/backup.env}"
if [[ -f "$ENV_FILE" ]]; then
    # shellcheck disable=SC1090
    source "$ENV_FILE"
fi

for var in RESTIC_REPOSITORY RESTIC_PASSWORD POSTGRES_HOST POSTGRES_DB POSTGRES_USER QDRANT_DATA_DIR CONFIG_DIR; do
    if [[ -z "${!var:-}" ]]; then
        echo "ERROR: required variable $var is not set (check $ENV_FILE)" >&2
        exit 1
    fi
done

export RESTIC_REPOSITORY RESTIC_PASSWORD

if ! restic snapshots >/dev/null 2>&1; then
    echo "Repository not found or not initialized — running 'restic init'."
    restic init
fi

echo "[$(date -Is)] Backing up PostgreSQL ($POSTGRES_DB)..."
PGPASSWORD="${PGPASSWORD:-}" pg_dump \
    --host="$POSTGRES_HOST" --port="${POSTGRES_PORT:-5432}" \
    --username="$POSTGRES_USER" --dbname="$POSTGRES_DB" \
    --format=plain \
    | restic backup --stdin --stdin-filename "postgres-${POSTGRES_DB}.sql" --tag postgres

echo "[$(date -Is)] Backing up Qdrant data directory..."
restic backup "$QDRANT_DATA_DIR" --tag qdrant

echo "[$(date -Is)] Backing up configuration..."
restic backup "$CONFIG_DIR" --tag config

echo "[$(date -Is)] Pruning old snapshots (retention: 7 daily, 4 weekly, 6 monthly)..."
restic forget --keep-daily 7 --keep-weekly 4 --keep-monthly 6 --prune

echo "[$(date -Is)] Verifying repository integrity..."
restic check

echo "[$(date -Is)] Backup complete."
