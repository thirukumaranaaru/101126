#!/usr/bin/env bash
# Bring up the backend stack with one command. The supplied Compose file uses
# Ollama on the Windows host by default; if an `ollama` Compose service exists,
# this script also supports pulling models into that service.
#
# Usage: ./start.sh
# Run from the infrastructure/ directory (where docker-compose.yml lives).

set -euo pipefail

if [[ ! -f .env ]]; then
    echo "==> .env not found; creating a local configuration from .env.example"
    cp .env.example .env
fi

# Make .env's values available to this script itself, not just to
# docker compose (which reads .env on its own but doesn't export it to
# the calling shell — this script needs LLM_MODEL/EMBEDDING_MODEL/
# RAG_ENABLED directly, below).
set -o allexport
source .env
set +o allexport

echo "==> Starting the stack (this can take a while on first run — image pulls)..."
docker compose up -d

LLM_MODEL="${LLM_MODEL:-llama3:8b}"
EMBEDDING_MODEL="${EMBEDDING_MODEL:-nomic-embed-text}"
RAG_ENABLED="${RAG_ENABLED:-false}"

ollama_service="$(docker compose ps -q ollama 2>/dev/null || true)"
if [[ -n "${ollama_service}" ]]; then
    echo "==> Waiting for the Ollama Compose service to become healthy..."
    tries=0
    while true; do
        status=$(docker inspect --format='{{.State.Health.Status}}' "${ollama_service}" 2>/dev/null || echo "starting")
        [[ "${status}" == "healthy" ]] && break
        tries=$((tries + 1))
        if [[ ${tries} -gt 30 ]]; then
            echo "ERROR: Ollama did not become healthy in time. Check: docker compose logs ollama" >&2
            exit 1
        fi
        sleep 2
    done
    echo "    Ollama Compose service is healthy."
    echo "==> Pulling ${LLM_MODEL} into the Ollama container..."
    docker compose exec -T ollama ollama pull "${LLM_MODEL}"
    if [[ "${RAG_ENABLED}" == "true" ]]; then
        echo "==> RAG_ENABLED=true — pulling embedding model ${EMBEDDING_MODEL} too..."
        docker compose exec -T ollama ollama pull "${EMBEDDING_MODEL}"
    fi
else
    echo "==> No Ollama Compose service found; using Ollama on the configured host."
    ollama_url="http://${LLM_SERVER_HOST:-localhost}:${LLM_SERVER_PORT:-11434}"
    if ! curl -sf "${ollama_url}/api/tags" >/dev/null 2>&1; then
        echo "ERROR: Ollama is not reachable at ${ollama_url}. Start Ollama and ensure ${LLM_MODEL} is installed." >&2
        exit 1
    fi
    echo "    Host Ollama is reachable. Ensure model ${LLM_MODEL} is available."
fi

echo "==> Waiting for the backend to report ready..."
tries=0
until curl -sf http://localhost:8000/health >/dev/null 2>&1; do
    tries=$((tries + 1))
    if [[ $tries -gt 30 ]]; then
        echo "ERROR: Backend did not respond in time. Check: docker compose logs backend" >&2
        exit 1
    fi
    sleep 2
done

echo ""
echo "==> Stack is up. Quick reference:"
echo "    Backend (direct):       http://localhost:8000/health"
echo "    Backend (via NGINX):    http://localhost/health"
echo "    Readiness (dependency check): http://localhost:8000/ready"
echo "    Qdrant:                 http://localhost:6333/collections"
echo "    Keycloak admin console: http://localhost:8080"
echo "    Prometheus:             http://localhost:9090"
echo "    Grafana:                http://localhost:3000"
echo ""
echo "    Open docs/standalone-chat.html in a browser to start chatting —"
echo "    no Visual Studio extension required."
