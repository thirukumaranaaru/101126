# Offline deployment update

## Source-only changes

The router, conversion prompts, schemas, tests, benchmark, and documentation are source changes. No new runtime service or model is required. Existing `llama3:8b`, `nomic-embed-text`, Qdrant, PostgreSQL, and Redis configuration remains compatible.

## Rebuild

Because `app/` is copied into the image, rebuild the backend image after transferring the source archive:

```powershell
docker compose -f infrastructure/docker-compose.yml build backend
docker compose -f infrastructure/docker-compose.yml up -d backend
```

To start the complete Compose stack with the helper script on Windows, use Git Bash or WSL:

```bash
cd backend/infrastructure
./start.sh
```

The script creates `infrastructure/.env` from `.env.example` if it is missing. It uses Ollama on the Windows host by default and checks that it is reachable; it no longer assumes an Ollama Compose service exists.

## Native PowerShell startup without Docker

From PowerShell at the project root:

```powershell
.\start.ps1
```

For RAG, Qdrant must already be running natively on `localhost:6333`:

```powershell
.\start.ps1 -EnableRag
```

If Python dependencies are not installed and offline wheels are available:

```powershell
.\start.ps1 -InstallDependencies
```

The script validates Python, FastAPI/Uvicorn, Ollama, the configured LLM model, and—when RAG is enabled—Qdrant and the embedding model before launching the backend in a new PowerShell window.

Use the already cached `python:3.11-slim` base and existing dependency layers. No new Python dependency was added.

The Compose file now has safe local-only defaults for PostgreSQL, Keycloak, and Grafana so the stack can be parsed and started without a missing-variable error. Replace those values in `infrastructure/.env` before using the stack beyond a local machine.

## Configuration

Optionally set `RAG_AMBIGUOUS_FALLBACK=rag` to prefer retrieval for ambiguous requests. Keep `LLM_SERVER_HOST=host.docker.internal` when Ollama runs on the Windows host, and keep the existing collection/model settings.

Optional quality/performance settings:

```env
RAG_CHUNK_OVERLAP_WORDS=20
RAG_MIN_SIMILARITY=0.35
```

The defaults remain `0` overlap and `0.0` threshold for compatibility. Raise the similarity threshold only after measuring your embedding model's score distribution.

For slower CPU-only Ollama inference, increase `LLM_TIMEOUT_SECONDS` (for example, `300`). LLM timeouts now return HTTP `504` with an actionable message instead of an unhandled traceback.

PDF handling:

- `pdfplumber` is included in `requirements-rag.txt` for page-aware text and table extraction; stage its wheel in the offline package bundle before building the image.
- Set `PDF_OCR_ENABLED=true` only when a compatible local OCR setup is installed. OCR is optional and failures do not stop ingestion.
- Without `pdfplumber`, PDF ingestion falls back to the existing text extraction path. Images and table structure cannot be recovered in that fallback.

## Verification

Run `python -m compileall -q app`, the available unit tests, and `python tools/benchmark_rag_routing.py`. Confirm the Docker base image and all model/service images are present locally before disconnecting the office PC.
