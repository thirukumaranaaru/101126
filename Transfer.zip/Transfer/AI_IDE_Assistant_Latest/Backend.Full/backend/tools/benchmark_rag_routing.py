"""Offline benchmark harness. Run with fake services to measure this deployment.

Example: python tools/benchmark_rag_routing.py
The script reports routing overhead only; service latency fields require a
configured Retriever/LLM and should be measured with deployment-specific fakes.
"""
import time
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app.rag.query_router import decide_route


def main() -> None:
    samples = ["Explain recursion", "According to our coding guidelines, explain error handling"]
    for sample in samples:
        start = time.perf_counter()
        decision = decide_route(sample)
        elapsed = (time.perf_counter() - start) * 1000
        print(f"route={decision.route.value}\trouting_ms={elapsed:.3f}\trequest={sample}")
    print("embedding_ms/retrieval_ms/reranking_ms/llm_ms/total_ms=not measured by this harness")


if __name__ == "__main__":
    main()
