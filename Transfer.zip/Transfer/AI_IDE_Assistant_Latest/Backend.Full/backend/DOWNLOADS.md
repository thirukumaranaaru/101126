# What Needs To Be Downloaded / Pre-Staged

This backend is designed to run with **zero runtime internet access** (SRS
EC-1 through EC-8). Everything below must be fetched *before* the target
machine is disconnected from the internet — typically on a connected
staging machine, then transferred in via approved media, per your
organization's air-gap transfer process. Nothing in this list is fetched
automatically by the application at runtime.

Status markers: **[Required]** the corresponding feature does not work at
all without it. **[Optional]** a documented fallback exists and is real,
tested code, not a stub — but functionality is degraded without it.

---

## 1. Python packages

Three requirements files, split by when they're actually needed:

| File | When needed | Install with |
|---|---|---|
| `requirements.txt` | Always — the core chat/code-action backend | `pip install -r requirements.txt` |
| `requirements-rag.txt` | Only if `RAG_ENABLED=true` | `pip install -r requirements-rag.txt` |
| `requirements-dev.txt` | Only to run the test suite | `pip install -r requirements-dev.txt` |

On a connected machine with the same OS/Python version as the target:

```bash
pip download -r requirements.txt -d ./offline-packages/core
pip download -r requirements-rag.txt -d ./offline-packages/rag
pip download -r requirements-dev.txt -d ./offline-packages/dev
```

Transfer the `offline-packages/` directory and install with
`pip install --no-index --find-links=./offline-packages/core -r requirements.txt`
(and similarly for the other two) on the air-gapped machine.

**All version numbers in the requirements files are ranges, not pins** —
this was written in a sandbox with no internet access to check current
releases. Resolve each range to an exact version against your internal
package mirror or the versions you actually download, and pin them, before
this goes anywhere near production.

---

## 2. Ollama + models **[Required for chat/code actions; embedding model Required only if RAG_ENABLED]**

The backend talks to Ollama over HTTP (`LLM_SERVER_HOST`/`LLM_SERVER_PORT`,
default `localhost:11434`) for both the LLM and (if RAG is enabled) the
embedding model.

1. Install Ollama itself on the LLM server: <https://ollama.com/download>
   (the installer/binary must be pre-staged and installed without internet
   access — see Ollama's own docs for offline installation).
2. Pull the models **on a connected machine**, then transfer Ollama's model
   storage directory (or use `ollama pull` against an internal registry
   mirror, if your organization runs one):
   - `llama3:8b` — the primary LLM (`LLM_MODEL` setting). **[Required]**
   - `nomic-embed-text` — the default embedding model
     (`EMBEDDING_MODEL` setting). **[Optional — only if RAG_ENABLED=true]**.
     This is one reasonable choice, not the only one; any embedding model
     Ollama can serve works, but changing it means re-embedding anything
     already ingested.

Verify locally before disconnecting: `curl http://localhost:11434/api/chat
-d '{"model":"llama3:8b","messages":[{"role":"user","content":"hi"}],
"stream":false}'` and, for embeddings, `curl
http://localhost:11434/api/embed -d '{"model":"nomic-embed-text","input":"hi"}'`.

---

## 3. Qdrant **[Required only if RAG_ENABLED=true]**

Vector store for RAG. Runs as its own service, most commonly via the
official Docker image:

```bash
docker pull qdrant/qdrant:v1.11.0   # pick a version, pin it, pre-stage the image
```

Pre-stage the image (`docker save` / `docker load`, or your internal
registry mirror) rather than pulling at deploy time. No model weights are
needed for Qdrant itself — it stores vectors your ingestion pipeline
produces, it doesn't generate them.

---

## 4. Reranker server (Text Embeddings Inference) **[Optional — only if you set `RERANKER_HOST`]**

`app/rag/reranker.py` targets Hugging Face's Text Embeddings Inference
(TEI) server's `/rerank` endpoint. If `RERANKER_HOST` is left unset,
`app/rag/dependencies.py` never constructs a reranker and retrieval falls
back to plain vector-similarity order — a real, tested code path, not a
missing feature.

If you do want reranking:

```bash
docker pull ghcr.io/huggingface/text-embeddings-inference:cpu-1.5   # or a cuda-* tag for GPU
```

Model weights (e.g. `BAAI/bge-reranker-v2-m3`) must be downloaded on a
connected machine and mounted into the container via a volume — Hugging
Face's own TEI documentation describes this exact air-gapped deployment
pattern (download weights, then `docker run -v $volume:/data ...`).

---

## 5. tree-sitter grammars **[Optional]**

`app/rag/chunker.py`'s `chunk_code()` uses tree-sitter for structure-aware
code chunking (SRS Section 14) if `tree-sitter` and `tree-sitter-languages`
(in `requirements-rag.txt`) are installed; otherwise it uses a tested
line-based fallback automatically, with a logged warning. No additional
download beyond the two pip packages above is needed — `tree-sitter-languages`
bundles prebuilt grammars for common languages.

**This code path has not been executed anywhere in this project** — it was
written against tree-sitter's documented API but this sandbox could not
install the package to run it. Verify it against real code samples on a
machine that has it installed before relying on it for anything.

---

## 6. Document-ingestion sample content

Not a download, but worth stating plainly: the ingestion pipeline
(`app/rag/ingestion/pipeline.py`) needs actual coding-standard documents
plus their metadata sidecars (`<file>.meta.json` — see
`app/rag/ingestion/metadata.py`) to ingest anything. None are included
here; the organization's RAG administrator supplies these per SRS Section
10/44.4.

---

## 7. Docker + the Phase 12-14 infrastructure stack **[Required only if you use `infrastructure/`]**

Skip this whole section if you're only running the backend standalone
(Section 1 of SETUP.md) — none of it is needed for basic chat/code
actions.

1. **Docker Engine + Compose plugin** — install per your OS, pre-staged
   like everything else here.
2. **Container images**, pre-staged via `docker pull` on a connected
   machine then `docker save`/`docker load`, or your internal registry
   mirror:
   - `postgres:16-alpine`
   - `redis:7-alpine`
   - `qdrant/qdrant:v1.11.0` (also listed in §3 above)
   - `quay.io/keycloak/keycloak:26.0.0`
   - `nginx:1.27-alpine`
   - `prom/prometheus:v2.54.0`
   - `grafana/loki:3.1.0`
   - `grafana/grafana:11.2.0`
   - (Optional, GPU host only) an NVIDIA DCGM exporter image — see the
     commented-out service in `infrastructure/docker-compose.yml`.
3. **restic** (Phase 14 backup) — install the binary on the backend host
   itself (not containerized in this delivery); see
   `infrastructure/backup/backup.sh`.
4. **TLS certificates** for NGINX — not generated by anything here. Use
   your organization's internal CA; self-signed certificates are not
   appropriate for anything beyond initial testing.

None of images 2-7 in this list are pulled automatically — see SETUP.md
Section 3.3 for the exact pre-staging commands.

## 8. What's genuinely NOT needed

- **No cloud AI service credentials** — nothing in this codebase calls
  OpenAI, Azure OpenAI, Google AI, or any other cloud provider (EC-5).
- **No Hugging Face Hub token** — TEI's own air-gapped docs cover
  downloading weights separately from running the server; nothing here
  authenticates to huggingface.co at runtime.
- **No internet access from the backend process itself, ever.** Every
  outbound call this codebase makes is to a `*_HOST`/`*_PORT` pair read
  from environment configuration (`app/config/settings.py`) — grep for
  `os.environ.get` there to see the complete list of addresses the backend
  will ever contact.
