# Setup Guide — Backend + RAG + Infrastructure

This walks through everything needed to get the backend running, from a
bare machine to the full Phase 12-14 infrastructure stack. Follow the
sections in order — each one assumes the previous ones are done.

**Read this first:** nothing in this guide has been executed end-to-end in
one place (see each zip's README.md "Honesty note"). Treat every command
below as a well-founded starting point, not a guarantee. Expect to
troubleshoot.

---

## 0. What you're building

```
Visual Studio Extension  --HTTP-->  NGINX  --+--> Keycloak (auth)
                                              +--> Backend (FastAPI)
                                                       |
                                          +------------+------------+
                                          |            |            |
                                       Redis      PostgreSQL     Qdrant
                                          |                          |
                                     (queue/cache)          (RAG vectors)
                                                       |
                                                  Ollama (LLM + embeddings)
                                                       |
                                          Prometheus + Grafana + Loki (monitoring)
```

You do not need all of this to get chat working. Section 1 alone gives you
a working `/api/chat` and `/api/code-action`. Everything after that is
additive.

---

## 1. Minimum viable setup (chat + code actions, no RAG, no infra)

### 1.1 Install Python

Python 3.11 recommended (matches the Dockerfile's base image). 3.10+ should
work.

### 1.2 Install Ollama and pull the LLM

- Install from <https://ollama.com/download> (do this on a connected
  machine if the target is air-gapped, then transfer — see DOWNLOADS.md).
- `ollama pull llama3:8b`
- Verify: `ollama run llama3:8b "hello"` should return a response.

### 1.3 Install and run the backend

```bash
cd backend
pip install -r requirements.txt
export LLM_SERVER_HOST=localhost
export LLM_SERVER_PORT=11434
export LLM_MODEL=llama3:8b
uvicorn app.main:app --host 0.0.0.0 --port 8000
```

### 1.4 Verify

```bash
curl http://localhost:8000/health
# {"status":"ok"}

curl -X POST http://localhost:8000/api/chat \
  -H "Content-Type: application/json" \
  -d '{"message": "What is a linked list?", "history": []}'
```

If that returns a real answer, chat works. Point the Visual Studio
extension at this address (see the extension's own SETUP.md) and you have
an end-to-end system.

---

## 2. Adding RAG (required for chat fallback answers)

Skip this section only if you accept that questions the model declines to
answer will stop with a no-verified-answer response. With `RAG_ENABLED=true`,
the backend searches these documents only after the model says it needs
additional knowledge; it does not retrieve for every chat question.

### 2.1 Install the RAG dependencies

```bash
pip install -r requirements-rag.txt
```

### 2.2 Pull the embedding model into the same Ollama instance

```bash
ollama pull nomic-embed-text
curl http://localhost:11434/api/embed -d '{"model":"nomic-embed-text","input":"test"}'
```

### 2.3 Run Qdrant

```bash
docker run -d -p 6333:6333 -v qdrant_data:/qdrant/storage qdrant/qdrant:v1.11.0
```

(Or use `infrastructure/docker-compose.yml`, which includes Qdrant — see
Section 3.)

### 2.4 (Optional) Run a reranker

Only if you want cross-encoder reranking rather than plain vector-order
results. See DOWNLOADS.md for the Text Embeddings Inference (TEI)
container and model. Leave `RERANKER_HOST` unset to skip this — retrieval
still works without it.

### 2.5 Ingest some documents

Create a directory of guideline documents, each with a `.meta.json`
sidecar (see `app/rag/ingestion/metadata.py` for the exact fields):

```
mandatory-guidelines/
  coding-standard.md
  coding-standard.md.meta.json
```

Example sidecar:
```json
{
  "document_name": "coding-standard",
  "document_version": "1.0",
  "category": "coding-standard",
  "priority_tier": 5,
  "is_mandatory": true,
  "status": "active"
}
```

Ingest the directory into Qdrant before starting the backend:

```bash
python -m app.rag.ingestion.cli --source-dir /path/to/mandatory-guidelines
```

The fallback flow deliberately stops when this collection contains no
relevant chunks, so an empty or un-ingested directory cannot produce a RAG
answer.

### 2.6 Turn it on

```bash
export RAG_ENABLED=true
export QDRANT_HOST=localhost QDRANT_PORT=6333
export EMBEDDING_MODEL=nomic-embed-text
export MANDATORY_GUIDELINES_DIR=/path/to/mandatory-guidelines
uvicorn app.main:app --host 0.0.0.0 --port 8000
```

Mandatory guidelines load once at process start (`app/rag/dependencies.py`
caches them) — restart the process after ingesting new mandatory
documents.

---

## 3. Full infrastructure stack (Phases 12-14)

Everything in `infrastructure/`: NGINX, Keycloak, PostgreSQL, Redis,
Qdrant, Prometheus, Grafana, Loki.

### 3.0 One-command startup

On Windows, start Docker Desktop and Ollama first, then run the helper from Git Bash or WSL:

```bash
cd backend/infrastructure
./start.sh
```

The helper creates a local `.env` from `.env.example` when needed, starts Compose, verifies host Ollama, and waits for the backend health endpoint. The default Compose configuration expects Ollama at `host.docker.internal:11434`; install the configured `llama3:8b` model before running it.

**Important limitation, stated plainly:** this stack stands up Keycloak
and provisions a realm, but **no code in this project actually validates a
Keycloak token yet.** `/api/chat` and `/api/code-action` remain
unauthenticated even with this whole stack running. Standing up Keycloak
now is still worthwhile — it means Phase 12's actual auth code, whenever
it's written, has something real to integrate against — but don't mistake
"Keycloak is running" for "the API is secured."

### 3.1 Install Docker and Docker Compose

Standard Docker Engine + Compose plugin install for your OS. Pre-stage the
installer per your organization's air-gap process (DOWNLOADS.md).

### 3.2 Configure

```bash
cd infrastructure
cp .env.example .env
# edit .env: set POSTGRES_PASSWORD, KEYCLOAK_ADMIN_PASSWORD,
# GRAFANA_ADMIN_PASSWORD, and LLM_SERVER_HOST (point this at wherever
# Ollama actually runs — it is NOT one of the containers below)
```

### 3.3 Pre-stage every image

On a connected machine:
```bash
docker pull postgres:16-alpine
docker pull redis:7-alpine
docker pull qdrant/qdrant:v1.11.0
docker pull quay.io/keycloak/keycloak:26.0.0
docker pull nginx:1.27-alpine
docker pull prom/prometheus:v2.54.0
docker pull grafana/loki:3.1.0
docker pull grafana/grafana:11.2.0
```
Then `docker save`/`docker load` each into the air-gapped environment, or
push to your internal registry mirror. The backend's own image is built
locally from the included `Dockerfile` — no pull needed for that one.

### 3.4 Bring it up

```bash
docker compose up -d
docker compose ps        # everything should show "healthy" or "running"
docker compose logs -f backend   # watch for startup errors
```

### 3.5 Verify each piece

| Check | Command |
|---|---|
| Backend via NGINX | `curl http://localhost/health` |
| Keycloak admin console | Browse to `http://localhost:8080` (or via NGINX's `/auth/` path), log in with the admin credentials from `.env` |
| Prometheus targets | Browse to `http://localhost:9090/targets` — the backend target should be "UP" |
| Grafana | Browse to `http://localhost:3000`, log in as `admin` / your `GRAFANA_ADMIN_PASSWORD`. Prometheus and Loki should already appear under Connections > Data sources (provisioned automatically) |
| Qdrant | `curl http://localhost:6333/collections` |

### 3.6 Set up backups

```bash
sudo mkdir -p /etc/ai-ide-assistant
sudo cp infrastructure/backup/backup.sh /usr/local/bin/
sudo chmod +x /usr/local/bin/backup.sh
# create /etc/ai-ide-assistant/backup.env with RESTIC_REPOSITORY,
# RESTIC_PASSWORD, POSTGRES_HOST, POSTGRES_DB, POSTGRES_USER, PGPASSWORD,
# QDRANT_DATA_DIR, CONFIG_DIR — see the script's own header comment
sudo crontab -e
# add: 0 2 * * * /usr/local/bin/backup.sh >> /var/log/ai-ide-assistant-backup.log 2>&1
```

Test it manually once before trusting the cron job:
```bash
sudo /usr/local/bin/backup.sh
```

---

## 4. Hardening before this goes anywhere near production

Not covered by this delivery — flagged here so it isn't forgotten:

- Switch Keycloak from `start-dev` to `start` with `KC_DB=postgres`
  pointing at a real, backed-up database (see the comment in
  `docker-compose.yml`'s `keycloak` service).
- Add a real TLS certificate to NGINX and enable the commented-out `443`
  block in `nginx.conf`.
- Write Phase 12's actual token-validation middleware
  (`app/auth/oidc.py` — not yet created) and wire it into every route.
- Write the extension's login flow (`AuthService.cs` — not yet created).
- Rotate every default/example credential in `.env`.

---

## 5. Running the tests

```bash
pip install -r requirements.txt -r requirements-dev.txt
python -m unittest discover -s tests    # 70/71 pass without fastapi installed*
python -m pytest                        # all should pass with fastapi installed
```
\* `tests/test_chat.py` needs `fastapi` importable to even load — see the
main README's "Honesty note."

---

## 6. Troubleshooting

| Symptom | Likely cause |
|---|---|
| `/api/chat` returns 502 | Ollama isn't running, or `LLM_SERVER_HOST`/`PORT` don't point at it |
| RAG requests silently ignore guidelines | Check `RAG_ENABLED=true` is actually set in the backend's environment, not just in your shell |
| Keycloak container exits immediately | Check `docker compose logs keycloak` — often a malformed `realm-export.json` or a port conflict on 8080 |
| `docker compose up` fails on `POSTGRES_PASSWORD` etc. | You didn't create `.env` from `.env.example`, or left a required value blank — the `${VAR:?message}` syntax in `docker-compose.yml` fails fast on purpose |
| Grafana shows no data | Confirm `http://prometheus:9090/targets` (from inside the Grafana container's network) shows the backend as UP first |
