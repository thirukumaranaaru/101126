# AI IDE Assistant — Backend + RAG Pipeline

Python/FastAPI backend for the offline AI coding assistant (see the SRS and
Phase-Wise Implementation Plan for full requirements). Covers Phases 4-11
fully, plus infrastructure-as-code for Phases 12-14 (Keycloak, NGINX,
PostgreSQL, Redis, Prometheus, Grafana, Loki, backup) — see SETUP.md for
the full picture, including what Phase 12-14 infra does NOT include yet.

## Honesty note before anything else

This codebase was written in a sandbox with **no internet access** and
**no Ollama/Qdrant/TEI servers available to test against**. Two different
levels of confidence apply, and the code comments say which applies to
each file:

- **Actually executed and passing** — anything covered by
  `python3 -m unittest discover -s tests`, which runs 71 tests without
  needing fastapi, httpx, qdrant-client, or any network service (70 pass;
  the 1 failure is `tests/test_chat.py`, which needs fastapi installed to
  even import — see below).
- **Verified against real API documentation but never executed** — the
  HTTP clients to Ollama, Qdrant, and TEI. Each was checked against that
  service's actual current API docs via web search before being written
  (not recalled from memory), but none has run against a live instance of
  that service anywhere in this project.

Do not treat "verified against docs" as equivalent to "tested." Run the
full suite yourself once fastapi/httpx are installed, and exercise the RAG
path against real Ollama/Qdrant instances before trusting it in anything
resembling production.

## Structure

```
app/
  main.py                 FastAPI app, mounts both routers
  api/
    chat.py                POST /api/chat  (+ RAG augmentation, Phase 11)
    code_action.py          POST /api/code-action (+ RAG augmentation)
  llm/
    base.py                  LLMService interface + LLMMessage (pure stdlib)
    local_llama_provider.py    Ollama /api/chat client
  services/
    code_actions.py            Prompt templates for the 8 code actions
  rag/
    models.py                   ChunkMetadata, DocumentChunk, ScoredChunk
    chunker.py                   Text + code chunking (tree-sitter optional)
    embeddings.py                 EmbeddingService interface + Ollama provider
    reranker.py                    Reranker interface + TEI provider
    vectorstore.py                  VectorStore interface + Qdrant + in-memory
    guidelines.py                    Mandatory-guideline selection/conflicts
    prompt_builder.py                 Three-block prompt assembly
    retriever.py                      Orchestrates embed -> search -> rerank
    dependencies.py                    FastAPI DI: get_retriever(), get_mandatory_chunks()
    ingestion/
      loader.py                        Markdown/txt/PDF/DOCX -> plain text
      metadata.py                       *.meta.json sidecar parsing
      pipeline.py                       Directory -> chunks -> embeddings -> vector store
  monitoring/metrics.py       Phase 13: Prometheus request/LLM/RAG latency metrics
  config/settings.py         All configuration, env-var driven (FR-INFRA-1)
  models/schemas.py           Pydantic request/response models
tests/                       71 tests; see "Honesty note" above
requirements.txt              Core (always needed)
requirements-rag.txt           Only if RAG_ENABLED=true
requirements-dev.txt            Only to run tests
infrastructure/                Phase 12-14: docker-compose.yml + NGINX/
                                 Postgres/Prometheus/Grafana/Loki/Keycloak/
                                 backup configs — see SETUP.md Section 3
SETUP.md                       Step-by-step: bare machine -> full stack
DOWNLOADS.md                    Everything to pre-stage before going offline
```

## Running it

```bash
pip install -r requirements.txt
export LLM_SERVER_HOST=localhost LLM_SERVER_PORT=11434 LLM_MODEL=llama3:8b
uvicorn app.main:app --host 0.0.0.0 --port 8000
```

With RAG enabled:

```bash
pip install -r requirements-rag.txt
export RAG_ENABLED=true
export QDRANT_HOST=localhost QDRANT_PORT=6333
export EMBEDDING_MODEL=nomic-embed-text
export MANDATORY_GUIDELINES_DIR=/path/to/ingested/mandatory/docs
# RERANKER_HOST left unset -> falls back to plain vector order, by design
uvicorn app.main:app --host 0.0.0.0 --port 8000
```

### Chat answer routing

`/api/chat` uses a local deterministic router before calling any embedding or
vector service. Direct requests use one LLM call. Internal-guideline,
compliance, and project-specific requests use query embedding, vector search,
optional reranking, and one grounded LLM pass. Ambiguous requests follow
`RAG_AMBIGUOUS_FALLBACK`. If RAG returns no chunks or is unavailable, the API
returns "I don't have enough verified information to answer that." Existing
clients that still emit the historical internal RAG marker remain supported as
a compatibility path.

Set `RAG_ENABLED=true`, ingest documents into Qdrant, and configure
`MANDATORY_GUIDELINES_DIR` for this fallback to be useful. If
`RAG_ENABLED=false`, a model-declared knowledge gap returns the same safe
no-answer response because no retrieval path is available.

## Running the tests

```bash
pip install -r requirements.txt -r requirements-dev.txt
python -m pytest                              # needs fastapi (test_chat.py)
python -m unittest discover -s tests          # works without fastapi/httpx
```

## Endpoints

| Endpoint | Purpose |
|---|---|
| `GET /health` | Liveness check |
| `POST /api/chat` | General Ask AI (SRS FR-GA-3/4/5) |
| `POST /api/code-action` | The 8 context-menu code actions (SRS FR-CTX-6..13) |

See the SDD (Section 8) for full request/response schemas.

## Infrastructure (Phases 12-14)

`infrastructure/` has a full `docker-compose.yml` for NGINX, Keycloak,
PostgreSQL, Redis, Qdrant, Prometheus, Grafana, and Loki — see SETUP.md
Section 3 for the walkthrough. Stated there and worth repeating here:
**Keycloak is provisioned but nothing in this codebase validates a token
yet** — `/api/chat` and `/api/code-action` are unauthenticated regardless
of whether this stack is running.

## Where to go next

- `DOWNLOADS.md` — what must be pre-staged before the target machine goes
  offline.
- The Phase-Wise Implementation Plan — Phases 12-18 (auth, infrastructure,
  backup, hardening, testing, deployment) are not part of this codebase yet.
- The SDD — architecture diagrams and data flow, some of which this
  delivery has now outrun (it still shows Phase 7/8 C# code as the most
  recent milestone; the RAG sections should be updated from "Planned" to
  "Implemented" to match this delivery).
