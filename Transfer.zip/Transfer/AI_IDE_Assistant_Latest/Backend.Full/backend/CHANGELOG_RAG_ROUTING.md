# RAG routing and conversion update

## Changes

- Added `app/rag/query_router.py`, a deterministic offline router returning `direct` or `rag`.
- General programming and self-contained conversion requests use one direct LLM call and do not embed, query Qdrant, or rerank.
- Requests mentioning internal/project knowledge, standards, guidelines, compliance, manuals, or mandatory requirements use RAG. Ambiguous requests use `RAG_AMBIGUOUS_FALLBACK` (default `direct`).
- Existing `explain`, `evaluate`, and `fix_errors` actions continue to force guideline retrieval when RAG is configured.
- Added exact operation identifiers `algorith_to_code` and `code_to_algorithm` to the existing `/api/code-action` dispatcher. `operation` may be supplied explicitly; legacy `action` remains supported.
- Conversion requests may use `algorithm` or `source_code` fields, while the existing `code` field remains supported for compatibility.
- `algorith_to_code` returns `language_required: true` when language is missing and never assumes one.
- `code_to_algorithm` analyzes the supplied source without requiring a language.
- Added embedding and reranking latency Prometheus histograms and routing logs.
- Added configurable chunk overlap (`RAG_CHUNK_OVERLAP_WORDS`), similarity filtering (`RAG_MIN_SIMILARITY`), and loading for common source-code/configuration extensions.
- Qdrant ingestion now creates the configured collection automatically when it is missing, using the first embedding dimension and cosine distance.
- Compose can start without missing-secret interpolation errors by using clearly local-only default credentials; deployment values remain overridable through `.env`.
- Removed NumPy from the in-memory vector-store path so lightweight offline tests do not require scientific Python packages.
- Added page-aware PDF elements: paragraphs, structured table text, and image markers with optional OCR. Source references and content type are preserved in chunk metadata and rendered into the RAG prompt.
- Added root-level `start.ps1` for native Windows startup without Docker, including dependency, Ollama, model, and optional Qdrant checks.

## Verification

`python -m compileall -q app tests tools` completed successfully. The focused pure tests passed: 25 tests via `python -m unittest tests.test_chunker tests.test_query_router tests.test_conversion tests.test_code_actions`. Docker Compose configuration validation also passed. The PDF loader test could not run because `reportlab` is not installed in this environment; async vector/retriever tests were not counted because this environment's `asyncio.run()` test processes did not terminate. A live Docker/Ollama/Qdrant run was not performed.

## Limitations

The router is intentionally heuristic and does not infer undocumented organization-specific terms. RAG behavior and end-to-end latency require live or mocked Ollama/Qdrant services for integration verification.
