import unittest

from app.rag.models import ChunkMetadata, DocumentChunk
from app.rag.prompt_builder import (
    CONTEXTUAL_TOKEN_BUDGET,
    MANDATORY_TOKEN_RESERVE,
    build_prompt,
)


def make_chunk(name, text, mandatory=False):
    return DocumentChunk(
        chunk_id=name,
        text=text,
        metadata=ChunkMetadata(document_name=name, document_version="1.0", is_mandatory=mandatory),
    )


class BuildPromptStructureTests(unittest.TestCase):
    def test_three_blocks_present_in_order(self):
        prompt = build_prompt("write a function", [], [])
        m = prompt.index("MANDATORY ORGANIZATIONAL GUIDELINES")
        r = prompt.index("RELEVANT RETRIEVED KNOWLEDGE")
        u = prompt.index("USER REQUEST / CODE CONTEXT")
        self.assertLess(m, r)
        self.assertLess(r, u)

    def test_user_request_always_included(self):
        prompt = build_prompt("explain this function", [], [])
        self.assertIn("explain this function", prompt)

    def test_mandatory_and_contextual_text_included(self):
        mandatory = [make_chunk("m1", "use smart pointers", mandatory=True)]
        contextual = [make_chunk("c1", "background info about pointers")]
        prompt = build_prompt("write code", mandatory, contextual)
        self.assertIn("use smart pointers", prompt)
        self.assertIn("background info about pointers", prompt)

    def test_empty_blocks_say_none(self):
        prompt = build_prompt("hello", [], [])
        self.assertIn("(none applicable to this request)", prompt)
        self.assertIn("(none retrieved)", prompt)


class TokenBudgetPriorityTests(unittest.TestCase):
    def test_contextual_chunks_dropped_before_mandatory_is_ever_touched(self):
        # A mandatory chunk sized well under its own reserve...
        mandatory_text = "use smart pointers instead of raw owning pointers"
        mandatory = [make_chunk("m1", mandatory_text, mandatory=True)]

        # ...and contextual chunks that vastly exceed the contextual budget.
        huge_chunk = make_chunk("huge", " ".join(["word"] * (CONTEXTUAL_TOKEN_BUDGET * 3)))
        contextual = [huge_chunk]

        prompt = build_prompt("write code", mandatory, contextual)

        # The mandatory guideline survives completely, untruncated.
        self.assertIn(mandatory_text, prompt)
        # The oversized contextual chunk was dropped rather than truncating
        # the mandatory block to make room for it.
        self.assertIn("(none retrieved)", prompt)

    def test_mandatory_block_truncated_only_if_it_alone_exceeds_its_reserve(self):
        oversized_mandatory_text = " ".join(["guideline"] * (MANDATORY_TOKEN_RESERVE * 2))
        mandatory = [make_chunk("m1", oversized_mandatory_text, mandatory=True)]
        prompt = build_prompt("write code", mandatory, [])
        self.assertIn("[...truncated]", prompt)

    def test_lower_ranked_contextual_chunks_dropped_first(self):
        # First chunk leaves only 3 words of budget remaining; second chunk
        # is deliberately larger than that remainder, so it must be dropped.
        first = make_chunk("first", " ".join(["word"] * (CONTEXTUAL_TOKEN_BUDGET - 3)))
        second = make_chunk("second", "this should be dropped")
        prompt = build_prompt("write code", [], [first, second])
        self.assertIn("word word", prompt)
        self.assertNotIn("this should be dropped", prompt)

    def test_unresolved_conflicts_are_surfaced(self):
        m1 = make_chunk("guideline-a", "text a", mandatory=True)
        m2 = make_chunk("guideline-b", "text b", mandatory=True)
        prompt = build_prompt("write code", [m1, m2], [], unresolved_conflicts=[[m1, m2]])
        self.assertIn("UNRESOLVED GUIDELINE CONFLICTS", prompt)
        self.assertIn("guideline-a", prompt)
        self.assertIn("guideline-b", prompt)


if __name__ == "__main__":
    unittest.main()
