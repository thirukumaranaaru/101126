import unittest
from datetime import date

from app.rag.models import ChunkMetadata, DocumentChunk
from app.rag.guidelines import is_applicable, resolve_conflicts, select_mandatory_chunks


def make_chunk(name, priority=0, eff_date=None, category="coding", section="pointers",
                mandatory=True, status="active", scope=None, text="guideline text"):
    return DocumentChunk(
        chunk_id=name,
        text=text,
        metadata=ChunkMetadata(
            document_name=name,
            document_version="1.0",
            category=category,
            section=section,
            priority_tier=priority,
            effective_date=eff_date,
            is_mandatory=mandatory,
            status=status,
            applicable_scope=scope,
        ),
    )


class ApplicabilityTests(unittest.TestCase):
    def test_no_scope_applies_everywhere(self):
        c = make_chunk("A", scope=None)
        self.assertTrue(is_applicable(c, "cpp"))
        self.assertTrue(is_applicable(c, None))

    def test_scope_must_match(self):
        c = make_chunk("A", scope="cpp")
        self.assertTrue(is_applicable(c, "cpp"))
        self.assertFalse(is_applicable(c, "python"))
        self.assertFalse(is_applicable(c, None))

    def test_superseded_never_applicable(self):
        c = make_chunk("A", status="superseded")
        self.assertFalse(is_applicable(c))


class SelectMandatoryTests(unittest.TestCase):
    def test_filters_non_mandatory_and_inapplicable(self):
        chunks = [
            make_chunk("mandatory-global", mandatory=True),
            make_chunk("contextual", mandatory=False),
            make_chunk("mandatory-wrong-scope", mandatory=True, scope="python"),
        ]
        result = select_mandatory_chunks(chunks, scope="cpp")
        names = {c.chunk_id for c in result}
        self.assertEqual(names, {"mandatory-global"})


class ResolveConflictsTests(unittest.TestCase):
    def test_single_chunk_group_is_not_a_conflict(self):
        chunks = [make_chunk("only-one", priority=1)]
        winners, conflicts = resolve_conflicts(chunks)
        self.assertEqual(len(winners), 1)
        self.assertEqual(conflicts, [])

    def test_higher_priority_wins_outright(self):
        low = make_chunk("low", priority=1)
        high = make_chunk("high", priority=5)
        winners, conflicts = resolve_conflicts([low, high])
        self.assertEqual([c.chunk_id for c in winners], ["high"])
        self.assertEqual(conflicts, [])

    def test_same_priority_more_recent_date_wins(self):
        old = make_chunk("old", priority=3, eff_date=date(2024, 1, 1))
        new = make_chunk("new", priority=3, eff_date=date(2025, 6, 1))
        winners, conflicts = resolve_conflicts([old, new])
        self.assertEqual([c.chunk_id for c in winners], ["new"])
        self.assertEqual(conflicts, [])

    def test_same_priority_same_date_is_unresolved_conflict(self):
        a = make_chunk("a", priority=3, eff_date=date(2025, 1, 1))
        b = make_chunk("b", priority=3, eff_date=date(2025, 1, 1))
        winners, conflicts = resolve_conflicts([a, b])
        self.assertEqual({c.chunk_id for c in winners}, {"a", "b"})
        self.assertEqual(len(conflicts), 1)
        self.assertEqual({c.chunk_id for c in conflicts[0]}, {"a", "b"})

    def test_dated_beats_undated_at_same_priority(self):
        dated = make_chunk("dated", priority=2, eff_date=date(2025, 1, 1))
        undated = make_chunk("undated", priority=2, eff_date=None)
        winners, conflicts = resolve_conflicts([dated, undated])
        self.assertEqual([c.chunk_id for c in winners], ["dated"])
        self.assertEqual(conflicts, [])

    def test_all_undated_same_priority_is_unresolved(self):
        a = make_chunk("a", priority=2, eff_date=None)
        b = make_chunk("b", priority=2, eff_date=None)
        winners, conflicts = resolve_conflicts([a, b])
        self.assertEqual({c.chunk_id for c in winners}, {"a", "b"})
        self.assertEqual(len(conflicts), 1)

    def test_different_topics_never_conflict(self):
        a = make_chunk("a", category="coding", section="pointers")
        b = make_chunk("b", category="coding", section="naming")
        winners, conflicts = resolve_conflicts([a, b])
        self.assertEqual(len(winners), 2)
        self.assertEqual(conflicts, [])

    def test_ungrouped_chunks_never_conflict(self):
        a = make_chunk("a", category=None, section=None)
        b = make_chunk("b", category=None, section=None)
        winners, conflicts = resolve_conflicts([a, b])
        self.assertEqual(len(winners), 2)
        self.assertEqual(conflicts, [])


if __name__ == "__main__":
    unittest.main()
