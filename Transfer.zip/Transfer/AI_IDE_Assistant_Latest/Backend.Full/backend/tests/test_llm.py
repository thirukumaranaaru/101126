"""
Tests the LLMService contract itself, independent of any concrete provider.
Deliberately uses unittest (stdlib) rather than pytest, and imports nothing
from app.llm.local_llama_provider (which needs httpx) or app.api.chat (which
needs fastapi) — so this file can actually run in an environment where those
third-party packages aren't installable, which is exactly the situation this
sandbox is in. Run with: python3 -m unittest tests.test_llm
"""
import asyncio
import unittest
from typing import List, Optional

from app.llm.base import LLMMessage, LLMService


class FakeLLMService(LLMService):
    """Deterministic stand-in used here and recommended for Phase 6's
    dependency-override tests against the /api/chat route."""

    def __init__(self, fixed_reply: str = "fake reply") -> None:
        self.fixed_reply = fixed_reply
        self.calls: List[tuple] = []

    async def generate(self, prompt: str, history: Optional[List[LLMMessage]] = None) -> str:
        self.calls.append((prompt, history or []))
        return self.fixed_reply


class LLMServiceContractTests(unittest.TestCase):
    def test_cannot_instantiate_abstract_base(self):
        with self.assertRaises(TypeError):
            LLMService()  # abstract — must fail without a concrete generate()

    def test_fake_provider_satisfies_the_contract(self):
        service = FakeLLMService(fixed_reply="hello")
        reply = asyncio.run(service.generate("hi"))
        self.assertEqual(reply, "hello")

    def test_fake_provider_receives_history(self):
        service = FakeLLMService()
        history = [LLMMessage(role="user", content="earlier question")]
        asyncio.run(service.generate("follow-up", history=history))
        self.assertEqual(len(service.calls), 1)
        prompt, received_history = service.calls[0]
        self.assertEqual(prompt, "follow-up")
        self.assertEqual(received_history, history)

    def test_llm_message_equality(self):
        a = LLMMessage(role="user", content="x")
        b = LLMMessage(role="user", content="x")
        c = LLMMessage(role="assistant", content="x")
        self.assertEqual(a, b)
        self.assertNotEqual(a, c)


if __name__ == "__main__":
    unittest.main()
