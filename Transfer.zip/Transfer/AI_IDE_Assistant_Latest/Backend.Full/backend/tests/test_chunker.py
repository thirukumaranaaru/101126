import unittest

from app.rag.chunker import DEFAULT_MAX_CHUNK_WORDS, chunk_code, chunk_text
from app.rag.models import ChunkMetadata


def meta(name="doc"):
    return ChunkMetadata(document_name=name, document_version="1.0")


class ChunkTextTests(unittest.TestCase):
    def test_splits_on_paragraph_boundaries(self):
        text = "First paragraph.\n\nSecond paragraph.\n\nThird paragraph."
        chunks = chunk_text(text, meta())
        self.assertEqual([c.text for c in chunks], [
            "First paragraph.", "Second paragraph.", "Third paragraph.",
        ])

    def test_long_paragraph_split_on_word_boundary_without_exceeding_limit(self):
        text = " ".join(f"word{i}" for i in range(50))
        chunks = chunk_text(text, meta(), max_words=20)
        self.assertEqual(len(chunks), 3)  # 20 + 20 + 10
        for c in chunks:
            self.assertLessEqual(len(c.text.split()), 20)
        # No word lost or duplicated across the split.
        rejoined = " ".join(c.text for c in chunks)
        self.assertEqual(rejoined, text)

    def test_chunk_ids_are_unique_and_ordered(self):
        text = "A.\n\nB.\n\nC."
        chunks = chunk_text(text, meta("standards"))
        ids = [c.chunk_id for c in chunks]
        self.assertEqual(len(ids), len(set(ids)))
        self.assertEqual(ids, ["standards:1.0:0", "standards:1.0:1", "standards:1.0:2"])

    def test_empty_paragraphs_are_skipped(self):
        text = "First.\n\n\n\nSecond."
        chunks = chunk_text(text, meta())
        self.assertEqual(len(chunks), 2)

    def test_default_max_words_is_reasonable(self):
        # Sanity check on the module constant itself, not just behavior.
        self.assertGreater(DEFAULT_MAX_CHUNK_WORDS, 0)

    def test_optional_overlap_preserves_boundary_context(self):
        text = " ".join(f"word{i}" for i in range(25))
        chunks = chunk_text(text, meta(), max_words=10, overlap_words=2)
        self.assertEqual(len(chunks), 3)
        self.assertEqual(chunks[0].text.split()[-2:], chunks[1].text.split()[:2])


class ChunkCodeFallbackTests(unittest.TestCase):
    def test_fallback_used_when_tree_sitter_unavailable(self):
        # This sandbox has no tree-sitter installed (see chunker.py's module
        # docstring), so this test exercises the real fallback path, not a
        # mocked one.
        code = "\n".join([f"line {i}" for i in range(10)])
        chunks = chunk_code(code, meta(), max_lines=100)
        self.assertEqual(len(chunks), 1)
        self.assertIn("line 0", chunks[0].text)
        self.assertIn("line 9", chunks[0].text)

    def test_fallback_breaks_on_blank_lines_once_over_max_lines(self):
        block1 = "\n".join(f"a{i}" for i in range(5))
        block2 = "\n".join(f"b{i}" for i in range(5))
        code = block1 + "\n\n" + block2  # a genuine blank line between blocks
        chunks = chunk_code(code, meta(), max_lines=5)
        self.assertGreaterEqual(len(chunks), 2)
        self.assertIn("a0", chunks[0].text)

    def test_no_content_lost_across_fallback_chunks(self):
        lines = [f"line{i}" for i in range(30)]
        code = "\n".join(lines)
        chunks = chunk_code(code, meta(), max_lines=7)
        rejoined_lines = "\n".join(c.text for c in chunks).splitlines()
        self.assertEqual(rejoined_lines, lines)

    def test_hard_cap_splits_even_with_no_blank_lines(self):
        # 30 non-blank lines, max_lines=7 -> hard cap at 14 forces splits.
        lines = [f"line{i}" for i in range(30)]
        code = "\n".join(lines)
        chunks = chunk_code(code, meta(), max_lines=7)
        self.assertGreater(len(chunks), 1)
        for c in chunks:
            self.assertLessEqual(len(c.text.splitlines()), 14)


if __name__ == "__main__":
    unittest.main()
