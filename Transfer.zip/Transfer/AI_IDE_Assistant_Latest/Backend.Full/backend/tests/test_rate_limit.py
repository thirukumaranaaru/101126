import asyncio
import unittest

from app.middleware.rate_limit import RateLimiter


class FakeRedis:
    def __init__(self):
        self._counters = {}

    async def incr(self, key: str) -> int:
        self._counters[key] = self._counters.get(key, 0) + 1
        return self._counters[key]

    async def expire(self, key: str, seconds: int) -> None:
        pass


class FailingRedis:
    async def incr(self, key: str) -> int:
        raise ConnectionError("connection refused")

    async def expire(self, key: str, seconds: int) -> None:
        raise ConnectionError("connection refused")


class RateLimiterTests(unittest.TestCase):
    def test_allows_requests_under_the_limit(self):
        limiter = RateLimiter(FakeRedis(), limit=3, window_seconds=60)
        for _ in range(3):
            self.assertTrue(asyncio.run(limiter.is_allowed("client-a")))

    def test_blocks_requests_over_the_limit(self):
        limiter = RateLimiter(FakeRedis(), limit=3, window_seconds=60)
        results = [asyncio.run(limiter.is_allowed("client-a")) for _ in range(5)]
        self.assertEqual(results, [True, True, True, False, False])

    def test_different_keys_have_independent_limits(self):
        limiter = RateLimiter(FakeRedis(), limit=1, window_seconds=60)
        self.assertTrue(asyncio.run(limiter.is_allowed("client-a")))
        self.assertTrue(asyncio.run(limiter.is_allowed("client-b")))
        self.assertFalse(asyncio.run(limiter.is_allowed("client-a")))

    def test_fails_open_when_redis_is_unreachable(self):
        limiter = RateLimiter(FailingRedis(), limit=1, window_seconds=60)
        for _ in range(5):
            self.assertTrue(asyncio.run(limiter.is_allowed("client-a")))


if __name__ == "__main__":
    unittest.main()
