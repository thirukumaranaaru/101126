"""Pure tests for the supported code-action prompt dispatcher."""
import unittest

from app.services.code_actions import CodeAction, UnknownCodeActionError, build_prompt


class BuildPromptTests(unittest.TestCase):
    def test_only_supported_actions_are_registered(self):
        self.assertEqual(
            {action.value for action in CodeAction},
            {"explain", "evaluate", "fix_errors", "algorith_to_code", "code_to_algorithm"},
        )

    def test_explain_includes_code_and_context(self):
        prompt = build_prompt("explain", "int x = 1;", language="cpp", file_name="a.cpp")
        self.assertIn("int x = 1;", prompt)
        self.assertIn("File: a.cpp", prompt)
        self.assertIn("Explain", prompt)

    def test_evaluate_includes_code(self):
        self.assertIn("Evaluate", build_prompt("evaluate", "return value;"))

    def test_fix_errors_requires_compiler_error(self):
        with self.assertRaises(ValueError):
            build_prompt("fix_errors", "int x = 1", compiler_error=None)

    def test_algorithm_to_code_requires_language(self):
        with self.assertRaises(ValueError):
            build_prompt("algorith_to_code", "Read two numbers")

    def test_algorithm_to_code_prompt_preserves_language_and_algorithm(self):
        prompt = build_prompt("algorith_to_code", "Read two numbers and add them", "C++")
        self.assertIn("C++", prompt)
        self.assertIn("Read two numbers and add them", prompt)

    def test_code_to_algorithm_prompt_preserves_source(self):
        prompt = build_prompt("code_to_algorithm", "for (int i = 0; i < n; ++i) sum += i;")
        self.assertIn("for (int i = 0; i < n; ++i)", prompt)
        self.assertIn("numbered", prompt)

    def test_unknown_action_raises_specific_error(self):
        with self.assertRaises(UnknownCodeActionError):
            build_prompt("modify", "int x = 1;")


if __name__ == "__main__":
    unittest.main()
