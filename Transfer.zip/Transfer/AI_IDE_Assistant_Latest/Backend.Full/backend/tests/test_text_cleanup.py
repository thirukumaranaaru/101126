import unittest

from app.services.text_cleanup import strip_outer_code_fence


class StripOuterCodeFenceTests(unittest.TestCase):
    def test_strips_fence_with_language_tag(self):
        wrapped = "```cpp\nint x = 1;\n```"
        self.assertEqual(strip_outer_code_fence(wrapped), "int x = 1;")

    def test_strips_fence_without_language_tag(self):
        wrapped = "```\nint x = 1;\n```"
        self.assertEqual(strip_outer_code_fence(wrapped), "int x = 1;")

    def test_strips_fence_with_surrounding_whitespace(self):
        wrapped = "  \n```cpp\nint x = 1;\n```\n  "
        self.assertEqual(strip_outer_code_fence(wrapped), "int x = 1;")

    def test_preserves_multiline_code_inside_fence(self):
        wrapped = "```cpp\nint x = 1;\nint y = 2;\n```"
        self.assertEqual(strip_outer_code_fence(wrapped), "int x = 1;\nint y = 2;")

    def test_plain_code_with_no_fence_is_unchanged(self):
        plain = "int x = 1;"
        self.assertEqual(strip_outer_code_fence(plain), plain)

    def test_does_not_touch_a_fence_embedded_in_a_longer_explanation(self):
        prose = "This function does the following:\n\n```cpp\nint x = 1;\n```\n\nNote the missing null check."
        self.assertEqual(strip_outer_code_fence(prose), prose)

    def test_unterminated_fence_is_left_alone(self):
        broken = "```cpp\nint x = 1;"
        self.assertEqual(strip_outer_code_fence(broken), broken)

    def test_empty_string_is_safe(self):
        self.assertEqual(strip_outer_code_fence(""), "")

    def test_fence_containing_triple_backticks_inside_is_still_matched_conservatively(self):
        tricky = "```cpp\nint x = 1;\n```\nextra\n```"
        result = strip_outer_code_fence(tricky)
        self.assertIsInstance(result, str)


if __name__ == "__main__":
    unittest.main()
