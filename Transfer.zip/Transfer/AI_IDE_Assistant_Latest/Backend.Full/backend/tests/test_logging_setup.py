import io
import logging
import unittest

from app.logging.setup import configure_logging


class ConfigureLoggingTests(unittest.TestCase):
    def setUp(self):
        self.root = logging.getLogger()
        self._original_handlers = list(self.root.handlers)
        self._original_level = self.root.level
        for h in self._original_handlers:
            self.root.removeHandler(h)

    def tearDown(self):
        for h in list(self.root.handlers):
            self.root.removeHandler(h)
        for h in self._original_handlers:
            self.root.addHandler(h)
        self.root.setLevel(self._original_level)

    def test_child_logger_records_are_redacted(self):
        configure_logging()

        stream = io.StringIO()
        for h in self.root.handlers:
            if isinstance(h, logging.StreamHandler):
                h.stream = stream

        child_logger = logging.getLogger("app.api.chat")
        child_logger.warning("failed request with api_key=sk-realsecretvalue")

        output = stream.getvalue()
        self.assertNotIn("sk-realsecretvalue", output)
        self.assertIn("[REDACTED]", output)

    def test_idempotent_does_not_duplicate_filters_or_handlers(self):
        configure_logging()
        configure_logging()
        configure_logging()

        self.assertEqual(len(self.root.handlers), 1)
        total_filters = sum(len(h.filters) for h in self.root.handlers)
        self.assertEqual(total_filters, 1)


if __name__ == "__main__":
    unittest.main()
