import tempfile
import unittest
import unittest.mock
from pathlib import Path

from app.rag.ingestion.loader import UnsupportedDocumentTypeError, load_document, load_text


class LoadTextTests(unittest.TestCase):
    def test_reads_markdown_content(self):
        with tempfile.TemporaryDirectory() as tmp:
            doc = Path(tmp) / "guide.md"
            doc.write_text("# Title\n\nSome content.", encoding="utf-8")
            self.assertEqual(load_document(doc), "# Title\n\nSome content.")

    def test_reads_plain_txt(self):
        with tempfile.TemporaryDirectory() as tmp:
            doc = Path(tmp) / "notes.txt"
            doc.write_text("plain text notes", encoding="utf-8")
            self.assertEqual(load_document(doc), "plain text notes")

    def test_unsupported_extension_raises(self):
        with tempfile.TemporaryDirectory() as tmp:
            doc = Path(tmp) / "image.png"
            doc.write_bytes(b"\x89PNG")
            with self.assertRaises(UnsupportedDocumentTypeError):
                load_document(doc)

    def test_pdf_without_pypdf_raises_clear_import_error(self):
        # pypdf IS installed in this sandbox (confirmed separately), so this
        # test simulates its absence via the standard sys.modules trick
        # rather than asserting on an environment property that's actually
        # false — see test_real_pdf_round_trip below for the
        # pypdf-installed path, which is the one that matters most.
        import sys
        import app.rag.ingestion.loader as loader_module

        with tempfile.TemporaryDirectory() as tmp:
            doc = Path(tmp) / "standard.pdf"
            doc.write_bytes(b"%PDF-1.4 fake")

            with unittest.mock.patch.dict(sys.modules, {"pypdf": None}):
                with self.assertRaises(ImportError) as ctx:
                    loader_module.load_pdf(doc)
                self.assertIn("pypdf", str(ctx.exception))

    def test_real_pdf_round_trip(self):
        # pypdf and reportlab are both actually installed here, so this
        # generates a real PDF and confirms load_document genuinely
        # extracts its text — not just that the code path doesn't crash.
        from reportlab.pdfgen import canvas

        with tempfile.TemporaryDirectory() as tmp:
            pdf_path = Path(tmp) / "standard.pdf"
            c = canvas.Canvas(str(pdf_path))
            c.drawString(100, 750, "Use smart pointers for ownership.")
            c.save()

            text = load_document(pdf_path)
            self.assertIn("Use smart pointers for ownership.", text)

    def test_real_docx_round_trip(self):
        # python-docx is actually installed here too.
        import docx

        with tempfile.TemporaryDirectory() as tmp:
            docx_path = Path(tmp) / "standard.docx"
            document = docx.Document()
            document.add_paragraph("Avoid raw owning pointers.")
            document.save(str(docx_path))

            text = load_document(docx_path)
            self.assertIn("Avoid raw owning pointers.", text)


if __name__ == "__main__":
    unittest.main()
