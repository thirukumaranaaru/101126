import unittest

from app.services.code_actions import CodeAction, build_prompt


class ConversionPromptTests(unittest.TestCase):
    def test_algorithm_to_code_requires_language_at_api_boundary(self):
        prompt = build_prompt("algorith_to_code", "Read two numbers and add them.", "C++")
        self.assertIn("C++", prompt)
        self.assertIn("Read two numbers", prompt)

    def test_code_to_algorithm_preserves_source(self):
        prompt = build_prompt("code_to_algorithm", "for (int i = 1; i <= n; i++) result *= i;")
        self.assertIn("for (int i = 1; i <= n; i++)", prompt)
        self.assertIn("exactly as written", prompt)

    def test_required_wire_identifier_is_preserved(self):
        self.assertEqual(CodeAction.ALGORITHM_TO_CODE.value, "algorith_to_code")
        self.assertIn("C++", build_prompt("algorith_to_code", "Add two numbers", "C++"))

    def test_algorithm_to_code_requires_language(self):
        with self.assertRaises(ValueError):
            build_prompt("algorith_to_code", "Read input")


if __name__ == "__main__":
    unittest.main()
