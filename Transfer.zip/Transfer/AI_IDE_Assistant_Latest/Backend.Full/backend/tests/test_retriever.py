import asyncio
import unittest
from typing import List, Optional

from app.rag.embeddings import EmbeddingService
from app.rag.models import ChunkMetadata, DocumentChunk
from app.rag.reranker import Reranker, RerankResult
from app.rag.retriever import Retriever
from app.rag.vectorstore import InMemoryVectorStore


class FakeEmbeddingService(EmbeddingService):
    """Deterministic: embeds a string as a one-hot-ish vector based on a
    keyword, so retrieval tests can predict which chunk should win without
    needing a real model."""

    def __init__(self, keyword_to_vector):
        self._map = keyword_to_vector

    async def embed(self, texts: List[str]) -> List[List[float]]:
        result = []
        for text in texts:
            vec = [0.0, 0.0, 0.0]
            for keyword, v in self._map.items():
                if keyword in text:
                    vec = v
                    break
            result.append(vec)
        return result


class IdentityReranker(Reranker):
    """Passes vector-search order through unchanged — used to isolate
    retrieval tests from reranking behavior."""

    async def rerank(self, query: str, texts: List[str]) -> List[RerankResult]:
        return [RerankResult(index=i, score=1.0 - i * 0.01) for i in range(len(texts))]


class PreferSecondReranker(Reranker):
    """Always ranks whichever candidate came last in vector order as most
    relevant. Used only to prove, in a genuine vector-similarity tie, that
    the reranker's decision — not vector order — determines the final
    result. Properly sorts its own output descending by score, honoring
    the Reranker contract (unlike a broken reranker that returned
    unsorted results, which real TeiRerankerProvider explicitly guards
    against with its own sort)."""

    async def rerank(self, query: str, texts: List[str]) -> List[RerankResult]:
        n = len(texts)
        results = [RerankResult(index=i, score=1.0 if i == n - 1 else 0.0) for i in range(n)]
        return sorted(results, key=lambda r: r.score, reverse=True)


def mandatory_chunk(name, priority=1, scope=None):
    return DocumentChunk(
        chunk_id=name,
        text=f"mandatory rule: {name}",
        metadata=ChunkMetadata(
            document_name=name, document_version="1.0", is_mandatory=True,
            priority_tier=priority, applicable_scope=scope,
        ),
    )


class RetrieverContextualTests(unittest.TestCase):
    def _make_populated_store(self):
        store = InMemoryVectorStore()
        asyncio.run(store.upsert([
            DocumentChunk(
                chunk_id="pointers-doc",
                text="use smart pointers for ownership",
                metadata=ChunkMetadata(document_name="d", document_version="1.0"),
                embedding=[1.0, 0.0, 0.0],
            ),
            DocumentChunk(
                chunk_id="naming-doc",
                text="use camelCase for variable names",
                metadata=ChunkMetadata(document_name="d", document_version="1.0"),
                embedding=[0.0, 1.0, 0.0],
            ),
        ]))
        return store

    def test_retrieves_the_semantically_closer_chunk(self):
        store = self._make_populated_store()
        embeddings = FakeEmbeddingService({"pointer": [1.0, 0.0, 0.0], "naming": [0.0, 1.0, 0.0]})
        retriever = Retriever(embeddings, store, reranker=IdentityReranker(), rerank_top_k=1)

        prompt = asyncio.run(retriever.build_augmented_prompt("how should I manage pointer ownership?", []))
        self.assertIn("smart pointers", prompt)
        self.assertNotIn("camelCase", prompt)

    def test_reranker_output_order_wins_over_vector_order(self):
        store = self._make_populated_store()
        # Both chunks have identical cosine similarity to this query, so
        # vector order alone is a tie (stable sort keeps insertion order:
        # pointers-doc first, naming-doc second). PreferSecondReranker
        # always promotes whichever item was second — if the final result
        # is naming-doc, the reranker's decision won, not the vector tie.
        embeddings = FakeEmbeddingService({"anything": [1.0, 1.0, 0.0]})
        retriever = Retriever(embeddings, store, reranker=PreferSecondReranker(), rerank_top_k=1)

        prompt = asyncio.run(retriever.build_augmented_prompt("anything", []))
        self.assertIn("camelCase", prompt)
        self.assertNotIn("smart pointers", prompt)

    def test_no_reranker_falls_back_to_vector_order(self):
        store = self._make_populated_store()
        embeddings = FakeEmbeddingService({"pointer": [1.0, 0.0, 0.0]})
        retriever = Retriever(embeddings, store, reranker=None, rerank_top_k=1)
        prompt = asyncio.run(retriever.build_augmented_prompt("pointer question", []))
        self.assertIn("smart pointers", prompt)

    def test_empty_store_yields_none_retrieved(self):
        store = InMemoryVectorStore()
        embeddings = FakeEmbeddingService({})
        retriever = Retriever(embeddings, store, reranker=IdentityReranker())
        prompt = asyncio.run(retriever.build_augmented_prompt("anything", []))
        self.assertIn("(none retrieved)", prompt)


class RetrieverMandatoryIntegrationTests(unittest.TestCase):
    def test_mandatory_guidelines_bypass_the_vector_store_entirely(self):
        # Vector store is empty — proves mandatory guidelines don't depend
        # on it at all (SRS §11).
        store = InMemoryVectorStore()
        embeddings = FakeEmbeddingService({})
        retriever = Retriever(embeddings, store, reranker=IdentityReranker())

        all_mandatory = [mandatory_chunk("use-smart-pointers")]
        prompt = asyncio.run(retriever.build_augmented_prompt("write a class", all_mandatory))
        self.assertIn("use-smart-pointers", prompt)

    def test_scope_filtering_applied_before_conflict_resolution(self):
        store = InMemoryVectorStore()
        embeddings = FakeEmbeddingService({})
        retriever = Retriever(embeddings, store, reranker=IdentityReranker())

        all_mandatory = [
            mandatory_chunk("cpp-rule", scope="cpp"),
            mandatory_chunk("python-rule", scope="python"),
        ]
        prompt = asyncio.run(retriever.build_augmented_prompt("write code", all_mandatory, scope="cpp"))
        self.assertIn("cpp-rule", prompt)
        self.assertNotIn("python-rule", prompt)


if __name__ == "__main__":
    unittest.main()
