import unittest
from pathlib import Path

from app.rag.ingestion.cli import parse_args


class ParseArgsTests(unittest.TestCase):
    def test_source_dir_is_required(self):
        with self.assertRaises(SystemExit):
            parse_args([])

    def test_parses_source_dir_as_path(self):
        args = parse_args(["--source-dir", "/tmp/guidelines"])
        self.assertEqual(args.source_dir, Path("/tmp/guidelines"))

    def test_default_batch_size(self):
        args = parse_args(["--source-dir", "/tmp/guidelines"])
        self.assertEqual(args.batch_size, 32)

    def test_custom_batch_size(self):
        args = parse_args(["--source-dir", "/tmp/guidelines", "--batch-size", "8"])
        self.assertEqual(args.batch_size, 8)


if __name__ == "__main__":
    unittest.main()
