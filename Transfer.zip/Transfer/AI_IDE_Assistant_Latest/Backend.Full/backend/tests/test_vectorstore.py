import asyncio
import unittest

from app.rag.models import ChunkMetadata, DocumentChunk
from app.rag.vectorstore import InMemoryVectorStore


def chunk_with_vector(chunk_id, vector):
    return DocumentChunk(
        chunk_id=chunk_id,
        text=f"text for {chunk_id}",
        metadata=ChunkMetadata(document_name="doc", document_version="1.0"),
        embedding=vector,
    )


class InMemoryVectorStoreTests(unittest.TestCase):
    def test_query_returns_most_similar_first(self):
        store = InMemoryVectorStore()
        asyncio.run(store.upsert([
            chunk_with_vector("close", [1.0, 0.0, 0.0]),
            chunk_with_vector("far", [0.0, 1.0, 0.0]),
            chunk_with_vector("opposite", [-1.0, 0.0, 0.0]),
        ]))
        results = asyncio.run(store.query([0.9, 0.1, 0.0], top_k=3))
        self.assertEqual([r.chunk.chunk_id for r in results], ["close", "far", "opposite"])

    def test_top_k_limits_results(self):
        store = InMemoryVectorStore()
        asyncio.run(store.upsert([chunk_with_vector(f"c{i}", [float(i), 0.0]) for i in range(10)]))
        results = asyncio.run(store.query([5.0, 0.0], top_k=3))
        self.assertEqual(len(results), 3)

    def test_empty_store_returns_empty(self):
        store = InMemoryVectorStore()
        results = asyncio.run(store.query([1.0, 0.0], top_k=5))
        self.assertEqual(results, [])

    def test_upsert_of_same_id_replaces_not_duplicates(self):
        store = InMemoryVectorStore()
        asyncio.run(store.upsert([chunk_with_vector("a", [1.0, 0.0])]))
        asyncio.run(store.upsert([chunk_with_vector("a", [0.0, 1.0])]))
        results = asyncio.run(store.query([0.0, 1.0], top_k=10))
        self.assertEqual(len(results), 1)
        self.assertAlmostEqual(results[0].vector_score, 1.0, places=5)

    def test_scores_are_cosine_similarity_range(self):
        store = InMemoryVectorStore()
        asyncio.run(store.upsert([chunk_with_vector("a", [1.0, 0.0])]))
        results = asyncio.run(store.query([1.0, 0.0], top_k=1))
        self.assertAlmostEqual(results[0].vector_score, 1.0, places=5)


if __name__ == "__main__":
    unittest.main()
