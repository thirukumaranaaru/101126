import asyncio
import json
import tempfile
import unittest
from pathlib import Path
from typing import List

from app.rag.embeddings import EmbeddingService
from app.rag.ingestion.pipeline import discover_documents, ingest_directory
from app.rag.vectorstore import InMemoryVectorStore


class FixedVectorEmbeddingService(EmbeddingService):
    """Every text gets the same fixed-length vector — sufficient for
    proving the pipeline wires end to end without needing real semantics."""

    async def embed(self, texts: List[str]) -> List[List[float]]:
        return [[1.0, 0.0, 0.0] for _ in texts]


def write_doc_with_metadata(tmp: Path, name: str, content: str, **meta_overrides):
    doc = tmp / name
    doc.write_text(content, encoding="utf-8")
    meta = {"document_name": name, "document_version": "1.0"}
    meta.update(meta_overrides)
    sidecar = tmp / f"{name}.meta.json"
    sidecar.write_text(json.dumps(meta), encoding="utf-8")
    return doc


class DiscoverDocumentsTests(unittest.TestCase):
    def test_finds_documents_but_not_sidecars(self):
        with tempfile.TemporaryDirectory() as tmp_str:
            tmp = Path(tmp_str)
            write_doc_with_metadata(tmp, "a.md", "content a")
            write_doc_with_metadata(tmp, "b.md", "content b")
            found = discover_documents(tmp)
            names = {p.name for p in found}
            self.assertEqual(names, {"a.md", "b.md"})


class IngestDirectoryEndToEndTests(unittest.TestCase):
    def test_ingests_documents_into_vector_store(self):
        with tempfile.TemporaryDirectory() as tmp_str:
            tmp = Path(tmp_str)
            write_doc_with_metadata(
                tmp, "coding-standard.md",
                "Use smart pointers.\n\nAvoid raw owning pointers.",
                is_mandatory=True, priority_tier=5,
            )

            store = InMemoryVectorStore()
            count = asyncio.run(ingest_directory(tmp, FixedVectorEmbeddingService(), store))

            self.assertEqual(count, 2)  # two paragraphs -> two chunks
            results = asyncio.run(store.query([1.0, 0.0, 0.0], top_k=10))
            self.assertEqual(len(results), 2)
            texts = {r.chunk.text for r in results}
            self.assertIn("Use smart pointers.", texts)

    def test_missing_metadata_sidecar_is_skipped_not_fatal(self):
        with tempfile.TemporaryDirectory() as tmp_str:
            tmp = Path(tmp_str)
            # One good document, one with no sidecar at all.
            write_doc_with_metadata(tmp, "good.md", "Good content here.")
            (tmp / "orphan.md").write_text("No metadata for this one.", encoding="utf-8")

            store = InMemoryVectorStore()
            count = asyncio.run(ingest_directory(tmp, FixedVectorEmbeddingService(), store))

            # Only the well-formed document was ingested; the run didn't crash.
            self.assertEqual(count, 1)

    def test_mandatory_metadata_preserved_through_the_pipeline(self):
        with tempfile.TemporaryDirectory() as tmp_str:
            tmp = Path(tmp_str)
            write_doc_with_metadata(
                tmp, "mandatory.md", "Always validate input.",
                is_mandatory=True, priority_tier=9, category="security",
            )
            store = InMemoryVectorStore()
            asyncio.run(ingest_directory(tmp, FixedVectorEmbeddingService(), store))

            results = asyncio.run(store.query([1.0, 0.0, 0.0], top_k=10))
            self.assertTrue(results[0].chunk.metadata.is_mandatory)
            self.assertEqual(results[0].chunk.metadata.priority_tier, 9)
            self.assertEqual(results[0].chunk.metadata.category, "security")


if __name__ == "__main__":
    unittest.main()
