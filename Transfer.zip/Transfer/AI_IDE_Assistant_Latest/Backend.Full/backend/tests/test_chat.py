"""
NOTE: this file needs fastapi + httpx installed to run (TestClient requires
both). This sandbox has no network access to install them, so these tests are
syntax-checked here (see the ast.parse pass below and in chat history) but not
executed. Run `pip install -r requirements.txt -r requirements-dev.txt &&
pytest` on a machine with the packages available before trusting this beyond
that syntax check.
"""
from fastapi.testclient import TestClient

from app.api.chat import NO_VERIFIED_ANSWER, RAG_REQUIRED_SENTINEL, get_llm_service
from app.main import app
from tests.test_llm import FakeLLMService

client = TestClient(app)


def _override_llm(fake: FakeLLMService):
    app.dependency_overrides[get_llm_service] = lambda: fake


def _clear_overrides():
    app.dependency_overrides.clear()


def test_health():
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json() == {"status": "ok"}


def test_chat_returns_llm_reply():
    fake = FakeLLMService(fixed_reply="Quicksort is a divide-and-conquer algorithm.")
    _override_llm(fake)
    try:
        response = client.post("/api/chat", json={"message": "Explain quicksort", "history": []})
        assert response.status_code == 200
        body = response.json()
        assert body["reply"] == "Quicksort is a divide-and-conquer algorithm."
        assert body["history"][-2]["content"] == "Explain quicksort"
        assert body["history"][-1]["content"] == "Quicksort is a divide-and-conquer algorithm."
    finally:
        _clear_overrides()


def test_chat_preserves_and_forwards_history():
    fake = FakeLLMService(fixed_reply="follow-up answer")
    _override_llm(fake)
    try:
        history = [
            {"role": "user", "content": "hi"},
            {"role": "assistant", "content": "hello"},
        ]
        response = client.post("/api/chat", json={"message": "follow up", "history": history})
        assert response.status_code == 200
        body = response.json()
        assert len(body["history"]) == len(history) + 2
        # The fake provider recorded what it was actually called with.
        prompt, received_history = fake.calls[0]
        assert "follow up" in prompt
        assert "MANDATORY ORGANIZATIONAL GUIDELINES" in prompt
        assert [m.content for m in received_history] == ["hi", "hello"]
    finally:
        _clear_overrides()


def test_chat_maps_provider_error_to_502():
    from app.llm.base import LLMService
    from app.llm.local_llama_provider import LLMProviderError

    class BrokenLLMService(LLMService):
        async def generate(self, prompt, history=None):
            raise LLMProviderError("model server unreachable")

    _override_llm(BrokenLLMService())
    try:
        response = client.post("/api/chat", json={"message": "hi", "history": []})
        assert response.status_code == 502
    finally:
        _clear_overrides()


def test_chat_uses_rag_only_after_model_requests_it():
    """The model's private sentinel starts the RAG-only second pass."""
    from app.api.chat import get_retriever
    from app.llm.base import LLMService

    class TwoPassLLM(LLMService):
        def __init__(self):
            self.calls = []

        async def generate(self, prompt, history=None):
            self.calls.append((prompt, history or []))
            return RAG_REQUIRED_SENTINEL if len(self.calls) == 1 else "grounded answer"

    fake_llm = TwoPassLLM()
    _override_llm(fake_llm)

    class FakeRetriever:
        async def retrieve_contextual(self, user_request):
            assert user_request == "explain this"
            return ["retrieved chunk"]

        def build_augmented_prompt_from_context(
            self, user_request, mandatory_chunks, contextual_chunks, scope=None
        ):
            assert contextual_chunks == ["retrieved chunk"]
            return f"AUGMENTED[{user_request}]"

    app.dependency_overrides[get_retriever] = lambda: FakeRetriever()
    try:
        response = client.post("/api/chat", json={"message": "explain this", "history": []})
        assert response.status_code == 200
        assert response.json()["reply"] == "grounded answer"
        assert len(fake_llm.calls) == 2
        prompt, second_pass_history = fake_llm.calls[1]
        assert "AUGMENTED[explain this]" in prompt
        assert second_pass_history == []
    finally:
        _clear_overrides()


def test_chat_stops_if_rag_retrieval_raises_after_model_declines():
    """A RAG failure is not permission to make up a model-only answer."""
    from app.api.chat import get_retriever

    fake_llm = FakeLLMService(fixed_reply=RAG_REQUIRED_SENTINEL)
    _override_llm(fake_llm)

    class BrokenRetriever:
        async def retrieve_contextual(self, user_request):
            raise ConnectionError("qdrant unreachable")

    app.dependency_overrides[get_retriever] = lambda: BrokenRetriever()
    try:
        response = client.post("/api/chat", json={"message": "explain this", "history": []})
        assert response.status_code == 200
        assert response.json()["reply"] == NO_VERIFIED_ANSWER
        assert len(fake_llm.calls) == 1
    finally:
        _clear_overrides()


def test_chat_stops_when_rag_has_no_context():
    from app.api.chat import get_retriever

    fake_llm = FakeLLMService(fixed_reply=RAG_REQUIRED_SENTINEL)
    _override_llm(fake_llm)

    class EmptyRetriever:
        async def retrieve_contextual(self, user_request):
            return []

    app.dependency_overrides[get_retriever] = lambda: EmptyRetriever()
    try:
        response = client.post("/api/chat", json={"message": "unknown fact", "history": []})
        assert response.status_code == 200
        assert response.json()["reply"] == NO_VERIFIED_ANSWER
        assert len(fake_llm.calls) == 1
    finally:
        _clear_overrides()
