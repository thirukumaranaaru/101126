import io
import logging
import unittest

from app.logging.redaction import RedactionFilter, redact


class RedactFunctionTests(unittest.TestCase):
    def test_redacts_bearer_token(self):
        self.assertEqual(
            redact("Authorization: Bearer abc123.def456.ghi789"),
            "Authorization: Bearer [REDACTED]",
        )

    def test_redacts_api_key_assignment(self):
        result = redact("api_key=sk-1234567890abcdef")
        self.assertIn("[REDACTED]", result)
        self.assertNotIn("sk-1234567890abcdef", result)

    def test_redacts_password_assignment_with_quotes(self):
        result = redact('password: "hunter2hunter2"')
        self.assertNotIn("hunter2hunter2", result)

    def test_redacts_aws_access_key(self):
        result = redact("AKIAIOSFODNN7EXAMPLE")
        self.assertNotIn("AKIAIOSFODNN7EXAMPLE", result)

    def test_redacts_jwt(self):
        fake_jwt = "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiIxMjM0NTY3ODkwIn0.dozjgNryP4J3jVmNHl0w5N_XgL0n3I9PlFUP0THsR8U"
        result = redact(f"token was {fake_jwt}")
        self.assertNotIn(fake_jwt, result)

    def test_leaves_ordinary_text_unchanged(self):
        message = "Chat request completed in 340ms for action explain"
        self.assertEqual(redact(message), message)

    def test_does_not_over_redact_short_values(self):
        message = "key=on"
        self.assertEqual(redact(message), message)


class RedactionFilterEndToEndTests(unittest.TestCase):
    def test_filter_redacts_message_through_a_real_logger(self):
        logger = logging.getLogger("test_redaction_end_to_end")
        logger.setLevel(logging.WARNING)
        logger.addFilter(RedactionFilter())

        stream = io.StringIO()
        handler = logging.StreamHandler(stream)
        logger.addHandler(handler)
        try:
            logger.warning("token=supersecrettoken123")
        finally:
            logger.removeHandler(handler)

        output = stream.getvalue()
        self.assertNotIn("supersecrettoken123", output)
        self.assertIn("[REDACTED]", output)

    def test_filter_redacts_percent_style_args(self):
        logger = logging.getLogger("test_redaction_args")
        logger.setLevel(logging.WARNING)
        logger.addFilter(RedactionFilter())

        stream = io.StringIO()
        handler = logging.StreamHandler(stream)
        logger.addHandler(handler)
        try:
            logger.warning("Backend call failed with api_key=%s", "sk-realsecretvalue")
        finally:
            logger.removeHandler(handler)

        output = stream.getvalue()
        self.assertNotIn("sk-realsecretvalue", output)

    def test_filter_never_suppresses_the_record(self):
        result = RedactionFilter().filter(logging.LogRecord(
            name="x", level=logging.INFO, pathname="", lineno=0,
            msg="plain message", args=None, exc_info=None,
        ))
        self.assertTrue(result)


if __name__ == "__main__":
    unittest.main()
