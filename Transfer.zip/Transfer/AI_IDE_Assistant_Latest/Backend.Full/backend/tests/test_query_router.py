import unittest

from app.rag.query_router import Route, decide_route


class QueryRouterTests(unittest.TestCase):
    def test_general_question_is_direct(self):
        self.assertEqual(decide_route("What is recursion?").route, Route.DIRECT)

    def test_guideline_question_is_rag(self):
        self.assertEqual(decide_route("According to our coding guidelines, use what error handling?").route, Route.RAG)

    def test_compliance_is_rag(self):
        self.assertEqual(decide_route("Does this comply with project standards?").route, Route.RAG)

    def test_fallback_is_configurable(self):
        self.assertEqual(decide_route("How should I structure this?", fallback="rag").route, Route.RAG)

    def test_no_llm_is_needed_by_router(self):
        # The router is a pure function; this is also an offline smoke test.
        self.assertIn("route", decide_route("reverse a string").__dict__)


if __name__ == "__main__":
    unittest.main()
