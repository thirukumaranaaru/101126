import json
import tempfile
import unittest
from pathlib import Path

from app.rag.ingestion.metadata import MetadataError, load_metadata, parse_metadata_dict


class ParseMetadataDictTests(unittest.TestCase):
    def test_minimal_valid_metadata(self):
        meta = parse_metadata_dict({"document_name": "std", "document_version": "1.0"})
        self.assertEqual(meta.document_name, "std")
        self.assertEqual(meta.document_version, "1.0")
        self.assertEqual(meta.priority_tier, 0)
        self.assertFalse(meta.is_mandatory)

    def test_missing_required_field_raises(self):
        with self.assertRaises(MetadataError):
            parse_metadata_dict({"document_name": "std"})

    def test_full_metadata_parsed_correctly(self):
        meta = parse_metadata_dict({
            "document_name": "secure-coding",
            "document_version": "2.1",
            "section": "memory-safety",
            "category": "secure-coding-practice",
            "language": "cpp",
            "project": "ai-ide-assistant",
            "priority_tier": 5,
            "effective_date": "2025-06-01",
            "applicable_scope": "cpp",
            "status": "active",
            "is_mandatory": True,
        })
        self.assertEqual(meta.priority_tier, 5)
        self.assertEqual(meta.effective_date.isoformat(), "2025-06-01")
        self.assertTrue(meta.is_mandatory)

    def test_invalid_date_format_raises(self):
        with self.assertRaises(MetadataError):
            parse_metadata_dict({
                "document_name": "d", "document_version": "1", "effective_date": "06/01/2025",
            })

    def test_document_version_coerced_to_string(self):
        # A common authoring mistake: writing version as a bare number in JSON.
        meta = parse_metadata_dict({"document_name": "d", "document_version": 2})
        self.assertEqual(meta.document_version, "2")


class LoadMetadataFileTests(unittest.TestCase):
    def test_missing_sidecar_raises(self):
        with tempfile.TemporaryDirectory() as tmp:
            doc = Path(tmp) / "standards.md"
            doc.write_text("some content")
            with self.assertRaises(MetadataError):
                load_metadata(doc)

    def test_malformed_json_sidecar_raises(self):
        with tempfile.TemporaryDirectory() as tmp:
            doc = Path(tmp) / "standards.md"
            doc.write_text("content")
            sidecar = Path(tmp) / "standards.md.meta.json"
            sidecar.write_text("{not valid json")
            with self.assertRaises(MetadataError):
                load_metadata(doc)

    def test_valid_sidecar_loads_correctly(self):
        with tempfile.TemporaryDirectory() as tmp:
            doc = Path(tmp) / "standards.md"
            doc.write_text("content")
            sidecar = Path(tmp) / "standards.md.meta.json"
            sidecar.write_text(json.dumps({
                "document_name": "standards", "document_version": "1.0", "priority_tier": 3,
            }))
            meta = load_metadata(doc)
            self.assertEqual(meta.document_name, "standards")
            self.assertEqual(meta.priority_tier, 3)


if __name__ == "__main__":
    unittest.main()
