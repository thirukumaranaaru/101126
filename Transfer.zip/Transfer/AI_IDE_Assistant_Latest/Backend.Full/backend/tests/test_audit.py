import asyncio
import unittest
from unittest import mock

from app.services.audit import build_dsn, log_audit_event, sanitize_detail


class BuildDsnTests(unittest.TestCase):
    def test_builds_expected_postgres_dsn(self):
        dsn = build_dsn("localhost", 5432, "ai_ide_assistant", "app_user", "hunter2")
        self.assertEqual(dsn, "postgresql://app_user:hunter2@localhost:5432/ai_ide_assistant")


class SanitizeDetailTests(unittest.TestCase):
    def test_redacts_string_values(self):
        result = sanitize_detail({"note": "used api_key=sk-realsecretvalue"})
        self.assertNotIn("sk-realsecretvalue", result["note"])

    def test_leaves_non_string_values_unchanged(self):
        result = sanitize_detail({"count": 5, "flag": True, "note": "fine"})
        self.assertEqual(result["count"], 5)
        self.assertEqual(result["flag"], True)
        self.assertEqual(result["note"], "fine")

    def test_empty_detail_is_safe(self):
        self.assertEqual(sanitize_detail({}), {})


class LogAuditEventFailureHandlingTests(unittest.TestCase):
    def test_does_not_raise_when_postgres_is_unreachable(self):
        async def failing_execute(dsn, query, *args):
            raise ConnectionError("could not connect to postgres")

        with mock.patch("app.services.audit.postgres.execute", side_effect=failing_execute):
            asyncio.run(log_audit_event("postgresql://x", "test_event", {"k": "v"}))

    def test_calls_postgres_execute_with_sanitized_detail(self):
        captured = {}

        async def capturing_execute(dsn, query, *args):
            captured["dsn"] = dsn
            captured["args"] = args

        with mock.patch("app.services.audit.postgres.execute", side_effect=capturing_execute):
            asyncio.run(log_audit_event(
                "postgresql://x", "code_action_invoked",
                {"note": "token=supersecret123456"}, user_id="user-1",
            ))

        self.assertEqual(captured["dsn"], "postgresql://x")
        user_id, event_type, detail_json = captured["args"]
        self.assertEqual(user_id, "user-1")
        self.assertEqual(event_type, "code_action_invoked")
        self.assertNotIn("supersecret123456", detail_json)


if __name__ == "__main__":
    unittest.main()
