"""
SRS Section 21: rate limiting via Redis. Fails OPEN if Redis is
unreachable — matching this project's NFR-REL-1 pattern of a non-critical
dependency's outage never blocking the primary request path. Disclosed
trade-off: a Redis outage also disables rate limiting's protection.
Failing CLOSED is a one-line change in is_allowed's except clause if that
trade-off is preferred instead.

RateLimiter.is_allowed is fully unit-tested against a fake Redis client
(tests/test_rate_limit.py) — only the real Redis network client is
unexecuted here.
"""
import logging
import time

logger = logging.getLogger(__name__)


class RateLimiter:
    def __init__(self, redis_client, limit: int, window_seconds: int):
        self._redis = redis_client
        self._limit = limit
        self._window_seconds = window_seconds

    async def is_allowed(self, key: str) -> bool:
        try:
            count = await self._redis.incr(key)
            if count == 1:
                await self._redis.expire(key, self._window_seconds)
            return count <= self._limit
        except Exception as exc:  # noqa: BLE001 - see module docstring
            logger.warning("Rate limiter could not reach Redis, failing open: %s", exc)
            return True


def build_rate_limit_middleware(redis_client, limit: int, window_seconds: int):
    """Returns an ASGI-style HTTP middleware function. RateLimiter itself
    stays fastapi-free (see the deferred import below) so it can be unit
    tested without fastapi installed."""
    limiter = RateLimiter(redis_client, limit, window_seconds)

    async def rate_limit_middleware(request, call_next):
        from fastapi.responses import JSONResponse  # deferred: keep RateLimiter fastapi-free

        client_host = request.client.host if request.client else "unknown"
        window = int(time.time() // window_seconds)
        key = f"ratelimit:{client_host}:{window}"

        if not await limiter.is_allowed(key):
            return JSONResponse(
                status_code=429,
                content={"detail": "Rate limit exceeded. Please slow down."},
            )

        return await call_next(request)

    return rate_limit_middleware
