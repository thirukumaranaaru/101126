import os
from dataclasses import dataclass
from functools import lru_cache


@dataclass(frozen=True)
class Settings:
    """
    Externalized configuration (SRS FR-INFRA-1 / EC constraints: no hardcoded
    infrastructure addresses). Deliberately plain os.environ + dataclass rather
    than pydantic-settings/BaseSettings: that package's API differs between
    pydantic v1 and v2, and this sandbox has no network access to pin down
    which one your environment will actually install, so this avoids guessing.
    """

    backend_host: str = os.environ.get("BACKEND_HOST", "0.0.0.0")
    backend_port: int = int(os.environ.get("BACKEND_PORT", "8000"))

    # Phase 5 (FR-RAG-8, EC-6): never hardcode the model server address.
    llm_server_host: str = os.environ.get("LLM_SERVER_HOST", "localhost")
    llm_server_port: int = int(os.environ.get("LLM_SERVER_PORT", "11434"))
    llm_model: str = os.environ.get("LLM_MODEL", "llama3:8b")
    llm_timeout_seconds: float = float(os.environ.get("LLM_TIMEOUT_SECONDS", "180"))

    # Phase 9-11 (RAG). Disabled by default: the retrieval path depends on
    # Qdrant, an embedding server, and (optionally) a reranker server, none
    # of which exist yet in most deployments of this codebase as it stands.
    # With rag_enabled=False, a chat model knowledge gap returns the safe
    # no-verified-answer response because there is no retrieval path.
    rag_enabled: bool = os.environ.get("RAG_ENABLED", "false").lower() == "true"
    rag_ambiguous_fallback: str = os.environ.get("RAG_AMBIGUOUS_FALLBACK", "direct")

    # Embedding model, served from the same Ollama instance as the LLM
    # (see app/rag/embeddings.py for why).
    embedding_model: str = os.environ.get("EMBEDDING_MODEL", "nomic-embed-text")

    qdrant_host: str = os.environ.get("QDRANT_HOST", "localhost")
    qdrant_port: int = int(os.environ.get("QDRANT_PORT", "6333"))
    qdrant_collection: str = os.environ.get("QDRANT_COLLECTION", "ai_ide_assistant_guidelines")

    # Reranker is genuinely optional (SRS FR-RAG-4 says reranking is used
    # "where appropriate") — retriever.py falls back to plain vector order
    # if this is left unset.
    reranker_host: str = os.environ.get("RERANKER_HOST", "")
    reranker_port: int = int(os.environ.get("RERANKER_PORT", "8081"))

    rag_top_k: int = int(os.environ.get("RAG_TOP_K", "20"))
    rerank_top_k: int = int(os.environ.get("RERANK_TOP_K", "5"))
    rag_min_similarity: float = float(os.environ.get("RAG_MIN_SIMILARITY", "0.0"))
    rag_chunk_overlap_words: int = int(os.environ.get("RAG_CHUNK_OVERLAP_WORDS", "0"))
    pdf_ocr_enabled: bool = os.environ.get("PDF_OCR_ENABLED", "false").lower() == "true"

    # Directory of ingested mandatory-guideline source documents, loaded
    # into memory at startup (SRS §11: mandatory guidelines must never
    # depend on vector-ranking luck, so they are not fetched via similarity
    # search at request time — see app/rag/dependencies.py).
    mandatory_guidelines_dir: str = os.environ.get("MANDATORY_GUIDELINES_DIR", "")

    # Postgres (SRS Section 18): audit logging (app/services/audit.py).
    # Empty postgres_host means "not configured" — main.py's /ready
    # endpoint and chat.py/code_action.py skip audit logging entirely
    # rather than fail, matching the RAG_ENABLED-off pattern above.
    postgres_host: str = os.environ.get("POSTGRES_HOST", "")
    postgres_port: int = int(os.environ.get("POSTGRES_PORT", "5432"))
    postgres_db: str = os.environ.get("POSTGRES_DB", "ai_ide_assistant")
    postgres_user: str = os.environ.get("POSTGRES_USER", "ai_ide_assistant")
    postgres_password: str = os.environ.get("POSTGRES_PASSWORD", "")

    # Redis (SRS Section 21): rate limiting (app/middleware/rate_limit.py).
    # Empty redis_host means "not configured" — main.py skips installing
    # the rate-limit middleware entirely rather than fail at startup.
    redis_host: str = os.environ.get("REDIS_HOST", "")
    redis_port: int = int(os.environ.get("REDIS_PORT", "6379"))
    rate_limit_per_minute: int = int(os.environ.get("RATE_LIMIT_PER_MINUTE", "60"))

    # CORS (new: supports the standalone browser-based chat page used while
    # the Visual Studio extension isn't available/installed yet). Comma-
    # separated origins, or "*" for the pilot/dev default. Tighten this
    # before anything beyond local testing — SRS Section 33 hardening.
    cors_allowed_origins: str = os.environ.get("CORS_ALLOWED_ORIGINS", "*")

    # Phase 12 adds: keycloak_host, keycloak_port, keycloak_realm, keycloak_client_id


@lru_cache
def get_settings() -> Settings:
    return Settings()
