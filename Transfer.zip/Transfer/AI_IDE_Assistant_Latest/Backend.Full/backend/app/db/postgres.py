"""
Fixes the most serious gap found on audit: infrastructure/postgres/init.sql
defines a real schema and docker-compose.yml deploys a real PostgreSQL
container, but until this fix no application code ever connected to it.

UNEXECUTED in this project: no PostgreSQL instance exists in the sandbox
this was written in. asyncpg's pool/execute/fetch API is long-stable and
used with high confidence, but "high confidence" is not "verified."
"""
import logging

logger = logging.getLogger(__name__)

_pool = None


async def get_pool(dsn: str):
    global _pool
    if _pool is None:
        import asyncpg  # deferred: optional runtime dependency

        _pool = await asyncpg.create_pool(dsn=dsn, min_size=1, max_size=10)
    return _pool


async def close_pool() -> None:
    global _pool
    if _pool is not None:
        await _pool.close()
        _pool = None


async def ping(dsn: str, timeout_seconds: float = 3.0) -> bool:
    try:
        import asyncpg

        conn = await asyncpg.connect(dsn=dsn, timeout=timeout_seconds)
        try:
            await conn.execute("SELECT 1")
            return True
        finally:
            await conn.close()
    except Exception as exc:  # noqa: BLE001 - readiness checks must not raise
        logger.warning("Postgres readiness check failed: %s", exc)
        return False


async def execute(dsn: str, query: str, *args) -> None:
    pool = await get_pool(dsn)
    async with pool.acquire() as conn:
        await conn.execute(query, *args)


async def fetch(dsn: str, query: str, *args) -> list:
    pool = await get_pool(dsn)
    async with pool.acquire() as conn:
        return await conn.fetch(query, *args)
