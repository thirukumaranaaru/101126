"""Prompt templates and dispatch identifiers for supported code actions."""
from enum import Enum
from typing import Optional


class CodeAction(str, Enum):
    EXPLAIN = "explain"
    EVALUATE = "evaluate"
    FIX_ERRORS = "fix_errors"
    ALGORITHM_TO_CODE = "algorith_to_code"
    CODE_TO_ALGORITHM = "code_to_algorithm"


class UnknownCodeActionError(ValueError):
    pass


def _code_block(code: str, language: Optional[str]) -> str:
    return f"```{language or ''}\n{code}\n```"


def build_prompt(
    action: str,
    code: str,
    language: Optional[str] = None,
    file_name: Optional[str] = None,
    instruction: Optional[str] = None,
    compiler_error: Optional[str] = None,
) -> str:
    try:
        kind = CodeAction(action)
    except ValueError as exc:
        raise UnknownCodeActionError(f"Unknown code action: {action!r}") from exc

    context_lines = []
    if file_name:
        context_lines.append(f"File: {file_name}")
    if language:
        context_lines.append(f"Language: {language}")
    context = "\n".join(context_lines)
    code_block = _code_block(code, language)

    if kind == CodeAction.EXPLAIN:
        return (
            f"{context}\n\nExplain the following code: its overall purpose, the role "
            "of each function, its logic, dependencies, design decisions, and "
            f"potential issues.\n\n{code_block}"
        )

    if kind == CodeAction.EVALUATE:
        return (
            f"{context}\n\nEvaluate the following code for correctness, performance, "
            "security, maintainability, quality, error handling, and bugs. "
            f"Organize the answer under those headings.\n\n{code_block}"
        )

    if kind == CodeAction.FIX_ERRORS:
        if not compiler_error:
            raise ValueError("The 'fix_errors' action requires a non-empty compiler_error.")
        return (
            f"{context}\n\nThe code produces this compiler/build error:\n{compiler_error}\n\n"
            "Fix the code and return the complete corrected code with no explanation.\n\n"
            f"{code_block}"
        )

    if kind == CodeAction.ALGORITHM_TO_CODE:
        if not language or not language.strip():
            raise ValueError("The 'algorith_to_code' action requires a target language.")
        return build_algorithm_to_code_prompt(code, language.strip())

    if kind == CodeAction.CODE_TO_ALGORITHM:
        return build_code_to_algorithm_prompt(code)

    raise UnknownCodeActionError(f"Unhandled code action: {kind!r}")


def build_algorithm_to_code_prompt(algorithm: str, language: str) -> str:
    return (
        f"Implement the following algorithm in {language}. Preserve its exact logic, "
        "order, conditions, loops, calculations, inputs, and outputs. Handle relevant "
        "edge cases and invalid input. Include necessary imports, declarations, functions, "
        "and an entry point where appropriate. State assumptions briefly, then return "
        "readable syntactically appropriate code and a brief explanation. Do not claim "
        "compilation or execution.\n\n"
        f"ALGORITHM:\n{algorithm}"
    )


def build_code_to_algorithm_prompt(code: str) -> str:
    return (
        "Analyze the source code exactly as written and convert it into a clear numbered, "
        "sequential algorithm. Include inputs, calculations, conditions, loops, calls, "
        "outputs, return values, error handling, and relevant edge cases. Do not optimize "
        "or invent intended behavior. Identify missing dependencies, variables, or "
        "definitions when they limit the analysis. If the code is empty or incomplete, "
        "explain what is missing.\n\n"
        f"SOURCE CODE:\n{code}"
    )


REPLACE_SELECTION_ACTIONS = frozenset()
