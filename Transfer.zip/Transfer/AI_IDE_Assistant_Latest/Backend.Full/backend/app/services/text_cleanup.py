"""
Fixes a real, concrete bug found on audit: code_actions.py's prompts ask
the LLM to "return ONLY the complete code," but LLMs routinely ignore that
and wrap the answer in a markdown fence anyway. Without this, Replace
Selection (CodeActionResultWindow.xaml.cs, extension side) could insert
literal ``` markers into the developer's source file.

Deliberately conservative: only strips a fence that wraps the ENTIRE
response (the "LLM ignored the instruction" case). A fence that appears
partway through a longer explanation (legitimate for Explain Code/Evaluate
Code, which are prose responses that may quote code) is left alone —
stripping every fence anywhere in the text would mangle formatting that
was never wrong in the first place.
"""
import re

_FULL_WRAP_PATTERN = re.compile(
    r"^```[ \t]*([A-Za-z0-9_+-]*)[ \t]*\r?\n(.*?)\r?\n?```[ \t]*$",
    re.DOTALL,
)


def strip_outer_code_fence(text: str) -> str:
    """If `text`, once stripped of leading/trailing whitespace, is a single
    markdown code fence wrapping everything else, returns just the inner
    content. Otherwise returns `text` unchanged (not even whitespace-trimmed,
    so this is always safe to apply unconditionally)."""
    stripped = text.strip()
    match = _FULL_WRAP_PATTERN.match(stripped)
    if not match:
        return text
    return match.group(2)
