"""
SRS FR-SEC-6 / NFR-AUDIT-1. Writes to the audit_events table in
infrastructure/postgres/init.sql.

user_id is None for every event until Phase 12's actual auth code exists —
disclosed limitation, not a bug: the column and FK are ready for Phase 12
to populate.
"""
import json
import logging
from typing import Any, Dict, Optional

from app.db import postgres
from app.logging.redaction import redact

logger = logging.getLogger(__name__)


def build_dsn(host: str, port: int, database: str, user: str, password: str) -> str:
    """Pure, testable: no network or DB touched."""
    return f"postgresql://{user}:{password}@{host}:{port}/{database}"


def sanitize_detail(detail: Dict[str, Any]) -> Dict[str, Any]:
    """Defense in depth: run every string value through the same
    redaction patterns used for logs, even though callers are responsible
    for never putting secrets/source code into `detail` in the first
    place."""
    sanitized = {}
    for key, value in detail.items():
        sanitized[key] = redact(value) if isinstance(value, str) else value
    return sanitized


async def log_audit_event(
    dsn: str,
    event_type: str,
    detail: Optional[Dict[str, Any]] = None,
    user_id: Optional[str] = None,
) -> None:
    """Never raises — an audit-logging failure must not break the request
    it's trying to audit (same NFR-REL-1 pattern as the RAG fallback)."""
    safe_detail = sanitize_detail(detail or {})
    try:
        await postgres.execute(
            dsn,
            "INSERT INTO audit_events (user_id, event_type, detail) VALUES ($1, $2, $3::jsonb)",
            user_id,
            event_type,
            json.dumps(safe_detail),
        )
    except Exception as exc:  # noqa: BLE001 - see docstring
        logger.warning("Failed to write audit event %r: %s", event_type, exc)
