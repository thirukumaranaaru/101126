"""
Phase 5 (SRS NFR-MAINT-1, original spec Section 35): abstracts the concrete LLM
provider behind a small interface so a different locally-hosted model can be
substituted later without touching app/api/chat.py or app/api/code_action.py.

Deliberately depends on nothing but the standard library, so this contract can
be unit-tested in any environment — including one with no network access to
install third-party packages, which is exactly the constraint this sandbox
hit when trying to verify Phase 4's FastAPI code.
"""
from abc import ABC, abstractmethod
from typing import List, Optional


class LLMMessage:
    """A minimal role/content pair — avoids depending on pydantic here so this
    module has zero third-party dependencies."""

    __slots__ = ("role", "content")

    def __init__(self, role: str, content: str) -> None:
        self.role = role
        self.content = content

    def __eq__(self, other: object) -> bool:
        return (
            isinstance(other, LLMMessage)
            and self.role == other.role
            and self.content == other.content
        )

    def __repr__(self) -> str:
        return f"LLMMessage(role={self.role!r}, content={self.content!r})"


class LLMService(ABC):
    """Contract every concrete provider (Phase 5: local_llama_provider.py) must
    satisfy. api/chat.py and api/code_action.py depend on this type, not on a
    concrete provider, so the provider is swappable per Section 35 of the
    original specification."""

    @abstractmethod
    async def generate(
        self,
        prompt: str,
        history: Optional[List[LLMMessage]] = None,
    ) -> str:
        """Return a single completion for `prompt`, given optional prior turns."""
        raise NotImplementedError
