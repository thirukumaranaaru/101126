"""
Phase 5 concrete provider. Talks to a locally hosted Llama 3 8B instance served
by Ollama (SRS EC-6: no internet access; this only ever talks to a host/port on
the internal LAN, both externally configured per FR-INFRA-1).

Why Ollama specifically: the original specification's example configuration
(`LLM_SERVER_PORT=11434`, `LLM_MODEL=llama3:8b`) matches Ollama's default port
and model-tag naming convention exactly, so that's the serving layer assumed
here. If your organization serves Llama 3 8B a different way (e.g. vLLM's
OpenAI-compatible endpoint), only this file needs to change — that is the
point of the LLMService abstraction in base.py.

The request/response shape below was checked against Ollama's own API
documentation (docs.ollama.com/api/chat) rather than recalled from memory,
since getting this wrong would silently break every AI feature.
"""
from typing import List, Optional

import httpx

from app.llm.base import LLMMessage, LLMService


class LocalLlamaProvider(LLMService):
    def __init__(self, host: str, port: int, model: str, timeout_seconds: float = 60.0) -> None:
        self._base_url = f"http://{host}:{port}"
        self._model = model
        self._timeout = timeout_seconds

    async def generate(
        self,
        prompt: str,
        history: Optional[List[LLMMessage]] = None,
    ) -> str:
        messages = [{"role": m.role, "content": m.content} for m in (history or [])]
        messages.append({"role": "user", "content": prompt})

        payload = {
            "model": self._model,
            "messages": messages,
            "stream": False,
        }

        try:
            async with httpx.AsyncClient(timeout=self._timeout) as client:
                response = await client.post(f"{self._base_url}/api/chat", json=payload)
                response.raise_for_status()
                body = response.json()
        except httpx.TimeoutException as exc:
            raise LLMTimeoutError(
                f"LLM request timed out after {self._timeout:g} seconds. "
                "Increase LLM_TIMEOUT_SECONDS or check Ollama/model performance."
            ) from exc
        except httpx.HTTPStatusError as exc:
            raise LLMProviderError(
                f"LLM server returned HTTP {exc.response.status_code}."
            ) from exc
        except httpx.RequestError as exc:
            raise LLMProviderError(
                "LLM server is unreachable. Check LLM_SERVER_HOST and LLM_SERVER_PORT."
            ) from exc

        try:
            return body["message"]["content"]
        except (KeyError, TypeError) as exc:
            raise LLMProviderError(
                f"Unexpected response shape from LLM server: {body!r}"
            ) from exc


class LLMProviderError(RuntimeError):
    """Raised when the local model server is unreachable or returns something
    api/chat.py doesn't know how to interpret. Caught at the API layer (Phase 6)
    and turned into FR-PANEL-5's clear, actionable error state — never a raw
    stack trace back to the Visual Studio panel."""


class LLMTimeoutError(LLMProviderError):
    """The local model did not finish within the configured timeout."""
