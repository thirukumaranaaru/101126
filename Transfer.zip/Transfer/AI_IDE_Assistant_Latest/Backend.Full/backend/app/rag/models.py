"""
Shared value types for the RAG pipeline (SRS Section 12 metadata fields).
Pure stdlib (dataclasses only) so this module — and anything that only
needs these types — is testable without qdrant-client, tree-sitter, or any
embedding library installed.
"""
from dataclasses import dataclass, field
from datetime import date
from typing import Optional


@dataclass(frozen=True)
class ChunkMetadata:
    """SRS Section 12: "Metadata should include ... document name, version,
    section, category, programming language, project, priority, effective
    date, applicable scope, document status." """

    document_name: str
    document_version: str
    section: Optional[str] = None
    category: Optional[str] = None
    language: Optional[str] = None
    project: Optional[str] = None
    priority_tier: int = 0  # higher = takes precedence in conflicts, SRS §7.3
    effective_date: Optional[date] = None
    applicable_scope: Optional[str] = None
    status: str = "active"  # draft | active | superseded
    is_mandatory: bool = False  # SRS §7.1: mandatory guideline vs. contextual knowledge
    page_number: Optional[int] = None
    content_type: str = "text"
    source_reference: Optional[str] = None


@dataclass(frozen=True)
class DocumentChunk:
    """One chunk produced by the chunker, before or after embedding."""

    chunk_id: str
    text: str
    metadata: ChunkMetadata
    embedding: Optional[list] = field(default=None, compare=False)


@dataclass(frozen=True)
class ScoredChunk:
    """A chunk plus its retrieval and/or reranking score."""

    chunk: DocumentChunk
    vector_score: float
    rerank_score: Optional[float] = None
