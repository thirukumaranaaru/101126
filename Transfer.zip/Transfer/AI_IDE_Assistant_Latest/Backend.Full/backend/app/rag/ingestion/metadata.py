"""
SRS Section 12: metadata accompanying each ingested document. Metadata is
read from a JSON sidecar file next to the document (e.g.
coding-standards.md + coding-standards.meta.json) rather than parsed out of
the document body — deliberately simple and dependency-free so it's fully
testable, and so a RAG administrator can set metadata without editing the
document itself.
"""
import json
from datetime import date
from pathlib import Path
from typing import Optional

from app.rag.models import ChunkMetadata

REQUIRED_FIELDS = {"document_name", "document_version"}


class MetadataError(ValueError):
    pass


def sidecar_path_for(document_path: Path) -> Path:
    return document_path.with_suffix(document_path.suffix + ".meta.json")


def load_metadata(document_path: Path) -> ChunkMetadata:
    """Raises MetadataError if the sidecar is missing or malformed — an
    ingested document with no declared version/priority is exactly the
    kind of silent gap SRS §11 warns against, so this fails loudly rather
    than defaulting to values that would let it slip through unmarked."""
    sidecar = sidecar_path_for(document_path)
    if not sidecar.exists():
        raise MetadataError(f"Missing metadata sidecar: {sidecar}")

    try:
        raw = json.loads(sidecar.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise MetadataError(f"Malformed metadata sidecar {sidecar}: {exc}") from exc

    return parse_metadata_dict(raw, source=str(sidecar))


def parse_metadata_dict(raw: dict, source: str = "<dict>") -> ChunkMetadata:
    missing = REQUIRED_FIELDS - raw.keys()
    if missing:
        raise MetadataError(f"{source} is missing required field(s): {sorted(missing)}")

    effective_date: Optional[date] = None
    if raw.get("effective_date"):
        try:
            effective_date = date.fromisoformat(raw["effective_date"])
        except ValueError as exc:
            raise MetadataError(
                f"{source}: effective_date must be YYYY-MM-DD, got {raw['effective_date']!r}"
            ) from exc

    return ChunkMetadata(
        document_name=raw["document_name"],
        document_version=str(raw["document_version"]),
        section=raw.get("section"),
        category=raw.get("category"),
        language=raw.get("language"),
        project=raw.get("project"),
        priority_tier=int(raw.get("priority_tier", 0)),
        effective_date=effective_date,
        applicable_scope=raw.get("applicable_scope"),
        status=raw.get("status", "active"),
        is_mandatory=bool(raw.get("is_mandatory", False)),
    )
