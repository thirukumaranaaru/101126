"""
Closes a gap found on audit: the Phase-Wise Implementation Plan listed
`rag/ingestion/cli.py` as a Phase 9 deliverable; it never existed until
this fix.

Usage:
    python -m app.rag.ingestion.cli --source-dir /path/to/guidelines

Reads the same environment variables as the running backend
(EMBEDDING_MODEL, LLM_SERVER_HOST/PORT, QDRANT_HOST/PORT) via
app.config.settings.
"""
import argparse
import asyncio
import logging
import sys
from pathlib import Path

from app.config.settings import get_settings
from app.rag.embeddings import OllamaEmbeddingProvider
from app.rag.ingestion.pipeline import ingest_directory
from app.rag.vectorstore import QdrantVectorStore

logger = logging.getLogger(__name__)


def parse_args(argv=None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Ingest guideline documents into the RAG vector store."
    )
    parser.add_argument(
        "--source-dir", required=True, type=Path,
        help="Directory of documents plus their .meta.json sidecars.",
    )
    parser.add_argument(
        "--batch-size", type=int, default=32,
        help="Number of chunks embedded per batch (default: 32).",
    )
    return parser.parse_args(argv)


async def run(source_dir: Path, batch_size: int) -> int:
    if not source_dir.is_dir():
        logger.error("Source directory does not exist: %s", source_dir)
        return 1

    settings = get_settings()
    embeddings = OllamaEmbeddingProvider(
        host=settings.llm_server_host, port=settings.llm_server_port, model=settings.embedding_model,
    )
    vector_store = QdrantVectorStore(
        host=settings.qdrant_host, port=settings.qdrant_port, collection_name=settings.qdrant_collection,
    )

    count = await ingest_directory(
        source_dir,
        embeddings,
        vector_store,
        batch_size=batch_size,
        chunk_overlap_words=settings.rag_chunk_overlap_words,
        pdf_ocr_enabled=settings.pdf_ocr_enabled,
    )
    print(f"Ingested {count} chunks from {source_dir}")
    return 0


def main(argv=None) -> int:
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s: %(message)s")
    args = parse_args(argv)
    return asyncio.run(run(args.source_dir, args.batch_size))


if __name__ == "__main__":
    sys.exit(main())
