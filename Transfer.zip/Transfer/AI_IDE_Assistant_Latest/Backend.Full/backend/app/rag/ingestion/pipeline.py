"""
SRS Section 12 end-to-end: Internal Documents -> Parsing -> Chunking ->
Metadata -> Embedding -> Vector Database. Needs a real EmbeddingService and
VectorStore to actually run (both HTTP clients to services this sandbox
doesn't have) — the orchestration logic itself is written to depend only
on the abstractions, so it's the same code path that tests/test_retriever.py
exercises against InMemoryVectorStore, just not exercised here end-to-end
with real files.
"""
import logging
from dataclasses import replace
from pathlib import Path
from typing import List

from app.rag.chunker import chunk_code, chunk_text
from app.rag.embeddings import EmbeddingService
from app.rag.ingestion.loader import SUPPORTED_TEXT_EXTENSIONS, load_document
from app.rag.ingestion.metadata import load_metadata
from app.rag.models import DocumentChunk
from app.rag.ingestion.pdf_elements import extract_pdf_elements
from app.rag.vectorstore import VectorStore

logger = logging.getLogger(__name__)

CODE_EXTENSIONS = {".cpp", ".h", ".hpp", ".cs", ".py", ".java", ".ts", ".js"}


def discover_documents(source_dir: Path) -> List[Path]:
    """Every ingestible file under source_dir, skipping metadata sidecars
    themselves (*.meta.json)."""
    return [
        p for p in sorted(source_dir.rglob("*"))
        if p.is_file() and not p.name.endswith(".meta.json")
    ]


def chunk_document(
    path: Path,
    text: str,
    metadata,
    chunk_overlap_words: int = 0,
    pdf_ocr_enabled: bool = False,
) -> List[DocumentChunk]:
    if path.suffix.lower() == ".pdf":
        elements = extract_pdf_elements(path, ocr_enabled=pdf_ocr_enabled)
        if elements:
            chunks: List[DocumentChunk] = []
            for element_index, element in enumerate(elements):
                element_metadata = replace(
                    metadata,
                    page_number=element.page_number,
                    content_type=element.content_type,
                    source_reference=element.source_reference,
                )
                element_chunks = chunk_text(
                    element.text,
                    element_metadata,
                    overlap_words=chunk_overlap_words,
                )
                for chunk_index, chunk in enumerate(element_chunks):
                    chunks.append(
                        replace(
                            chunk,
                            chunk_id=f"{metadata.document_name}:{metadata.document_version}:p{element.page_number}:{element.content_type}:{element_index}:{chunk_index}",
                        )
                    )
            return chunks
    if path.suffix.lower() in CODE_EXTENSIONS:
        return chunk_code(text, metadata, language=metadata.language)
    return chunk_text(text, metadata, overlap_words=chunk_overlap_words)


async def ingest_directory(
    source_dir: Path,
    embedding_service: EmbeddingService,
    vector_store: VectorStore,
    batch_size: int = 32,
    chunk_overlap_words: int = 0,
    pdf_ocr_enabled: bool = False,
) -> int:
    """Returns the number of chunks ingested. Skips (with a logged warning,
    not a crash) any document missing its metadata sidecar or of an
    unsupported type, so one bad file doesn't abort an entire ingestion
    run — SRS NFR-REL-1's "graceful handling" principle applied to
    ingestion, not just request handling."""
    documents = discover_documents(source_dir)
    total_chunks = 0

    for path in documents:
        try:
            metadata = load_metadata(path)
        except Exception as exc:  # noqa: BLE001 - deliberately broad, see docstring
            logger.warning("Skipping %s: could not load metadata (%s)", path, exc)
            continue

        try:
            text = load_document(path)
        except Exception as exc:  # noqa: BLE001
            logger.warning("Skipping %s: could not load document (%s)", path, exc)
            continue

        chunks = chunk_document(
            path,
            text,
            metadata,
            chunk_overlap_words=chunk_overlap_words,
            pdf_ocr_enabled=pdf_ocr_enabled,
        )
        if not chunks:
            continue

        for i in range(0, len(chunks), batch_size):
            batch = chunks[i : i + batch_size]
            embeddings = await embedding_service.embed([c.text for c in batch])
            embedded_batch = [
                DocumentChunk(chunk_id=c.chunk_id, text=c.text, metadata=c.metadata, embedding=emb)
                for c, emb in zip(batch, embeddings)
            ]
            await vector_store.upsert(embedded_batch)
            total_chunks += len(embedded_batch)

    return total_chunks
