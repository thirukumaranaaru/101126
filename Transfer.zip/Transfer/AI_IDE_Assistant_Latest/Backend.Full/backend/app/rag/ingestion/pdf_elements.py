"""Optional PDF layout extraction for text, tables, and image/OCR markers.

The base loader remains usable without these optional packages. When
pdfplumber is installed, table boundaries and page numbers are preserved. OCR
is opt-in because it also requires a local Tesseract executable.
"""
import logging
from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class PdfElement:
    page_number: int
    content_type: str  # text, table, image
    text: str
    source_reference: str


def _table_to_text(table: list) -> str:
    rows = []
    for row in table or []:
        cells = ["" if cell is None else " ".join(str(cell).split()) for cell in row]
        if any(cells):
            rows.append(" | ".join(cells))
    if not rows:
        return ""
    return "TABLE\n" + "\n".join(rows)


def _ocr_page(page) -> Optional[str]:
    try:
        import pytesseract
        image = page.to_image(resolution=150).original
        text = pytesseract.image_to_string(image).strip()
        return text or None
    except ImportError:
        logger.info("PDF OCR skipped: pytesseract is not installed")
    except Exception as exc:  # OCR is enhancement, never a PDF-ingestion blocker
        logger.warning("PDF OCR failed on page: %s", type(exc).__name__)
    return None


def extract_pdf_elements(path: Path, *, ocr_enabled: bool = False) -> List[PdfElement]:
    """Extract page-aware elements, degrading safely when optional tooling is absent."""
    try:
        import pdfplumber
    except ImportError:
        logger.warning("pdfplumber is not installed; PDF tables/images use text-only fallback")
        return []

    elements: List[PdfElement] = []
    with pdfplumber.open(str(path)) as pdf:
        for page_number, page in enumerate(pdf.pages, start=1):
            reference = f"{path.name}#page={page_number}"
            page_text = (page.extract_text() or "").strip()
            if page_text:
                elements.append(PdfElement(page_number, "text", page_text, reference))

            for table in page.extract_tables() or []:
                table_text = _table_to_text(table)
                if table_text:
                    elements.append(PdfElement(page_number, "table", table_text, reference))

            image_count = len(getattr(page, "images", []) or [])
            if image_count:
                ocr_text = _ocr_page(page) if ocr_enabled else None
                image_text = (
                    f"IMAGE on page {page_number}; OCR text:\n{ocr_text}"
                    if ocr_text
                    else f"IMAGE on page {page_number}; visual content requires image review"
                )
                elements.append(PdfElement(page_number, "image", image_text, reference))

            if not page_text and not elements:
                logger.warning("PDF page %s contains no extractable text", page_number)

    return elements
