"""
SRS Section 12/44.4: ingestion must support the document formats the
organization actually provides (SRS A-5 assumes PDF, DOCX, Markdown pending
confirmation). Markdown/plain text need no extra dependencies. pypdf and
python-docx happen to be available in this sandbox, so load_pdf/load_docx
are genuinely tested here (see tests/test_ingestion_loader.py's real
round-trip tests) — but the target air-gapped environment must still have
both pre-staged per EC-6, since there's no guarantee they'll be present
there. The ImportError below is what a developer sees if they aren't.
"""
from pathlib import Path

SUPPORTED_TEXT_EXTENSIONS = {".md", ".markdown", ".txt"}
SUPPORTED_PDF_EXTENSIONS = {".pdf"}
SUPPORTED_DOCX_EXTENSIONS = {".docx"}
SUPPORTED_CODE_EXTENSIONS = {
    ".c", ".cc", ".cpp", ".h", ".hpp", ".cs", ".java", ".go", ".rs",
    ".py", ".js", ".jsx", ".ts", ".tsx", ".sql", ".sh", ".yaml", ".yml",
    ".json", ".xml", ".html", ".css",
}


class UnsupportedDocumentTypeError(ValueError):
    pass


def load_text(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def load_pdf(path: Path) -> str:
    try:
        from pypdf import PdfReader
    except ImportError as exc:
        raise ImportError(
            "Reading PDF documents requires the 'pypdf' package, which is "
            "not installed. Install it in the target environment (pre-staged "
            "per EC-6, not a runtime download) before ingesting PDFs."
        ) from exc

    reader = PdfReader(str(path))
    return "\n\n".join(page.extract_text() or "" for page in reader.pages)


def load_docx(path: Path) -> str:
    try:
        import docx
    except ImportError as exc:
        raise ImportError(
            "Reading DOCX documents requires the 'python-docx' package, "
            "which is not installed. Install it in the target environment "
            "(pre-staged per EC-6, not a runtime download) before ingesting "
            "DOCX files."
        ) from exc

    document = docx.Document(str(path))
    return "\n\n".join(p.text for p in document.paragraphs if p.text.strip())


def load_document(path: Path) -> str:
    suffix = path.suffix.lower()
    if suffix in SUPPORTED_TEXT_EXTENSIONS:
        return load_text(path)
    if suffix in SUPPORTED_PDF_EXTENSIONS:
        return load_pdf(path)
    if suffix in SUPPORTED_DOCX_EXTENSIONS:
        return load_docx(path)
    if suffix in SUPPORTED_CODE_EXTENSIONS:
        return load_text(path)
    raise UnsupportedDocumentTypeError(
        f"No loader for {suffix!r} ({path}). Supported: "
        f"{sorted(SUPPORTED_TEXT_EXTENSIONS | SUPPORTED_PDF_EXTENSIONS | SUPPORTED_DOCX_EXTENSIONS | SUPPORTED_CODE_EXTENSIONS)}"
    )
