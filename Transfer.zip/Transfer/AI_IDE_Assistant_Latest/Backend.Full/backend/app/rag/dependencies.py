"""
Phase 11 integration wiring. get_retriever() and get_mandatory_chunks() are
FastAPI dependencies used by app/api/chat.py and app/api/code_action.py.

Both are @lru_cache'd (constructed once per process, like get_llm_service
in app/api/chat.py) and both are None/empty when RAG isn't configured, so
existing deployments that never set RAG_ENABLED see no behavior change at
all — this module is inert until explicitly turned on.
"""
import logging
from functools import lru_cache
from pathlib import Path
from typing import List, Optional

from app.config.settings import get_settings
from app.rag.embeddings import OllamaEmbeddingProvider
from app.rag.ingestion.loader import load_document
from app.rag.ingestion.metadata import load_metadata
from app.rag.ingestion.pipeline import chunk_document, discover_documents
from app.rag.models import DocumentChunk
from app.rag.reranker import TeiRerankerProvider
from app.rag.retriever import Retriever
from app.rag.vectorstore import QdrantVectorStore

logger = logging.getLogger(__name__)


@lru_cache
def get_mandatory_chunks() -> List[DocumentChunk]:
    """
    SRS §11: mandatory guidelines must never depend on vector-ranking luck,
    so they're loaded directly into memory rather than fetched through
    Qdrant at request time. Re-ingesting the mandatory set currently
    requires a process restart (cache cleared) — a live-reload endpoint is
    a reasonable Phase 15 follow-up, not required for this to work
    correctly today.
    """
    settings = get_settings()
    if not settings.mandatory_guidelines_dir:
        return []

    directory = Path(settings.mandatory_guidelines_dir)
    if not directory.is_dir():
        logger.warning("MANDATORY_GUIDELINES_DIR %s does not exist; no mandatory guidelines loaded.", directory)
        return []

    chunks: List[DocumentChunk] = []
    for path in discover_documents(directory):
        try:
            metadata = load_metadata(path)
        except Exception as exc:  # noqa: BLE001 - one bad file must not block startup
            logger.warning("Skipping %s while loading mandatory guidelines: %s", path, exc)
            continue
        if not metadata.is_mandatory:
            continue
        try:
            text = load_document(path)
        except Exception as exc:  # noqa: BLE001
            logger.warning("Skipping %s while loading mandatory guidelines: %s", path, exc)
            continue
        chunks.extend(chunk_document(path, text, metadata))

    return chunks


@lru_cache
def get_retriever() -> Optional[Retriever]:
    settings = get_settings()
    if not settings.rag_enabled:
        return None

    embeddings = OllamaEmbeddingProvider(
        host=settings.llm_server_host, port=settings.llm_server_port, model=settings.embedding_model,
    )
    vector_store = QdrantVectorStore(
        host=settings.qdrant_host, port=settings.qdrant_port, collection_name=settings.qdrant_collection,
    )
    reranker = (
        TeiRerankerProvider(host=settings.reranker_host, port=settings.reranker_port)
        if settings.reranker_host
        else None
    )

    return Retriever(
        embedding_service=embeddings,
        vector_store=vector_store,
        reranker=reranker,
        vector_top_k=settings.rag_top_k,
        rerank_top_k=settings.rerank_top_k,
        min_similarity=settings.rag_min_similarity,
    )
