"""
SRS Section 16: a locally hosted cross-encoder reranker. Ollama has no
reranker support, so this targets Hugging Face's Text Embeddings Inference
(TEI) server instead — it explicitly supports cross-encoder rerankers
(e.g. BAAI/bge-reranker-v2-m3) and Hugging Face's own docs describe
deploying it in an air-gapped environment (download weights, mount via a
Docker volume), which fits SRS EC-6 directly. Verified against TEI's
documented /rerank endpoint via web search, not recalled from memory.
"""
from abc import ABC, abstractmethod
from typing import List, NamedTuple


class RerankResult(NamedTuple):
    index: int  # index into the original `texts` list passed to rerank()
    score: float


class Reranker(ABC):
    @abstractmethod
    async def rerank(self, query: str, texts: List[str]) -> List[RerankResult]:
        """Returns results sorted most-relevant-first. `index` refers back
        to the position in the input `texts` list, not the output order."""
        raise NotImplementedError


class RerankerError(RuntimeError):
    pass


class TeiRerankerProvider(Reranker):
    def __init__(self, host: str, port: int, timeout_seconds: float = 30.0) -> None:
        self._base_url = f"http://{host}:{port}"
        self._timeout = timeout_seconds

    async def rerank(self, query: str, texts: List[str]) -> List[RerankResult]:
        if not texts:
            return []

        import httpx  # deferred: optional runtime dependency, see module docstring

        payload = {"query": query, "texts": texts}

        async with httpx.AsyncClient(timeout=self._timeout) as client:
            response = await client.post(f"{self._base_url}/rerank", json=payload)
            response.raise_for_status()
            body = response.json()

        try:
            results = [RerankResult(index=item["index"], score=item["score"]) for item in body]
        except (KeyError, TypeError) as exc:
            raise RerankerError(f"Unexpected response shape from reranker: {body!r}") from exc

        return sorted(results, key=lambda r: r.score, reverse=True)
