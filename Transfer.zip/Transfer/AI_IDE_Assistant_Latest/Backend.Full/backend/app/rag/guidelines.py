"""
SRS FR-RAG-5/6/7 and Section 7 (Mandatory Guidelines vs Contextual
Knowledge). Pure stdlib — no vector store or embedding dependency, so the
conflict-resolution logic itself can be fully unit-tested independent of
whether Qdrant/Ollama-embeddings are reachable.
"""
from collections import defaultdict
from typing import List, Tuple

from app.rag.models import DocumentChunk


def is_applicable(chunk: DocumentChunk, scope: str = None) -> bool:
    """A chunk with no applicable_scope applies everywhere. Otherwise it
    only applies when the requested scope matches exactly (e.g. a language
    name). Superseded/draft documents are never applicable."""
    if chunk.metadata.status != "active":
        return False
    if chunk.metadata.applicable_scope is None:
        return True
    return scope is not None and chunk.metadata.applicable_scope == scope


def select_mandatory_chunks(chunks: List[DocumentChunk], scope: str = None) -> List[DocumentChunk]:
    """FR-RAG-5: the subset of chunks that must be included in the prompt
    regardless of vector-similarity ranking."""
    return [c for c in chunks if c.metadata.is_mandatory and is_applicable(c, scope)]


def resolve_conflicts(
    chunks: List[DocumentChunk],
) -> Tuple[List[DocumentChunk], List[List[DocumentChunk]]]:
    """
    SRS §7.3: groups chunks by (category, section) as a proxy for "same
    topic." Within each group:
      1. Keep only the chunk(s) with the highest priority_tier.
      2. If more than one remains, keep only the one(s) with the most
         recent effective_date.
      3. If more than one STILL remains, all of them are kept, and the
         group is also returned as an unresolved conflict (FR-RAG-7) —
         the caller (prompt_builder) surfaces this rather than silently
         picking one.

    Chunks with no category/section (grouping key is None) are never
    treated as conflicting with anything — there's no declared topic to
    conflict over.
    """
    groups = defaultdict(list)
    ungrouped = []
    for c in chunks:
        key = (c.metadata.category, c.metadata.section)
        if key == (None, None):
            ungrouped.append(c)
        else:
            groups[key].append(c)

    winners: List[DocumentChunk] = list(ungrouped)
    conflicts: List[List[DocumentChunk]] = []

    for _, group in groups.items():
        if len(group) == 1:
            winners.extend(group)
            continue

        max_priority = max(c.metadata.priority_tier for c in group)
        top_priority = [c for c in group if c.metadata.priority_tier == max_priority]

        if len(top_priority) == 1:
            winners.extend(top_priority)
            continue

        dated = [c for c in top_priority if c.metadata.effective_date is not None]
        if dated:
            # An undated chunk can never prove it's "more recent" than a
            # dated one, so it drops out of contention here rather than
            # counting as an unresolved tie.
            latest_date = max(c.metadata.effective_date for c in dated)
            candidates = [c for c in dated if c.metadata.effective_date == latest_date]
        else:
            # Nothing in this group has a date to break the tie with.
            candidates = top_priority

        winners.extend(candidates)
        if len(candidates) > 1:
            # Genuine, unresolved tie (FR-RAG-7): keep all of them, and
            # flag the group so the assistant can tell the developer
            # rather than silently picking one.
            conflicts.append(candidates)

    return winners, conflicts
