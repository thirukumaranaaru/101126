"""
SRS Section 15: a compact (~0.5-1.5B param), fully offline, locally hosted
embedding model. Reuses Ollama (already required for the LLM, Phase 5) by
serving an embedding model from the same Ollama instance — verified against
Ollama's own /api/embed documentation (docs.ollama.com/api/embed) via web
search, not recalled from memory, for the same reason local_llama_provider.py
was verified rather than guessed: getting this wire format wrong silently
breaks every retrieval-dependent feature.
"""
from abc import ABC, abstractmethod
from typing import List


class EmbeddingService(ABC):
    @abstractmethod
    async def embed(self, texts: List[str]) -> List[List[float]]:
        """Returns one embedding vector per input text, same order."""
        raise NotImplementedError


class EmbeddingProviderError(RuntimeError):
    """Mirrors LLMProviderError's role in app/llm/local_llama_provider.py —
    caught at the retriever layer and turned into a clear, logged failure
    rather than a raw exception."""


class OllamaEmbeddingProvider(EmbeddingService):
    def __init__(self, host: str, port: int, model: str, timeout_seconds: float = 30.0) -> None:
        self._base_url = f"http://{host}:{port}"
        self._model = model
        self._timeout = timeout_seconds

    async def embed(self, texts: List[str]) -> List[List[float]]:
        if not texts:
            return []

        import httpx  # deferred: optional runtime dependency, see module docstring

        payload = {"model": self._model, "input": texts}

        async with httpx.AsyncClient(timeout=self._timeout) as client:
            response = await client.post(f"{self._base_url}/api/embed", json=payload)
            response.raise_for_status()
            body = response.json()

        try:
            embeddings = body["embeddings"]
        except (KeyError, TypeError) as exc:
            raise EmbeddingProviderError(
                f"Unexpected response shape from embedding server: {body!r}"
            ) from exc

        if len(embeddings) != len(texts):
            raise EmbeddingProviderError(
                f"Expected {len(texts)} embeddings, got {len(embeddings)}"
            )

        return embeddings
