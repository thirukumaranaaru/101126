"""Small, offline-first routing policy for deciding whether RAG is needed."""
import re
from dataclasses import dataclass
from enum import Enum
from typing import Optional


class Route(str, Enum):
    DIRECT = "direct"
    RAG = "rag"


@dataclass(frozen=True)
class RoutingDecision:
    route: Route
    reason: str


_RAG_PATTERNS = (
    r"\b(our|internal|project|company|organization|team)\b",
    r"\b(coding|development|security|architecture)\s+(guidelines?|standards?|rules?|polic(?:y|ies))\b",
    r"\b(documentation|manuals?|procedures?|requirements?|specification|specs?)\b",
    r"\b(compliance|compliant|mandatory|according to|must follow|previously retrieved)\b",
    r"\b(project[- ]specific|internal api|indexed knowledge)\b",
)
_RAG_RE = re.compile("|".join(_RAG_PATTERNS), re.IGNORECASE)


def decide_route(
    text: str,
    *,
    fallback: str = "direct",
    force_rag: bool = False,
    operation: Optional[str] = None,
) -> RoutingDecision:
    """Return a route without calling an LLM or any external service.

    The fallback is used for ambiguous requests.  Explicit internal/compliance
    language wins over the fallback because missing a mandatory requirement is
    safer to avoid than an occasional extra retrieval.
    """
    if force_rag:
        return RoutingDecision(Route.RAG, "operation requires mandatory guideline review")
    if _RAG_RE.search(text or ""):
        return RoutingDecision(Route.RAG, "request references internal or mandatory knowledge")
    selected = Route.RAG if fallback.lower() == "rag" else Route.DIRECT
    suffix = f" for operation {operation}" if operation else ""
    return RoutingDecision(selected, f"no internal-knowledge signal{suffix}; configured fallback={selected.value}")
