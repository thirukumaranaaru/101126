"""
SRS §7.1: the final prompt must visibly separate Mandatory Organizational
Guidelines, Relevant Retrieved Knowledge, and the User Request/Code
Context — and a reserved token budget must protect the mandatory block
from being silently dropped by truncation.

Token counting here uses a whitespace-word-count proxy, not a real
tokenizer (tiktoken/the Llama 3 tokenizer aren't installed in this
sandbox). This is flagged explicitly rather than presented as exact: word
count under-counts real subword-tokenizer output for most English text, so
treat MANDATORY_TOKEN_RESERVE and any truncation here as conservative
estimates, not exact token budgets, until a real tokenizer is wired in.
"""
from typing import List, Optional

from app.rag.models import DocumentChunk

MANDATORY_TOKEN_RESERVE = 800  # SRS §11/34 "reserved token budget" — word-count proxy, see module docstring
CONTEXTUAL_TOKEN_BUDGET = 1200


def _word_count(text: str) -> int:
    return len(text.split())


def _truncate_to_words(text: str, max_words: int) -> str:
    words = text.split()
    if len(words) <= max_words:
        return text
    return " ".join(words[:max_words]) + " [...truncated]"


def _render_chunk(chunk: DocumentChunk) -> str:
    metadata = chunk.metadata
    source = metadata.source_reference or metadata.document_name
    page = f", page {metadata.page_number}" if metadata.page_number else ""
    content_type = metadata.content_type or "text"
    return f"[Source: {source}{page}; type: {content_type}]\n{chunk.text}"


def build_prompt(
    user_request: str,
    mandatory_chunks: List[DocumentChunk],
    contextual_chunks: List[DocumentChunk],
    unresolved_conflicts: Optional[List[List[DocumentChunk]]] = None,
) -> str:
    """
    Builds the full prompt text. Mandatory guidelines are truncated only if
    they alone exceed MANDATORY_TOKEN_RESERVE (should be rare — that budget
    exists specifically so this doesn't normally happen); contextual
    knowledge is truncated to fit CONTEXTUAL_TOKEN_BUDGET and is dropped
    entirely, chunk by chunk (dropping the lowest-ranked first), before any
    mandatory guideline is ever touched — reversing that priority would
    defeat the entire point of FR-RAG-6.
    """
    mandatory_text = "\n\n".join(_render_chunk(c) for c in mandatory_chunks)
    if _word_count(mandatory_text) > MANDATORY_TOKEN_RESERVE:
        mandatory_text = _truncate_to_words(mandatory_text, MANDATORY_TOKEN_RESERVE)

    contextual_parts = []
    budget_remaining = CONTEXTUAL_TOKEN_BUDGET
    for chunk in contextual_chunks:
        rendered = _render_chunk(chunk)
        cost = _word_count(rendered)
        if cost > budget_remaining:
            break  # drop this and all lower-ranked chunks after it
        contextual_parts.append(rendered)
        budget_remaining -= cost
    contextual_text = "\n\n".join(contextual_parts)

    sections = []
    sections.append("=== MANDATORY ORGANIZATIONAL GUIDELINES ===")
    sections.append(
        mandatory_text if mandatory_text else "(none applicable to this request)"
    )

    if unresolved_conflicts:
        sections.append("=== UNRESOLVED GUIDELINE CONFLICTS ===")
        sections.append(
            "The following guidelines conflict and could not be automatically "
            "resolved. State this limitation to the developer rather than "
            "silently picking one (SRS FR-RAG-7):"
        )
        for group in unresolved_conflicts:
            names = ", ".join(f"{c.metadata.document_name} v{c.metadata.document_version}" for c in group)
            sections.append(f"- {names}")

    sections.append("=== RELEVANT RETRIEVED KNOWLEDGE ===")
    sections.append(contextual_text if contextual_text else "(none retrieved)")

    sections.append("=== USER REQUEST / CODE CONTEXT ===")
    sections.append(user_request)

    return "\n\n".join(sections)
