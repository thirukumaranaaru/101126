"""
SRS Section 13 (RAG Retrieval Pipeline) end to end: Query -> Embedding ->
Vector Search -> Reranking -> mandatory-guideline merge -> Prompt.
Depends only on the abstractions (EmbeddingService, VectorStore, Reranker),
so it can be fully exercised in tests using InMemoryVectorStore and fake
embedding/reranker providers, without any of the real network services.
"""
from typing import List, Optional

from app.rag.embeddings import EmbeddingService
from app.rag.guidelines import resolve_conflicts, select_mandatory_chunks
from app.rag.models import DocumentChunk
from app.rag.prompt_builder import build_prompt
from app.rag.reranker import Reranker
from app.rag.vectorstore import VectorStore
import time
import logging

logger = logging.getLogger(__name__)


def _observe_metric(name: str, value: float) -> None:
    """Keep the retrieval core importable in lightweight/offline unit tests."""
    try:
        from app.monitoring import metrics
        getattr(metrics, name).observe(value)
    except (ImportError, AttributeError):
        # Metrics are operational telemetry, not a reason to break retrieval.
        logger.debug("metric_unavailable=%s", name)


class Retriever:
    def __init__(
        self,
        embedding_service: EmbeddingService,
        vector_store: VectorStore,
        reranker: Optional[Reranker] = None,
        vector_top_k: int = 20,
        rerank_top_k: int = 5,
        min_similarity: float = 0.0,
    ) -> None:
        self._embeddings = embedding_service
        self._vector_store = vector_store
        self._reranker = reranker
        self._vector_top_k = vector_top_k
        self._rerank_top_k = rerank_top_k
        self._min_similarity = min_similarity

    async def build_augmented_prompt(
        self,
        user_request: str,
        all_mandatory_chunks: List[DocumentChunk],
        scope: Optional[str] = None,
    ) -> str:
        """
        `all_mandatory_chunks` is the full set of mandatory guideline chunks
        known to the system (small enough to hold in memory and filter
        directly — SRS §11 is explicit that these must never depend on
        vector-ranking luck, so they are never fetched via similarity
        search). Contextual knowledge, by contrast, does go through the
        full embed -> search -> rerank pipeline.
        """
        contextual_chunks = await self.retrieve_contextual(user_request)
        return self.build_augmented_prompt_from_context(
            user_request,
            all_mandatory_chunks,
            contextual_chunks,
            scope=scope,
        )

    def build_augmented_prompt_from_context(
        self,
        user_request: str,
        all_mandatory_chunks: List[DocumentChunk],
        contextual_chunks: List[DocumentChunk],
        scope: Optional[str] = None,
    ) -> str:
        """Build an augmented prompt from context already retrieved once.

        The chat route uses this when an initial model-only attempt declares
        that it needs RAG.  Keeping retrieval and prompt construction
        separate prevents that route from embedding and searching the same
        question twice merely to inspect whether any context was found.
        """
        mandatory_candidates = select_mandatory_chunks(all_mandatory_chunks, scope=scope)
        mandatory_chunks, unresolved_conflicts = resolve_conflicts(mandatory_candidates)

        return build_prompt(
            user_request=user_request,
            mandatory_chunks=mandatory_chunks,
            contextual_chunks=contextual_chunks,
            unresolved_conflicts=unresolved_conflicts,
        )

    async def retrieve_contextual(self, user_request: str) -> List[DocumentChunk]:
        """Return contextual RAG chunks for a query, ordered by relevance."""
        embed_start = time.perf_counter()
        [query_embedding] = await self._embeddings.embed([user_request])
        _observe_metric("RAG_EMBEDDING_LATENCY", time.perf_counter() - embed_start)
        scored = await self._vector_store.query(query_embedding, top_k=self._vector_top_k)
        scored = [s for s in scored if s.vector_score >= self._min_similarity]

        if not scored or self._reranker is None:
            return [s.chunk for s in scored[: self._rerank_top_k]]

        rerank_start = time.perf_counter()
        rerank_results = await self._reranker.rerank(query=user_request, texts=[s.chunk.text for s in scored])
        _observe_metric("RAG_RERANKING_LATENCY", time.perf_counter() - rerank_start)
        top = rerank_results[: self._rerank_top_k]
        return [scored[r.index].chunk for r in top]
