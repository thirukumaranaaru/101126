"""
SRS Section 17: Qdrant as primary vector store, abstracted so pgvector (or,
here, an in-memory store for testing) can substitute without changing
Retriever. QdrantVectorStore's calls are verified against qdrant-client's
current (non-deprecated) API — query_points(), not the deprecated search()
— via web search of qdrant-client's own release notes, not memory.
InMemoryVectorStore is a real, tested implementation of the same interface,
used by tests/test_retriever.py so the retrieval/ranking logic can be
exercised without a running Qdrant instance.
"""
from abc import ABC, abstractmethod
from typing import List, Optional

from app.rag.models import DocumentChunk, ScoredChunk


class VectorStore(ABC):
    @abstractmethod
    async def upsert(self, chunks: List[DocumentChunk]) -> None:
        """Each chunk must already have `embedding` populated."""
        raise NotImplementedError

    @abstractmethod
    async def query(self, embedding: List[float], top_k: int) -> List[ScoredChunk]:
        raise NotImplementedError


class QdrantVectorStore(VectorStore):
    """
    UNEXECUTED in this project — qdrant-client is not installed in this
    sandbox (no network access to install it). Written against the
    documented, current (1.8+) API: PointStruct + client.upsert() for
    writes, client.query_points() (not the deprecated client.search()) for
    reads. Verify end-to-end against a real Qdrant instance before relying
    on this.
    """

    def __init__(self, host: str, port: int, collection_name: str) -> None:
        from qdrant_client import QdrantClient  # deferred import: optional dependency

        self._client = QdrantClient(host=host, port=port)
        self._collection_name = collection_name

    async def upsert(self, chunks: List[DocumentChunk]) -> None:
        from qdrant_client.models import Distance, PointStruct, VectorParams

        if not chunks:
            return
        if any(chunk.embedding is None for chunk in chunks):
            raise ValueError("Cannot store a chunk without an embedding")

        # Make ingestion self-starting. Existing collections are left intact;
        # a missing collection is created using the first embedding dimension.
        try:
            self._client.get_collection(self._collection_name)
        except Exception:  # qdrant-client raises an API error for a missing collection
            self._client.create_collection(
                collection_name=self._collection_name,
                vectors_config=VectorParams(size=len(chunks[0].embedding), distance=Distance.COSINE),
            )

        points = [
            PointStruct(
                id=chunk.chunk_id,
                vector=chunk.embedding,
                payload={
                    "text": chunk.text,
                    "document_name": chunk.metadata.document_name,
                    "document_version": chunk.metadata.document_version,
                    "category": chunk.metadata.category,
                    "section": chunk.metadata.section,
                    "priority_tier": chunk.metadata.priority_tier,
                    "is_mandatory": chunk.metadata.is_mandatory,
                    "status": chunk.metadata.status,
                    "applicable_scope": chunk.metadata.applicable_scope,
                    "page_number": chunk.metadata.page_number,
                    "content_type": chunk.metadata.content_type,
                    "source_reference": chunk.metadata.source_reference,
                },
            )
            for chunk in chunks
        ]
        # NOTE: qdrant-client is synchronous; FastAPI route handlers are
        # async. Wrap in run_in_executor at the call site (Retriever) rather
        # than blocking the event loop directly — flagged here since it's
        # exactly the kind of detail that's easy to get right in isolation
        # and wrong at the integration point.
        self._client.upsert(collection_name=self._collection_name, points=points)

    async def query(self, embedding: List[float], top_k: int) -> List[ScoredChunk]:
        from app.rag.models import ChunkMetadata

        result = self._client.query_points(
            collection_name=self._collection_name, query=embedding, limit=top_k
        )
        scored = []
        for point in result.points:
            payload = point.payload or {}
            metadata = ChunkMetadata(
                document_name=payload.get("document_name", "unknown"),
                document_version=payload.get("document_version", "unknown"),
                category=payload.get("category"),
                section=payload.get("section"),
                priority_tier=payload.get("priority_tier", 0),
                is_mandatory=payload.get("is_mandatory", False),
                status=payload.get("status", "active"),
                applicable_scope=payload.get("applicable_scope"),
                page_number=payload.get("page_number"),
                content_type=payload.get("content_type", "text"),
                source_reference=payload.get("source_reference"),
            )
            chunk = DocumentChunk(chunk_id=str(point.id), text=payload.get("text", ""), metadata=metadata)
            scored.append(ScoredChunk(chunk=chunk, vector_score=point.score))
        return scored


class PgVectorStore(VectorStore):
    """
    The pgvector alternative SRS Section 17 explicitly asked for ("use
    pgvector if the project needs a lighter architecture") — Qdrant was the
    only implementation that existed until this fix.

    UNEXECUTED in this project — no PostgreSQL+pgvector instance in this
    sandbox. The `<=>` cosine-distance operator (not `<->`, which is L2/
    Euclidean) was checked against pgvector's own README and several
    independent tutorials via web search — one source had the operator/
    index mapping backwards compared to every other source checked, which
    is exactly why this was verified against multiple independent sources.
    Similarity is computed as `1 - cosine_distance` so ScoredChunk.vector_score
    uses the same "higher is more similar" convention as InMemoryVectorStore
    and QdrantVectorStore.

    Expects a table already created via a migration such as:
        CREATE EXTENSION IF NOT EXISTS vector;
        CREATE TABLE rag_chunks (
            id TEXT PRIMARY KEY,
            embedding vector(<dimensions>),
            text TEXT NOT NULL,
            document_name TEXT NOT NULL, document_version TEXT NOT NULL,
            category TEXT, section TEXT, priority_tier INT DEFAULT 0,
            is_mandatory BOOLEAN DEFAULT false, status TEXT DEFAULT 'active',
            applicable_scope TEXT
        );
        CREATE INDEX ON rag_chunks USING hnsw (embedding vector_cosine_ops);
    Not included in infrastructure/postgres/init.sql — only needed if you
    choose PgVectorStore over QdrantVectorStore.
    """

    def __init__(self, dsn: str, table_name: str = "rag_chunks") -> None:
        self._dsn = dsn
        self._table = table_name

    async def upsert(self, chunks: List[DocumentChunk]) -> None:
        from app.db import postgres

        query = f"""
            INSERT INTO {self._table}
                (id, embedding, text, document_name, document_version,
                 category, section, priority_tier, is_mandatory, status, applicable_scope)
            VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)
            ON CONFLICT (id) DO UPDATE SET
                embedding = EXCLUDED.embedding, text = EXCLUDED.text,
                document_name = EXCLUDED.document_name, document_version = EXCLUDED.document_version,
                category = EXCLUDED.category, section = EXCLUDED.section,
                priority_tier = EXCLUDED.priority_tier, is_mandatory = EXCLUDED.is_mandatory,
                status = EXCLUDED.status, applicable_scope = EXCLUDED.applicable_scope
        """
        for chunk in chunks:
            vector_literal = "[" + ",".join(str(x) for x in chunk.embedding) + "]"
            await postgres.execute(
                self._dsn, query,
                chunk.chunk_id, vector_literal, chunk.text,
                chunk.metadata.document_name, chunk.metadata.document_version,
                chunk.metadata.category, chunk.metadata.section,
                chunk.metadata.priority_tier, chunk.metadata.is_mandatory,
                chunk.metadata.status, chunk.metadata.applicable_scope,
            )

    async def query(self, embedding: List[float], top_k: int) -> List[ScoredChunk]:
        from app.db import postgres
        from app.rag.models import ChunkMetadata

        vector_literal = "[" + ",".join(str(x) for x in embedding) + "]"
        query = f"""
            SELECT id, text, document_name, document_version, category, section,
                   priority_tier, is_mandatory, status, applicable_scope,
                   1 - (embedding <=> $1) AS similarity
            FROM {self._table}
            ORDER BY embedding <=> $1
            LIMIT $2
        """
        rows = await postgres.fetch(self._dsn, query, vector_literal, top_k)

        scored = []
        for row in rows:
            metadata = ChunkMetadata(
                document_name=row["document_name"], document_version=row["document_version"],
                category=row["category"], section=row["section"],
                priority_tier=row["priority_tier"], is_mandatory=row["is_mandatory"],
                status=row["status"], applicable_scope=row["applicable_scope"],
            )
            chunk = DocumentChunk(chunk_id=row["id"], text=row["text"], metadata=metadata)
            scored.append(ScoredChunk(chunk=chunk, vector_score=row["similarity"]))
        return scored


class InMemoryVectorStore(VectorStore):
    """Real, tested implementation using standard-library cosine similarity — not a
    mock. Used for local development and for testing Retriever's logic
    without a running Qdrant instance; not intended for production use
    (no persistence, no filtering, linear-scan search). It deliberately has
    no NumPy dependency so lightweight test environments do not need scientific
    Python packages."""

    def __init__(self) -> None:
        self._chunks: List[DocumentChunk] = []

    async def upsert(self, chunks: List[DocumentChunk]) -> None:
        existing_ids = {c.chunk_id for c in self._chunks}
        for chunk in chunks:
            if chunk.chunk_id in existing_ids:
                self._chunks = [c for c in self._chunks if c.chunk_id != chunk.chunk_id]
            self._chunks.append(chunk)

    async def query(self, embedding: List[float], top_k: int) -> List[ScoredChunk]:
        if not self._chunks:
            return []

        query_values = [float(value) for value in embedding]
        query_norm = sum(value * value for value in query_values) ** 0.5

        scored: List[ScoredChunk] = []
        for chunk in self._chunks:
            if chunk.embedding is None:
                continue
            chunk_values = [float(value) for value in chunk.embedding]
            if len(chunk_values) != len(query_values):
                continue
            chunk_norm = sum(value * value for value in chunk_values) ** 0.5
            denom = query_norm * chunk_norm
            dot_product = sum(left * right for left, right in zip(query_values, chunk_values))
            similarity = dot_product / denom if denom else 0.0
            scored.append(ScoredChunk(chunk=chunk, vector_score=similarity))

        scored.sort(key=lambda s: s.vector_score, reverse=True)
        return scored[:top_k]
