"""
SRS Section 14 (Code-Aware RAG): use tree-sitter to chunk source code along
structural boundaries (functions, classes) rather than blind character
counts.

tree-sitter is not installed in the sandbox this was written in (no
network access to install it — see chat history). Rather than write
tree-sitter-dependent code that can't be exercised at all here,
chunk_code() below tries to import tree-sitter lazily and falls back to a
simple, fully-tested paragraph/line-based splitter if it's unavailable,
logging which path it took. This means:
  - The fallback path (used by every test in this sandbox) is real,
    tested code, not a stub.
  - The tree-sitter path is written to the same output contract
    (list[DocumentChunk]) so swapping it in on a machine that has
    tree-sitter installed requires no caller changes — but it has NOT
    been executed anywhere in this project yet, and must be verified on
    a machine with tree-sitter installed before relying on it.
"""
import logging
from typing import List, Optional

from app.rag.models import ChunkMetadata, DocumentChunk

logger = logging.getLogger(__name__)

DEFAULT_MAX_CHUNK_WORDS = 200
DEFAULT_CHUNK_OVERLAP_WORDS = 0


def chunk_text(
    text: str,
    metadata: ChunkMetadata,
    max_words: int = DEFAULT_MAX_CHUNK_WORDS,
    overlap_words: int = DEFAULT_CHUNK_OVERLAP_WORDS,
) -> List[DocumentChunk]:
    """Paragraph-aware splitter for prose documents (guidelines, standards
    documents) — not code. Splits on blank lines first, then further splits
    any paragraph longer than max_words on word boundaries, so no chunk
    exceeds the limit and no chunk splits a paragraph unnecessarily."""
    paragraphs = [p.strip() for p in text.split("\n\n") if p.strip()]
    overlap_words = max(0, min(overlap_words, max_words - 1))
    chunks: List[DocumentChunk] = []
    index = 0

    for paragraph in paragraphs:
        words = paragraph.split()
        if len(words) <= max_words:
            pieces = [paragraph]
        else:
            step = max_words - overlap_words
            pieces = []
            for start in range(0, len(words), step):
                # Avoid creating a useless final fragment that is already
                # fully covered by the previous overlapping chunk.
                if start and len(words) - start <= overlap_words:
                    break
                pieces.append(" ".join(words[start : start + max_words]))

        for piece in pieces:
            chunks.append(
                DocumentChunk(
                    chunk_id=f"{metadata.document_name}:{metadata.document_version}:{index}",
                    text=piece,
                    metadata=metadata,
                )
            )
            index += 1

    return chunks


def _chunk_code_fallback(code: str, metadata: ChunkMetadata, max_lines: int) -> List[DocumentChunk]:
    """Line-based fallback: groups lines into chunks of at most max_lines,
    preferring to break on a blank line once at or past max_lines. If no
    blank line appears (e.g. a long function with no blank lines at all),
    a hard cap at 2 * max_lines forces a split anyway, so this never
    produces one unbounded chunk regardless of input shape. Not
    structure-aware — this is the degraded path, used whenever tree-sitter
    isn't available."""
    lines = code.splitlines()
    chunks: List[DocumentChunk] = []
    current: List[str] = []
    index = 0

    def flush():
        nonlocal index
        if current:
            chunks.append(
                DocumentChunk(
                    chunk_id=f"{metadata.document_name}:{metadata.document_version}:{index}",
                    text="\n".join(current),
                    metadata=metadata,
                )
            )
            index += 1
            current.clear()

    for line in lines:
        current.append(line)
        at_preferred_boundary = len(current) >= max_lines and line.strip() == ""
        at_hard_cap = len(current) >= max_lines * 2
        if at_preferred_boundary or at_hard_cap:
            flush()
    flush()

    return chunks


def chunk_code(
    code: str,
    metadata: ChunkMetadata,
    language: Optional[str] = None,
    max_lines: int = 80,
) -> List[DocumentChunk]:
    """
    Structure-aware chunking (SRS §14) when tree-sitter is available;
    otherwise the tested line-based fallback above. See module docstring —
    the tree-sitter branch is unexecuted in this environment.
    """
    try:
        import tree_sitter  # noqa: F401
        import tree_sitter_languages  # noqa: F401
    except ImportError:
        logger.warning(
            "tree-sitter not installed; chunk_code() is using the "
            "line-based fallback, not structure-aware chunking. This is "
            "expected in this sandbox and must be revisited once "
            "tree-sitter is available in the target environment."
        )
        return _chunk_code_fallback(code, metadata, max_lines)

    return _chunk_code_with_tree_sitter(code, metadata, language, max_lines)


def _chunk_code_with_tree_sitter(
    code: str, metadata: ChunkMetadata, language: Optional[str], max_lines: int
) -> List[DocumentChunk]:
    """
    UNEXECUTED in this project so far — written against tree-sitter's
    documented Python API but never run, because tree-sitter could not be
    installed in this sandbox (no network access). Verify this against a
    real tree-sitter installation before depending on it; do not assume it
    is correct just because it imports cleanly.

    Intended approach: parse with the language-specific grammar, walk the
    top-level nodes of the syntax tree, and emit one chunk per
    function/class/method definition (falling back to the line-based
    splitter for any span between top-level definitions, e.g. imports).
    """
    from tree_sitter_languages import get_parser  # type: ignore

    parser = get_parser(language or "python")
    tree = parser.parse(code.encode("utf-8"))
    source_lines = code.splitlines()

    definition_node_types = {
        "function_definition", "class_definition",  # python
        "function_declaration", "method_declaration", "class_declaration",  # c-like/java
        "function_item", "impl_item",  # rust
    }

    chunks: List[DocumentChunk] = []
    index = 0
    last_end_line = 0

    for node in tree.root_node.children:
        start_line, end_line = node.start_point[0], node.end_point[0]

        if node.type in definition_node_types:
            if start_line > last_end_line:
                gap_text = "\n".join(source_lines[last_end_line:start_line])
                if gap_text.strip():
                    chunks.append(DocumentChunk(
                        chunk_id=f"{metadata.document_name}:{metadata.document_version}:{index}",
                        text=gap_text, metadata=metadata,
                    ))
                    index += 1

            definition_text = "\n".join(source_lines[start_line : end_line + 1])
            chunks.append(DocumentChunk(
                chunk_id=f"{metadata.document_name}:{metadata.document_version}:{index}",
                text=definition_text, metadata=metadata,
            ))
            index += 1
            last_end_line = end_line + 1

    if last_end_line < len(source_lines):
        tail = "\n".join(source_lines[last_end_line:])
        if tail.strip():
            chunks.append(DocumentChunk(
                chunk_id=f"{metadata.document_name}:{metadata.document_version}:{index}",
                text=tail, metadata=metadata,
            ))

    return chunks
