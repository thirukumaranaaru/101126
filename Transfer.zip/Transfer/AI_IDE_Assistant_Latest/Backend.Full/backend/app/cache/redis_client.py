"""
Fixes another gap found on audit: docker-compose.yml deploys Redis, but
until this fix no application code used it. Implements rate limiting
(SRS Section 21); session/queue state and caching remain unbuilt.

UNEXECUTED in this project — no Redis instance in this sandbox. redis-py's
async client API (redis.asyncio) is long-stable.
"""
import logging

logger = logging.getLogger(__name__)

_client = None


def get_client(host: str, port: int):
    global _client
    if _client is None:
        import redis.asyncio as redis  # deferred: optional runtime dependency

        _client = redis.Redis(host=host, port=port, decode_responses=True)
    return _client


async def ping(host: str, port: int, timeout_seconds: float = 3.0) -> bool:
    try:
        import asyncio

        client = get_client(host, port)
        await asyncio.wait_for(client.ping(), timeout=timeout_seconds)
        return True
    except Exception as exc:  # noqa: BLE001 - readiness checks must not raise
        logger.warning("Redis readiness check failed: %s", exc)
        return False
