import logging

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.api.chat import router as chat_router
from app.api.code_action import router as code_action_router
from app.config.settings import get_settings
from app.logging.setup import configure_logging
from app.monitoring.metrics import metrics_endpoint, metrics_middleware
from app.services.audit import build_dsn

logger = logging.getLogger(__name__)


def create_app() -> FastAPI:
    configure_logging()

    settings = get_settings()
    app = FastAPI(title="AI IDE Assistant Backend", version="0.1.0")

    # New: CORS, added to support the standalone browser-based chat page
    # (docs/standalone-chat.html) used while the Visual Studio extension
    # isn't installed/available. The VS extension itself never needed this
    # — HttpClient in a .NET desktop app isn't subject to browser CORS at
    # all; only browser-origin JavaScript is. "*" is a pilot/dev default
    # (CORS_ALLOWED_ORIGINS setting) — tighten to specific origins before
    # this goes beyond local testing, per SRS Section 33.
    allowed_origins = (
        ["*"] if settings.cors_allowed_origins == "*"
        else [o.strip() for o in settings.cors_allowed_origins.split(",") if o.strip()]
    )
    app.add_middleware(
        CORSMiddleware,
        allow_origins=allowed_origins,
        allow_credentials=False,  # "*" origins and allow_credentials=True are mutually exclusive per the CORS spec
        allow_methods=["*"],
        allow_headers=["*"],
    )

    app.include_router(chat_router, prefix="/api", tags=["chat"])
    app.include_router(code_action_router, prefix="/api", tags=["code_action"])

    # Phase 13 (SRS FR-INFRA-4): request count/latency for every route,
    # scraped by Prometheus per infrastructure/prometheus/prometheus.yml.
    app.middleware("http")(metrics_middleware)

    # SRS Section 21: rate limiting via Redis — only installed if
    # REDIS_HOST is actually configured.
    if settings.redis_host:
        from app.cache.redis_client import get_client
        from app.middleware.rate_limit import build_rate_limit_middleware

        redis_client = get_client(settings.redis_host, settings.redis_port)
        app.middleware("http")(
            build_rate_limit_middleware(redis_client, settings.rate_limit_per_minute, window_seconds=60)
        )
    else:
        logger.info("REDIS_HOST not set — rate limiting is disabled.")

    @app.get("/health")
    def health() -> dict:
        """Pure liveness. Deliberately does NOT check dependencies — see
        /ready for that. Conflating the two means a slow Ollama would make
        an orchestrator think the whole process is dead and restart it,
        which fixes nothing."""
        return {"status": "ok"}

    @app.get("/ready")
    async def ready() -> dict:
        """Readiness: are this process's actual dependencies reachable
        right now. Fixes a gap found on audit — /health was previously the
        only endpoint and was unconditional, which is a liveness check
        wearing a readiness check's name."""
        checks = {}

        try:
            import httpx
            async with httpx.AsyncClient(timeout=3.0) as client:
                resp = await client.get(f"http://{settings.llm_server_host}:{settings.llm_server_port}/api/tags")
                checks["ollama"] = resp.status_code == 200
        except Exception:
            checks["ollama"] = False

        if settings.postgres_host:
            from app.db import postgres
            dsn = build_dsn(
                settings.postgres_host, settings.postgres_port, settings.postgres_db,
                settings.postgres_user, settings.postgres_password,
            )
            checks["postgres"] = await postgres.ping(dsn)

        if settings.redis_host:
            from app.cache import redis_client
            checks["redis"] = await redis_client.ping(settings.redis_host, settings.redis_port)

        if settings.rag_enabled:
            checks["qdrant_configured"] = bool(settings.qdrant_host)

        all_ready = all(checks.values()) if checks else True
        return {"ready": all_ready, "checks": checks}

    @app.get("/metrics")
    def metrics():
        return metrics_endpoint()

    return app


app = create_app()
