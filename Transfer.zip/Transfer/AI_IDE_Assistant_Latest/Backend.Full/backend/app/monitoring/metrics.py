"""
SRS FR-INFRA-4: expose request count, latency, and error rate to
Prometheus. Uses prometheus_client's documented, long-stable API
(Counter/Histogram/generate_latest) — not installed in the sandbox this
was written in (no network access), so this is syntax-checked but not
executed. The API surface used here has been stable for years; the risk
is lower than most of this project's unexecuted code, but "lower risk"
is not "verified" — test this for real before relying on it.
"""
import time
from typing import Callable

from starlette.requests import Request
from starlette.responses import Response

from prometheus_client import CONTENT_TYPE_LATEST, Counter, Histogram, generate_latest

REQUEST_COUNT = Counter(
    "ai_ide_assistant_http_requests_total",
    "Total HTTP requests handled by the backend",
    ["method", "path", "status_code"],
)

REQUEST_LATENCY = Histogram(
    "ai_ide_assistant_http_request_duration_seconds",
    "HTTP request latency in seconds",
    ["method", "path"],
)

LLM_LATENCY = Histogram(
    "ai_ide_assistant_llm_request_duration_seconds",
    "Latency of calls to the LLM provider (SRS FR-INFRA-4: LLM latency)",
)

RAG_RETRIEVAL_LATENCY = Histogram(
    "ai_ide_assistant_rag_retrieval_duration_seconds",
    "Latency of the RAG retrieval path (SRS FR-INFRA-4: RAG retrieval latency)",
)

RAG_EMBEDDING_LATENCY = Histogram("ai_ide_assistant_rag_embedding_duration_seconds", "Embedding latency")
RAG_RERANKING_LATENCY = Histogram("ai_ide_assistant_rag_reranking_duration_seconds", "Reranking latency")


async def metrics_middleware(request: Request, call_next: Callable) -> Response:
    """
    Registered in app/main.py via app.middleware("http"). Uses the raw
    request path template where available (request.scope["route"].path)
    to avoid a high-cardinality metric from path parameters — falls back
    to the raw path for routes that don't expose one (e.g. 404s).
    """
    start = time.perf_counter()
    response = await call_next(request)
    duration = time.perf_counter() - start

    route = request.scope.get("route")
    path_label = route.path if route is not None else request.url.path

    REQUEST_COUNT.labels(
        method=request.method, path=path_label, status_code=response.status_code
    ).inc()
    REQUEST_LATENCY.labels(method=request.method, path=path_label).observe(duration)

    return response


def metrics_endpoint() -> Response:
    return Response(content=generate_latest(), media_type=CONTENT_TYPE_LATEST)
