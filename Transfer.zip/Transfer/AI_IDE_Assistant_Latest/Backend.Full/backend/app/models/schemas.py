from typing import List, Optional

from pydantic import BaseModel, Field


class ChatMessage(BaseModel):
    role: str = Field(..., description="'user' or 'assistant'")
    content: str


class ChatRequest(BaseModel):
    message: str
    history: List[ChatMessage] = Field(default_factory=list)


class ChatResponse(BaseModel):
    reply: str
    history: List[ChatMessage]


class CodeActionRequest(BaseModel):
    """SRS FR-CTX-5: fields the extension sends for a code action. Field
    names here must match Models/CodeActionApiDtos.cs in the extension
    exactly (checked in the verification pass, not just by convention)."""

    action: Optional[str] = Field(
        None,
        description=(
            "One of: explain, evaluate, fix_errors, algorith_to_code, "
            "code_to_algorithm"
        ),
    )
    code: str = ""
    algorithm: Optional[str] = None
    source_code: Optional[str] = None
    language: Optional[str] = None
    file_name: Optional[str] = None
    instruction: Optional[str] = None
    compiler_error: Optional[str] = None
    # The two conversion operations intentionally use the existing dispatcher.
    # `code` carries the algorithm/source text, preserving old clients.
    operation: Optional[str] = None


class CodeActionResponse(BaseModel):
    result: str
    route: Optional[str] = None
    routing_reason: Optional[str] = None
    language_required: bool = False
    clarification_required: bool = False
