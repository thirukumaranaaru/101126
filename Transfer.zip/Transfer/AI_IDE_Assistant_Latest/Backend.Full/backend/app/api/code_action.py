import logging
import time
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException

from app.api.chat import get_llm_service
from app.llm.base import LLMService
from app.llm.local_llama_provider import LLMProviderError, LLMTimeoutError
from app.models.schemas import CodeActionRequest, CodeActionResponse
from app.monitoring.metrics import LLM_LATENCY, RAG_RETRIEVAL_LATENCY
from app.rag.dependencies import get_mandatory_chunks, get_retriever
from app.rag.retriever import Retriever
from app.services.code_actions import CodeAction, UnknownCodeActionError, build_prompt
from app.services.text_cleanup import strip_outer_code_fence
from app.rag.query_router import Route, decide_route
from app.config.settings import get_settings

logger = logging.getLogger(__name__)
router = APIRouter()


@router.post("/code-action", response_model=CodeActionResponse)
async def code_action(
    request: CodeActionRequest,
    llm_service: LLMService = Depends(get_llm_service),
    retriever: Optional[Retriever] = Depends(get_retriever),
) -> CodeActionResponse:
    """
    Phase 8 (SRS FR-CTX-6..13). Reuses the same LLMService dependency as
    /api/chat (Phase 5/6) — one provider instance, one place to swap it out.
    Phase 11 adds RAG augmentation behind the same RAG_ENABLED flag as chat.py,
    scoped to the code's language so a C++ guideline never leaks into a
    Python request (SRS §7, applicable_scope).
    """
    operation = request.operation or request.action
    if not operation:
        raise HTTPException(status_code=422, detail="An operation or action is required.")
    is_algorithm_to_code = operation == CodeAction.ALGORITHM_TO_CODE.value
    algorithm_text = request.algorithm if request.algorithm is not None else request.code
    source_text = request.source_code if request.source_code is not None else request.code

    if is_algorithm_to_code and not (request.language and request.language.strip()):
        logger.info("operation=%s validation_failure=language_required", operation)
        return CodeActionResponse(
            result="Please specify the programming language to use.",
            language_required=True,
            clarification_required=True,
        )

    if is_algorithm_to_code:
        if not algorithm_text.strip():
            return CodeActionResponse(
                result="Please provide the algorithm to convert.", clarification_required=True
            )
        base_prompt = build_prompt(operation, algorithm_text, request.language)
    elif operation == CodeAction.CODE_TO_ALGORITHM.value:
        if not source_text.strip():
            return CodeActionResponse(
                result="Please provide source code to analyze.", clarification_required=True
            )
        base_prompt = build_prompt(operation, source_text)
    else:
        try:
            base_prompt = build_prompt(
                action=operation,
                code=request.code,
                language=request.language,
                file_name=request.file_name,
                instruction=request.instruction,
                compiler_error=request.compiler_error,
            )
        except UnknownCodeActionError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        except ValueError as exc:
            # Missing instruction/compiler_error for modify/fix_errors.
            raise HTTPException(status_code=422, detail=str(exc)) from exc

    prompt = base_prompt
    force_guidelines = operation in {"explain", "evaluate", "fix_errors"}
    decision = decide_route(
        f"{request.instruction or ''}\n{algorithm_text if is_algorithm_to_code else source_text}",
        fallback=get_settings().rag_ambiguous_fallback,
        force_rag=force_guidelines,
        operation=operation,
    )
    logger.info("operation=%s route=%s routing_reason=%s", operation, decision.route.value, decision.reason)
    if retriever is not None and decision.route is Route.RAG:
        rag_start = time.perf_counter()
        try:
            prompt = await retriever.build_augmented_prompt(
                base_prompt, get_mandatory_chunks(), scope=request.language
            )
        except Exception as exc:  # noqa: BLE001 - RAG outage must not break code actions
            logger.warning("RAG retrieval failed, falling back to the base prompt: %s", exc)
            prompt = base_prompt
        finally:
            RAG_RETRIEVAL_LATENCY.observe(time.perf_counter() - rag_start)

    llm_start = time.perf_counter()
    try:
        result_text = await llm_service.generate(prompt)
    except LLMTimeoutError as exc:
        raise HTTPException(status_code=504, detail=str(exc)) from exc
    except LLMProviderError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc
    finally:
        LLM_LATENCY.observe(time.perf_counter() - llm_start)

    # Fixes a real bug found on audit: the prompt asks for "ONLY the code"
    # but LLMs routinely wrap it in a fence anyway. Safe to apply
    # unconditionally — see strip_outer_code_fence's docstring for why it
    # won't touch a fence embedded in a longer explanation.
    result_text = strip_outer_code_fence(result_text)

    return CodeActionResponse(result=result_text, route=decision.route.value, routing_reason=decision.reason)
