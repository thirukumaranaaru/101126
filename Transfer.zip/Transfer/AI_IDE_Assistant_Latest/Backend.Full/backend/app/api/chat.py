import logging
import time
from functools import lru_cache
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException

from app.config.settings import Settings, get_settings
from app.llm.base import LLMMessage, LLMService
from app.llm.local_llama_provider import LLMProviderError, LLMTimeoutError, LocalLlamaProvider
from app.models.schemas import ChatMessage, ChatRequest, ChatResponse
from app.monitoring.metrics import LLM_LATENCY, RAG_RETRIEVAL_LATENCY
from app.rag.dependencies import get_mandatory_chunks, get_retriever
from app.rag.query_router import Route, decide_route
from app.rag.retriever import Retriever

logger = logging.getLogger(__name__)
router = APIRouter()

# These values are protocol markers between the backend and the local model;
# they are never exposed in a ChatResponse.  A deliberately unusual marker
# makes an accidental normal-language match extremely unlikely.
RAG_REQUIRED_SENTINEL = "[[AI_IDE_RAG_REQUIRED]]"
NO_VERIFIED_ANSWER = "I don't have enough verified information to answer that."


@lru_cache
def get_llm_service() -> LLMService:
    """
    Constructed once per process. FastAPI's dependency-override mechanism lets
    tests replace this with a fake LLMService without touching this module —
    see tests/test_llm.py for the pure-abstraction test, and test_chat.py for
    the dependency-override pattern applied to this route.
    """
    settings: Settings = get_settings()
    return LocalLlamaProvider(
        host=settings.llm_server_host,
        port=settings.llm_server_port,
        model=settings.llm_model,
        timeout_seconds=settings.llm_timeout_seconds,
    )


def _build_rag_answer_prompt(augmented_prompt: str) -> str:
    """Constrain a RAG pass to retrieved knowledge, never a guess."""
    policy = (
        "Answer only when the relevant retrieved knowledge below directly supports "
        "the answer, while obeying every mandatory guideline. Do not supplement it "
        "with unstated facts or guesses. If it does not contain enough information, "
        "respond with exactly " + RAG_REQUIRED_SENTINEL + " and nothing else.\n\n"
    )
    return policy + augmented_prompt


def _build_direct_prompt(user_request: str) -> str:
    # Keep the stable prompt section name used by existing clients/tests, but
    # do not load or retrieve guideline documents on this route.
    return (
        "Answer the request directly from general programming knowledge and the "
        "conversation history. Do not invent project-specific facts.\n\n"
        "=== MANDATORY ORGANIZATIONAL GUIDELINES ===\n"
        "(not retrieved on the direct route)\n\n"
        f"USER REQUEST:\n{user_request}"
    )


async def _generate(
    llm_service: LLMService, prompt: str, history: list[LLMMessage]
) -> str:
    """Generate once and record latency for each of the possible two passes."""
    llm_start = time.perf_counter()
    try:
        return await llm_service.generate(prompt, history=history)
    finally:
        LLM_LATENCY.observe(time.perf_counter() - llm_start)


async def _retrieve_after_model_declines(
    request: ChatRequest, retriever: Optional[Retriever]
) -> Optional[str]:
    """Retrieve context once, stopping when none is available."""
    if retriever is None:
        return None

    start = time.perf_counter()
    try:
        contextual_chunks = await retriever.retrieve_contextual(request.message)
        if not contextual_chunks:
            return None
        return retriever.build_augmented_prompt_from_context(
            request.message, get_mandatory_chunks(), contextual_chunks
        )
    except Exception as exc:  # noqa: BLE001 - an unavailable RAG cannot justify a guess
        logger.warning("operation=chat rag_retrieval_error=%s", type(exc).__name__)
        return None
    finally:
        RAG_RETRIEVAL_LATENCY.observe(time.perf_counter() - start)


@router.post("/chat", response_model=ChatResponse)
async def chat(
    request: ChatRequest,
    llm_service: LLMService = Depends(get_llm_service),
    retriever: Optional[Retriever] = Depends(get_retriever),
) -> ChatResponse:
    """
    Routes locally before any embedding, Qdrant, or retrieval call. Direct
    requests use exactly one LLM call; RAG requests retrieve once and then
    use one grounded LLM call.
    """
    history = [LLMMessage(role=m.role, content=m.content) for m in request.history]
    decision = decide_route(request.message, fallback=get_settings().rag_ambiguous_fallback)
    logger.info("operation=chat route=%s routing_reason=%s", decision.route.value, decision.reason)
    try:
        if decision.route is Route.DIRECT or retriever is None:
            reply_text = await _generate(llm_service, _build_direct_prompt(request.message), history)
        else:
            augmented_prompt = await _retrieve_after_model_declines(request, retriever)
            if augmented_prompt is None:
                reply_text = NO_VERIFIED_ANSWER
            else:
                reply_text = await _generate(
                    llm_service, _build_rag_answer_prompt(augmented_prompt), []
                )
        # Backward-compatible escape hatch for clients/models that still emit
        # the historical sentinel. Routing itself never uses an LLM call.
        if decision.route is Route.DIRECT and reply_text.strip() == RAG_REQUIRED_SENTINEL:
            augmented_prompt = await _retrieve_after_model_declines(request, retriever)
            if augmented_prompt is None:
                reply_text = NO_VERIFIED_ANSWER
            else:
                reply_text = await _generate(
                    llm_service, _build_rag_answer_prompt(augmented_prompt), []
                )
    except LLMTimeoutError as exc:
        raise HTTPException(status_code=504, detail=str(exc)) from exc
    except LLMProviderError as exc:
        # FR-PANEL-5: a clear, actionable error — not a raw 500 with a stack trace.
        raise HTTPException(status_code=502, detail=str(exc)) from exc

    updated_history = list(request.history) + [
        ChatMessage(role="user", content=request.message),
        ChatMessage(role="assistant", content=reply_text),
    ]
    return ChatResponse(reply=reply_text, history=updated_history)
