"""
Wires RedactionFilter onto each HANDLER of the root logger — not the root
Logger object itself. That distinction matters and was verified by direct
experiment, not just reasoning about the docs: Python's logging
propagation walks a child logger's ancestors and invokes each ancestor's
HANDLERS on a record, but does NOT re-check each ancestor Logger's own
filters — only the originating logger's filters (and each handler's own
filters) are ever consulted. A filter added via root.addFilter(...) would
silently never fire for records from any child logger — i.e. every
logging.getLogger(__name__) call in this codebase, which is all of them.

Call configure_logging() once, at process startup (app/main.py).
"""
import logging

from app.logging.redaction import RedactionFilter


def configure_logging(level: int = logging.INFO) -> None:
    root = logging.getLogger()
    root.setLevel(level)

    if not root.handlers:
        handler = logging.StreamHandler()
        handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(name)s: %(message)s"))
        root.addHandler(handler)

    for handler in root.handlers:
        if not any(isinstance(f, RedactionFilter) for f in handler.filters):
            handler.addFilter(RedactionFilter())
