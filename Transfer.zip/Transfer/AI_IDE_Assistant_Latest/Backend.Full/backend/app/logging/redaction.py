"""
SRS FR-SEC-6 / Section 23: logs must exclude source code, secrets,
credentials, and tokens. Referenced by DOWNLOADS.md and the SDD as a
planned module but never actually created until this fix.

Registered on each Handler (not the Logger) — see app/logging/setup.py's
docstring for why that distinction is load-bearing, not stylistic.
"""
import re

_PATTERNS = [
    (re.compile(r"(?i)\bbearer\s+[A-Za-z0-9\-_.=]+"), "Bearer [REDACTED]"),
    (
        re.compile(
            r"(?i)\b(api[_-]?key|secret|password|passwd|token|access[_-]?key)"
            r"\s*[:=]\s*['\"]?[A-Za-z0-9\-_.\/+=]{6,}['\"]?"
        ),
        r"\1=[REDACTED]",
    ),
    (re.compile(r"\bAKIA[0-9A-Z]{16}\b"), "[REDACTED_AWS_KEY]"),
    (re.compile(r"\beyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\b"), "[REDACTED_JWT]"),
]


def redact(message: str) -> str:
    redacted = message
    for pattern, replacement in _PATTERNS:
        redacted = pattern.sub(replacement, redacted)
    return redacted


class RedactionFilter:
    """A logging.Filter (duck-typed). Redacts the fully-FORMATTED message
    (record.getMessage(), i.e. msg % args already combined) rather than
    msg and args separately — a real bug this project's own tests caught:
    %-style logging like logger.warning("failed with api_key=%s", secret)
    has the key name in msg ("api_key=%s") and the secret alone in args
    (no "api_key=" prefix), so neither piece alone matches a
    "key=value"-shaped pattern. Only the combined, rendered string does."""

    def filter(self, record) -> bool:
        try:
            rendered = record.getMessage()
        except Exception:
            record.msg = redact(str(record.msg)) if isinstance(record.msg, str) else record.msg
            return True

        record.msg = redact(rendered)
        record.args = None
        return True
