[CmdletBinding()]
param(
    [string]$ProjectRoot = ".",
    [string]$PythonCmd = "python",
    [string]$OllamaUrl = "http://localhost:11434",
    [int]$BackendPort = 8000,
    [switch]$EnableRag,
    [switch]$InstallDependencies
)

$ErrorActionPreference = "Stop"

function Step([string]$Message) {
    Write-Host ""
    Write-Host ("==> {0}" -f $Message) -ForegroundColor Cyan
}

function Test-HttpEndpoint([string]$Uri, [int]$TimeoutSec = 5) {
    try {
        Invoke-RestMethod -Uri $Uri -Method Get -TimeoutSec $TimeoutSec | Out-Null
        return $true
    }
    catch {
        return $false
    }
}

function Import-SimpleDotEnv([string]$Path) {
    if (-not (Test-Path -LiteralPath $Path)) {
        return
    }

    Get-Content -LiteralPath $Path | ForEach-Object {
        $line = $_.Trim()
        if ($line -and -not $line.StartsWith("#") -and $line -match '^([^=]+)=(.*)$') {
            $name = $Matches[1].Trim()
            $value = $Matches[2].Trim()
            if (($value.StartsWith('"') -and $value.EndsWith('"')) -or
                ($value.StartsWith("'") -and $value.EndsWith("'"))) {
                $value = $value.Substring(1, $value.Length - 2)
            }
            Set-Item -Path ("Env:{0}" -f $name) -Value $value
        }
    }
}

$root = (Resolve-Path -LiteralPath $ProjectRoot).Path
$backendDir = if (Test-Path (Join-Path $root "app\main.py")) {
    $root
} elseif (Test-Path (Join-Path $root "backend\app\main.py")) {
    Join-Path $root "backend"
} else {
    throw "Could not find backend\app\main.py below '$root'. Run this script from the project root or pass -ProjectRoot."
}

$envPath = Join-Path $backendDir "infrastructure\.env"
Import-SimpleDotEnv $envPath

$env:BACKEND_HOST = "0.0.0.0"
$env:BACKEND_PORT = [string]$BackendPort
$env:LLM_SERVER_HOST = if ($env:LLM_SERVER_HOST) { $env:LLM_SERVER_HOST } else { "localhost" }
$env:LLM_SERVER_PORT = if ($env:LLM_SERVER_PORT) { $env:LLM_SERVER_PORT } else { "11434" }
$env:LLM_MODEL = if ($env:LLM_MODEL) { $env:LLM_MODEL } else { "llama3:8b" }
if ($EnableRag) {
    $env:RAG_ENABLED = "true"
}

Step "Checking Python"
& $PythonCmd --version
if ($LASTEXITCODE -ne 0) {
    throw "Python was not found. Pass the full executable path with -PythonCmd."
}

Step "Checking Python dependencies"
$dependencyCheck = "import fastapi, httpx, pydantic, uvicorn; print('Python dependencies are available')"
& $PythonCmd -c $dependencyCheck
if ($LASTEXITCODE -ne 0) {
    if ($InstallDependencies) {
        Write-Host "Installing core dependencies from requirements.txt..." -ForegroundColor Yellow
        Push-Location $backendDir
        try {
            & $PythonCmd -m pip install -r requirements.txt
            if ($EnableRag) {
                & $PythonCmd -m pip install -r requirements-rag.txt
            }
        }
        finally {
            Pop-Location
        }
    }
    else {
        throw "Required Python packages are missing. Run with -InstallDependencies or install requirements.txt manually."
    }
}

Step "Checking Ollama reachability"
if (-not (Test-HttpEndpoint "$OllamaUrl/api/tags" 8)) {
    throw "Ollama is not reachable at $OllamaUrl. Start Ollama first."
}
Write-Host "Ollama reachable at $OllamaUrl" -ForegroundColor Green

$tags = Invoke-RestMethod -Uri "$OllamaUrl/api/tags" -Method Get -TimeoutSec 8
$modelName = $env:LLM_MODEL
$modelPresent = @($tags.models | Where-Object { $_.name -eq $modelName -or $_.name -like "$modelName`%" }).Count -gt 0
if (-not $modelPresent) {
    throw "Ollama model '$modelName' is not installed. Run: ollama pull $modelName"
}

if ($EnableRag) {
    Step "Checking RAG services"
    if (-not (Test-HttpEndpoint "http://localhost:6333/collections" 5)) {
        throw "RAG is enabled but Qdrant is not reachable at http://localhost:6333. Start Qdrant natively or run without -EnableRag."
    }

    $embeddingModel = if ($env:EMBEDDING_MODEL) { $env:EMBEDDING_MODEL } else { "nomic-embed-text" }
    $embeddingPresent = @($tags.models | Where-Object { $_.name -eq $embeddingModel -or $_.name -like "$embeddingModel`%" }).Count -gt 0
    if (-not $embeddingPresent) {
        throw "RAG embedding model '$embeddingModel' is not installed. Run: ollama pull $embeddingModel"
    }
    Write-Host "Qdrant and embedding model are available." -ForegroundColor Green
}

Step "Starting backend in a new PowerShell window"
$backendCommand = @"
Set-Location -LiteralPath '$backendDir'
`$env:BACKEND_HOST = '$($env:BACKEND_HOST)'
`$env:BACKEND_PORT = '$($env:BACKEND_PORT)'
`$env:LLM_SERVER_HOST = '$($env:LLM_SERVER_HOST)'
`$env:LLM_SERVER_PORT = '$($env:LLM_SERVER_PORT)'
`$env:LLM_MODEL = '$($env:LLM_MODEL)'
if ('$($env:RAG_ENABLED)' -ne '') { `$env:RAG_ENABLED = '$($env:RAG_ENABLED)' }
& '$PythonCmd' -m uvicorn app.main:app --host 0.0.0.0 --port $BackendPort
"@

Start-Process -FilePath "powershell.exe" -ArgumentList @(
    "-NoExit",
    "-ExecutionPolicy", "Bypass",
    "-Command", $backendCommand
)

Start-Sleep -Seconds 2
if (-not (Test-HttpEndpoint "http://localhost:$BackendPort/health" 5)) {
    Write-Host "Backend process was launched, but /health is not ready yet. Check the new PowerShell window." -ForegroundColor Yellow
}
else {
    Write-Host "Backend is healthy at http://localhost:$BackendPort" -ForegroundColor Green
}

Write-Host ""
Write-Host "Native services launched successfully." -ForegroundColor Green
Write-Host "Health: http://localhost:$BackendPort/health"
Write-Host "API docs: http://localhost:$BackendPort/docs"
