# Code-action UI changes

- Added a multiline compiler/build error input prompt to the Fix Errors flow (the existing dialog is now wired as the required input).
- Added an editable programming-language selection dialog for Algorithm to Code.
- Added the `Algorithm to Code` context-menu command and command ID using the backend's exact action identifier `algorith_to_code`.
- Fix Errors keeps an explicit Apply Changes (Replace Selection) button; it does not silently edit the source.
- Input validation prevents sending Fix Errors without an error or Algorithm to Code without a language.
- This package is source-only and has not been compiled or runtime-tested in this environment.


## Code to Algorithm context-menu action
- Added the missing `Code to Algorithm` command to the editor Ask AI submenu.
- Registered command ID `0x0119` and dispatches backend action `code_to_algorithm`.
- The action uses the selected source code and does not require a target-language dialog.


## Chat input keyboard behavior
- Press Enter to send the current chat message.
- Press Shift+Enter to insert a newline.
- The Send button remains available.
